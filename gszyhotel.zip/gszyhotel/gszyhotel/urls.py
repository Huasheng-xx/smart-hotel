"""
URL configuration for gszyhotel project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from django.conf import settings
from django.conf.urls.static import static
from hotel_app import views

urlpatterns = [
    # ==================== Admin 后台 ====================
    path('admin/', admin.site.urls),

    # ==================== 认证相关 ====================
    path('login/', views.custom_login, name='login'),
    path('logout/', views.custom_logout, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('change-password/', views.change_password, name='change_password'),

    # Django内置的认证视图（可选，备用）
    path('password-reset/',
         auth_views.PasswordResetView.as_view(template_name='auth/password_reset.html'),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(template_name='auth/password_reset_done.html'),
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(template_name='auth/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('reset/done/',
         auth_views.PasswordResetCompleteView.as_view(template_name='auth/password_reset_complete.html'),
         name='password_reset_complete'),

    # ==================== 主页和仪表板 ====================
    path('', views.index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # ==================== 客房管理 ====================
    path('rooms/', views.room_list, name='room_list'),
    path('rooms/add/', views.room_add, name='room_add'),
    path('rooms/status/update/', views.room_status_update, name='room_status_update'),
    path('rooms/<str:room_id>/', views.room_detail, name='room_detail'),
    path('rooms/<str:room_id>/edit/', views.room_edit, name='room_edit'),
    path('rooms/<str:room_id>/delete/', views.room_delete, name='room_delete'),


    # ==================== 客户管理 ====================
    path('customers/', views.customer_list, name='customer_list'),
    path('customers/add/', views.customer_add, name='customer_add'),
    path('customers/<int:customer_id>/', views.customer_detail, name='customer_detail'),
    path('customers/<int:customer_id>/edit/', views.customer_edit, name='customer_edit'),
    path('customers/search/', views.customer_search, name='customer_search'),

    # ==================== 预订管理 ====================
    path('reservations/', views.reservation_list, name='reservation_list'),
    path('reservations/add/', views.reservation_add, name='reservation_add'),
    path('reservations/<int:reservation_id>/', views.reservation_detail, name='reservation_detail'),
    path('reservations/<int:reservation_id>/confirm/', views.reservation_confirm, name='reservation_confirm'),
    path('reservations/<int:reservation_id>/cancel/', views.reservation_cancel, name='reservation_cancel'),
    path('reservations/<int:reservation_id>/checkin/', views.reservation_checkin, name='reservation_checkin'),

    # ==================== 入住管理 ====================
    path('checkins/', views.checkin_list, name='checkin_list'),
    path('checkins/add/', views.checkin_add, name='checkin_add'),
    path('checkins/<int:checkin_id>/', views.checkin_detail, name='checkin_detail'),
    # 修复：删除重复的路由，只保留一个正确的命名
    path('checkins/<int:checkin_id>/checkout/', views.checkin_checkout, name='checkin_checkout'),
    path('checkins/<int:checkin_id>/extend/', views.checkin_extend, name='checkin_extend'),
    # 账单管理已经单独有这个路由了
    # path('checkins/<int:checkin_id>/bills/', views.checkin_bills, name='checkin_bills'),
    path('debug/checkins/', views.debug_checkins, name='debug_checkins'),
    # ==================== 账单管理 ====================
    path('bills/', views.bill_list, name='bill_list'),
    path('bills/add/', views.bill_add, name='bill_add'),
    path('bills/<int:bill_id>/pay/', views.bill_pay, name='bill_pay'),
    path('checkins/<int:checkin_id>/bills/', views.checkin_bills, name='checkin_bills'),

    # ==================== 报表查询 ====================
    # 房态相关报表
    path('reports/room-status/', views.report_room_status, name='report_room_status'),
    path('reports/occupancy/', views.report_occupancy, name='report_occupancy'),  # 修复名称一致

    # 客人相关报表
    path('reports/daily-arrivals/', views.report_daily_arrivals, name='report_daily_arrivals'),

    # 在urlpatterns中添加
    path('reports/daily-arrivals/api/', views.api_today_arrivals, name='api_today_arrivals'),
    path('reports/daily-arrivals/export/', views.export_daily_arrivals, name='export_daily_arrivals'),


    path('reports/daily-departures/', views.report_daily_departures, name='report_daily_departures'),
    path('reports/customer-statistics/', views.report_customer_statistics, name='report_customer_statistics'),

    # 财务相关报表
    path('reports/revenue/', views.report_revenue, name='report_revenue'),
    path('reports/billing-summary/', views.report_billing_summary, name='report_billing_summary'),

    # ==================== 实时查询 ====================
    path('live/room-status/', views.live_room_status, name='live_room_status'),
    path('live/guests-in-house/', views.live_guests_in_house, name='live_guests_in_house'),
    path('live/expected-departures/', views.live_expected_departures, name='live_expected_departures'),
    path('live/today-summary/', views.live_today_summary, name='live_today_summary'),

    # ==================== 综合查询 ====================
    path('query/room-availability/', views.query_room_availability, name='query_room_availability'),
    path('query/guest-history/', views.query_guest_history, name='query_guest_history'),
    path('query/billing-details/', views.query_billing_details, name='query_billing_details'),
    path('query/reservation-status/', views.query_reservation_status, name='query_reservation_status'),

    # ==================== API接口 ====================
    # 客房相关API
    path('api/available-rooms/', views.api_available_rooms, name='api_available_rooms'),
    path('api/room-status/<str:room_id>/', views.api_room_status, name='api_room_status'),
    path('api/update-room-status/', views.api_update_room_status, name='api_update_room_status'),

    # 客户相关API
    path('api/customer-info/<int:customer_id>/', views.api_customer_info, name='api_customer_info'),
    path('api/search-customers/', views.api_search_customers, name='api_search_customers'),
    path('api/customer-history/<int:customer_id>/', views.api_customer_history, name='api_customer_history'),

    # 预订相关API
    path('api/check-reservation/', views.api_check_reservation, name='api_check_reservation'),
    path('api/calculate-price/', views.api_calculate_price, name='api_calculate_price'),
    path('api/reservation-details/<int:reservation_id>/', views.api_reservation_details,
         name='api_reservation_details'),

    # 入住相关API
    path('api/checkin-details/<int:checkin_id>/', views.api_checkin_details, name='api_checkin_details'),
    path('api/guest-bills/<int:checkin_id>/', views.api_guest_bills, name='api_guest_bills'),

    # 报表数据API
    path('api/dashboard-stats/', views.api_dashboard_stats, name='api_dashboard_stats'),
    path('api/revenue-chart/', views.api_revenue_chart, name='api_revenue_chart'),
    path('api/occupancy-chart/', views.api_occupancy_chart, name='api_occupancy_chart'),

    # ==================== 系统功能 ====================
    path('system/logs/', views.system_logs, name='system_logs'),
    path('system/backup/', views.system_backup, name='system_backup'),
    path('system/settings/', views.system_settings, name='system_settings'),

    # ==================== 员工管理 ====================
    path('staff/', views.staff_list, name='staff_list'),
    path('staff/add/', views.staff_add, name='staff_add'),
    path('staff/<int:staff_id>/edit/', views.staff_edit, name='staff_edit'),
    path('staff/<int:staff_id>/profile/', views.staff_profile, name='staff_profile'),

    # ==================== 快速操作 ====================
    path('quick/checkin/', views.quick_checkin, name='quick_checkin'),
    path('quick/checkout/', views.quick_checkout, name='quick_checkout'),
    path('quick/reservation/', views.quick_reservation, name='quick_reservation'),
    path('quick/billing/', views.quick_billing, name='quick_billing'),
]




