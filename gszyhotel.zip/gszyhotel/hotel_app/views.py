from django.contrib import messages
from django.contrib.auth import authenticate, login, update_session_auth_hash
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Case, When, Value, IntegerField, Max, Min
from django.http import JsonResponse, HttpResponse
from django.shortcuts import redirect
from django.shortcuts import render, get_object_or_404
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST, require_GET

from .forms import *
from .utils import *


# ==================== 错误页面处理 ====================
def custom_404(request):
    return render(request, 'errors/404.html', status=404)

def custom_500(request):
    return render(request, 'errors/500.html', status=500)

# ==================== 认证相关视图 ====================
@never_cache  # 确保页面不被缓存
def custom_logout(request):
    """自定义登出视图"""
    # 检查用户是否已登录
    if request.user.is_authenticated:
        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='系统认证',
            action='登出',
            description=f'员工 {request.user.name} 退出系统',
            ip_address=get_client_ip(request)
        )

    # 登出用户
    logout(request)

    # 清除所有session数据
    request.session.flush()

    # 清除cookie
    response = redirect('login')

    # 添加不缓存头
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'

    # 清除可能的用户相关cookie
    response.delete_cookie('sessionid')
    response.delete_cookie('csrftoken')

    messages.success(request, '您已成功退出系统！')
    return response


def custom_login(request):
    """自定义登录视图"""
    # 如果用户已登录，重定向到dashboard
    if request.user.is_authenticated:
        return redirect('dashboard')

    # 检查是否有退出登录的消息
    logout_message = request.GET.get('logout', '')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)
                user.last_login = timezone.now()
                user.save()

                # 记录操作日志
                OperationLog.objects.create(
                    staff=user,
                    module='系统认证',
                    action='登录',
                    description=f'员工 {user.name} 登录系统',
                    ip_address=get_client_ip(request)
                )

                messages.success(request, f'欢迎回来，{user.name}！')

                # 检查是否有重定向参数
                next_url = request.POST.get('next', 'dashboard')
                return redirect(next_url)
            else:
                messages.error(request, '账号已被禁用，请联系管理员！')
        else:
            messages.error(request, '用户名或密码错误！')

    # 传递next参数到模板
    next_param = request.GET.get('next', 'dashboard')

    return render(request, 'auth/login.html', {
        'next': next_param,
        'logout_message': logout_message
    })

# def custom_login(request):
#     """自定义登录视图"""
#     if request.user.is_authenticated:
#         return redirect('dashboard')
#
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         user = authenticate(request, username=username, password=password)
#
#         if user is not None:
#             if user.is_active:
#                 login(request, user)
#                 user.last_login = timezone.now()
#                 user.save()
#
#                 # 记录操作日志
#                 OperationLog.objects.create(
#                     staff=user,
#                     module='系统认证',
#                     action='登录',
#                     description=f'员工 {user.name} 登录系统',
#                     ip_address=get_client_ip(request)
#                 )
#
#                 messages.success(request, f'欢迎回来，{user.name}！')
#                 next_url = request.GET.get('next', 'dashboard')
#                 return redirect(next_url)
#             else:
#                 messages.error(request, '账号已被禁用，请联系管理员！')
#         else:
#             messages.error(request, '用户名或密码错误！')
#
#     return render(request, 'auth/login.html')

# @login_required
# def custom_logout(request):
#     """自定义登出视图"""
#     # 记录操作日志
#     OperationLog.objects.create(
#         staff=request.user,
#         module='系统认证',
#         action='登出',
#         description=f'员工 {request.user.name} 退出系统',
#         ip_address=get_client_ip(request)
#     )
#
#     logout(request)
#     messages.success(request, '您已成功退出系统！')
#     return redirect('login')


@login_required
def profile_view(request):
    """个人资料视图"""
    staff = request.user

    if request.method == 'POST':
        form = StaffProfileForm(request.POST, instance=staff)
        if form.is_valid():
            form.save()
            messages.success(request, '个人资料更新成功！')

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='个人资料',
                action='更新',
                description=f'更新个人资料',
                ip_address=get_client_ip(request)
            )

            return redirect('profile')
    else:
        form = StaffProfileForm(instance=staff)

    # 获取最近的操作日志
    recent_logs = OperationLog.objects.filter(
        staff=staff
    ).order_by('-operation_time')[:10]

    return render(request, 'auth/profile.html', {
        'staff': staff,
        'form': form,
        'recent_logs': recent_logs
    })




@login_required
def change_password(request):
    """修改密码视图"""
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if not request.user.check_password(old_password):
            messages.error(request, '原密码错误！')
        elif new_password != confirm_password:
            messages.error(request, '两次输入的新密码不一致！')
        elif len(new_password) < 6:
            messages.error(request, '新密码长度至少6位！')
        else:
            request.user.set_password(new_password)
            request.user.save()
            update_session_auth_hash(request, request.user)

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='系统认证',
                action='修改密码',
                description=f'修改登录密码',
                ip_address=get_client_ip(request)
            )

            messages.success(request, '密码修改成功！')
            return redirect('profile')

    return render(request, 'auth/change_password.html')


# ==================== 主页和仪表板 ====================
def index(request):
    """首页视图"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'index.html')


@login_required
def dashboard(request):
    """仪表板视图"""
    today = timezone.now().date()

    # 1. 房态统计
    room_stats = Room.objects.aggregate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    )

    # 2. 今日统计
    today_stats = {
        'checkins': CheckIn.objects.filter(
            actual_check_in__date=today
        ).count(),
        'checkouts': CheckIn.objects.filter(
            actual_check_out__date=today,
            check_in_status='已离店'
        ).count(),
        'reservations': Reservation.objects.filter(
            expected_check_in=today,
            reservation_status='已确认'
        ).count(),
        'guests_in_house': CheckIn.objects.filter(
            check_in_status='在住'
        ).count(),
        'revenue': Bill.objects.filter(
            payment_time__date=today,
            payment_status='已结'
        ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total'],
        'unpaid_bills': Bill.objects.filter(
            payment_status='未结'
        ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
    }

    # 3. 即将离店客人（今天和明天）
    upcoming_checkouts = CheckIn.objects.filter(
        expected_check_out__lte=today + timedelta(days=1),
        check_in_status='在住'
    ).select_related('customer', 'room')[:10]

    # 4. 今日抵达客人
    today_arrivals = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')[:10]

    # 5. 最近操作日志
    recent_logs = OperationLog.objects.select_related('staff').order_by('-operation_time')[:10]

    # 6. 月度营收趋势（最近30天）
    revenue_data = []
    for i in range(30, -1, -1):
        day = today - timedelta(days=i)
        day_revenue = Bill.objects.filter(
            payment_time__date=day,
            payment_status='已结'
        ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
        revenue_data.append({
            'date': day.strftime('%m-%d'),
            'revenue': float(day_revenue)
        })

    # 7. 房型出租率
    room_type_stats = []
    for room_type in Room.objects.values_list('room_type', flat=True).distinct():
        total_rooms = Room.objects.filter(room_type=room_type).count()
        occupied_rooms = CheckIn.objects.filter(
            room__room_type=room_type,
            check_in_status='在住'
        ).count()

        if total_rooms > 0:
            occupancy_rate = (occupied_rooms / total_rooms) * 100
            room_type_stats.append({
                'type': room_type,
                'total': total_rooms,
                'occupied': occupied_rooms,
                'rate': round(occupancy_rate, 1)
            })

    return render(request, 'dashboard.html', {
        'today': today,
        'room_stats': room_stats,
        'today_stats': today_stats,
        'upcoming_checkouts': upcoming_checkouts,
        'today_arrivals': today_arrivals,
        'recent_logs': recent_logs,
        'revenue_data': json.dumps(revenue_data),
        'room_type_stats': room_type_stats
    })


# ==================== 客房管理模块 ====================
@login_required
def room_list(request):
    """客房列表视图"""
    rooms = Room.objects.all().order_by('floor', 'room_id')

    # 筛选条件
    status = request.GET.get('status')
    room_type = request.GET.get('type')
    floor = request.GET.get('floor')
    search = request.GET.get('search')

    if status:
        rooms = rooms.filter(status=status)
    if room_type:
        rooms = rooms.filter(room_type=room_type)
    if floor:
        rooms = rooms.filter(floor=floor)
    if search:
        rooms = rooms.filter(
            Q(room_id__icontains=search) |
            Q(room_type__icontains=search) |
            Q(description__icontains=search)
        )

    # 统计信息
    stats = rooms.aggregate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    )

    # 分页
    paginator = Paginator(rooms, 20)
    page = request.GET.get('page', 1)

    try:
        rooms_page = paginator.page(page)
    except PageNotAnInteger:
        rooms_page = paginator.page(1)
    except EmptyPage:
        rooms_page = paginator.page(paginator.num_pages)

    # 获取筛选选项
    room_types = Room.objects.values_list('room_type', flat=True).distinct()
    floors = Room.objects.values_list('floor', flat=True).distinct().order_by('floor')

    return render(request, 'rooms/list.html', {
        'rooms': rooms_page,
        'stats': stats,
        'status_choices': Room.ROOM_STATUS_CHOICES,
        'room_types': room_types,
        'floors': floors,
        'current_filters': {
            'status': status,
            'type': room_type,
            'floor': floor,
            'search': search
        }
    })


@login_required
def room_detail(request, room_id):
    """客房详情视图"""
    room = get_object_or_404(Room, room_id=room_id)

    # 当前入住信息
    current_checkin = CheckIn.objects.filter(
        room=room,
        check_in_status='在住'
    ).first()

    # 计算已住天数
    days_stayed = 0
    if current_checkin:
        today = timezone.now().date()
        checkin_date = current_checkin.actual_check_in.date()
        days_stayed = (today - checkin_date).days
        if days_stayed < 0:
            days_stayed = 0

    # 未来预订
    upcoming_reservations = Reservation.objects.filter(
        room=room,
        expected_check_in__gte=date.today(),
        reservation_status__in=['待确认', '已确认']
    ).order_by('expected_check_in')[:5]

    # 入住历史
    checkin_history = CheckIn.objects.filter(
        room=room
    ).select_related('customer').order_by('-actual_check_in')[:10]

    # 房态变更记录
    status_logs = RoomStatusLog.objects.filter(
        room=room
    ).select_related('operator').order_by('-change_time')[:10]

    # 账单记录
    recent_bills = Bill.objects.filter(
        check_in__room=room
    ).select_related('check_in', 'check_in__customer').order_by('-consumption_time')[:10]

    return render(request, 'rooms/detail.html', {
        'room': room,
        'current_checkin': current_checkin,
        'days_stayed': days_stayed,  # 新增：已住天数
        'upcoming_reservations': upcoming_reservations,
        'checkin_history': checkin_history,
        'status_logs': status_logs,
        'recent_bills': recent_bills,
        'today': timezone.now().date(),  # 新增：今天日期
    })
# @login_required
# def room_detail(request, room_id):
#     """客房详情视图"""
#     room = get_object_or_404(Room, room_id=room_id)
#
#     # 当前入住信息
#     current_checkin = CheckIn.objects.filter(
#         room=room,
#         check_in_status='在住'
#     ).first()
#
#     # 未来预订
#     upcoming_reservations = Reservation.objects.filter(
#         room=room,
#         expected_check_in__gte=date.today(),
#         reservation_status__in=['待确认', '已确认']
#     ).order_by('expected_check_in')[:5]
#
#     # 入住历史
#     checkin_history = CheckIn.objects.filter(
#         room=room
#     ).select_related('customer').order_by('-actual_check_in')[:10]
#
#     # 房态变更记录
#     status_logs = RoomStatusLog.objects.filter(
#         room=room
#     ).select_related('operator').order_by('-change_time')[:10]
#
#     # 账单记录
#     recent_bills = Bill.objects.filter(
#         check_in__room=room
#     ).select_related('check_in', 'check_in__customer').order_by('-consumption_time')[:10]
#
#     return render(request, 'rooms/detail.html', {
#         'room': room,
#         'current_checkin': current_checkin,
#         'upcoming_reservations': upcoming_reservations,
#         'checkin_history': checkin_history,
#         'status_logs': status_logs,
#         'recent_bills': recent_bills
#     })


@login_required
@permission_required('hotel_app.add_room', raise_exception=True)
def room_add(request):
    """添加客房视图"""
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            room = form.save()

            # 记录房态日志
            RoomStatusLog.objects.create(
                room=room,
                old_status=None,
                new_status=room.status,
                change_reason='新增房间',
                operator=request.user
            )

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='客房管理',
                action='新增',
                target_id=room.room_id,
                description=f'新增房间 {room.room_id} ({room.room_type})',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'房间 {room.room_id} 添加成功！')
            return redirect('room_detail', room_id=room.room_id)
    else:
        form = RoomForm()

    return render(request, 'rooms/form.html', {
        'form': form,
        'title': '添加房间',
        'submit_text': '添加'
    })


@login_required
@permission_required('hotel_app.change_room', raise_exception=True)
def room_edit(request, room_id):
    """编辑客房视图"""
    room = get_object_or_404(Room, room_id=room_id)
    old_status = room.status

    if request.method == 'POST':
        form = RoomForm(request.POST, instance=room)
        if form.is_valid():
            room = form.save()

            # 如果房态变更，记录日志
            if old_status != room.status:
                RoomStatusLog.objects.create(
                    room=room,
                    old_status=old_status,
                    new_status=room.status,
                    change_reason='手动更新',
                    operator=request.user
                )

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='客房管理',
                action='修改',
                target_id=room.room_id,
                description=f'修改房间 {room.room_id} 信息',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'房间 {room.room_id} 更新成功！')
            return redirect('room_detail', room_id=room.room_id)
    else:
        form = RoomForm(instance=room)

    return render(request, 'rooms/form.html', {
        'form': form,
        'title': f'编辑房间 {room.room_id}',
        'submit_text': '更新'
    })


@login_required
@permission_required('hotel_app.delete_room', raise_exception=True)
def room_delete(request, room_id):
    """删除客房视图"""
    room = get_object_or_404(Room, room_id=room_id)

    # 检查房间是否可删除
    if CheckIn.objects.filter(room=room, check_in_status='在住').exists():
        messages.error(request, f'房间 {room_id} 当前有客人入住，不能删除！')
        return redirect('room_detail', room_id=room_id)

    if Reservation.objects.filter(room=room, reservation_status='已确认').exists():
        messages.error(request, f'房间 {room_id} 有有效预订，不能删除！')
        return redirect('room_detail', room_id=room_id)

    if request.method == 'POST':
        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='客房管理',
            action='删除',
            target_id=room.room_id,
            description=f'删除房间 {room.room_id} ({room.room_type})',
            ip_address=get_client_ip(request)
        )

        room.delete()
        messages.success(request, f'房间 {room_id} 删除成功！')
        return redirect('room_list')

    return render(request, 'rooms/delete_confirm.html', {'room': room})


@login_required
@require_POST
def room_status_update(request):
    """更新房态视图"""
    room_id = request.POST.get('room_id')
    new_status = request.POST.get('status')
    reason = request.POST.get('reason', '手动更新')

    try:
        room = Room.objects.get(room_id=room_id)
        old_status = room.status

        # 验证状态转换
        if not is_valid_status_transition(old_status, new_status):
            messages.error(request, f'无效的状态转换: {old_status} -> {new_status}')
            return redirect('room_detail', room_id=room_id)

        # 更新房态
        room.status = new_status
        room.save()

        # 记录房态日志
        RoomStatusLog.objects.create(
            room=room,
            old_status=old_status,
            new_status=new_status,
            change_reason=reason,
            operator=request.user
        )

        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='客房管理',
            action='更新房态',
            target_id=room.room_id,
            description=f'更新房间 {room.room_id} 状态: {old_status} -> {new_status}',
            ip_address=get_client_ip(request)
        )

        messages.success(request, f'房间 {room_id} 状态已更新为 {new_status}')

    except Room.DoesNotExist:
        messages.error(request, f'房间 {room_id} 不存在！')
    except Exception as e:
        messages.error(request, f'更新失败: {str(e)}')

    return redirect('room_detail', room_id=room_id)


# ==================== 客户管理模块 ====================
@login_required
def customer_list(request):
    """客户列表视图"""
    customers = Customer.objects.all().order_by('-create_time')

    # 筛选条件
    customer_type = request.GET.get('type')
    member_level = request.GET.get('level')
    search = request.GET.get('search')

    if customer_type:
        customers = customers.filter(customer_type=customer_type)
    if member_level:
        customers = customers.filter(member_level=member_level)
    if search:
        customers = customers.filter(
            Q(name__icontains=search) |
            Q(phone__icontains=search) |
            Q(member_id__icontains=search) |
            Q(id_number__icontains=search) |
            Q(email__icontains=search)
        )

    # 统计信息
    stats = customers.aggregate(
        total=Count('customer_id'),
        vip=Count('customer_id', filter=Q(customer_type='VIP')),
        member=Count('customer_id', filter=Q(customer_type='会员')),
        guest=Count('customer_id', filter=Q(customer_type='散客')),
        blacklist=Count('customer_id', filter=Q(is_blacklist=True))
    )

    # 分页
    paginator = Paginator(customers, 20)
    page = request.GET.get('page', 1)

    try:
        customers_page = paginator.page(page)
    except PageNotAnInteger:
        customers_page = paginator.page(1)
    except EmptyPage:
        customers_page = paginator.page(paginator.num_pages)

    return render(request, 'customers/list.html', {
        'customers': customers_page,
        'stats': stats,
        'type_choices': Customer.CUSTOMER_TYPE_CHOICES,
        'current_filters': {
            'type': customer_type,
            'level': member_level,
            'search': search
        }
    })


@login_required
def customer_add(request):
    """添加客户视图"""
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='客户管理',
                action='新增',
                target_id=customer.customer_id,
                description=f'新增客户 {customer.name} ({customer.customer_type})',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'客户 {customer.name} 添加成功！')
            return redirect('customer_detail', customer_id=customer.customer_id)
    else:
        form = CustomerForm()

    return render(request, 'customers/form.html', {
        'form': form,
        'title': '添加客户',
        'submit_text': '添加'
    })



@login_required
def customer_detail(request, customer_id):
    """客户详情视图"""
    customer = get_object_or_404(Customer, customer_id=customer_id)

    # 入住历史
    checkin_history = CheckIn.objects.filter(
        customer=customer
    ).select_related('room').order_by('-actual_check_in')

    # 预订记录
    reservations = Reservation.objects.filter(
        customer=customer
    ).select_related('room').order_by('-create_time')

    # 消费记录
    bills = Bill.objects.filter(
        check_in__customer=customer
    ).select_related('check_in', 'check_in__room').order_by('-consumption_time')

    # 消费统计
    consumption_stats = bills.aggregate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
        bill_count=Count('bill_id')
    )

    # 入住统计 - 修复这里
    try:
        stay_stats = checkin_history.aggregate(
            total_days=Coalesce(Sum(
                Case(
                    When(
                        actual_check_out__isnull=False,
                        then=F('expected_check_out') - F('actual_check_in__date')
                    ),
                    default=Value(0),
                    output_field=IntegerField()  # 明确指定 output_field
                )
            ), 0),
            stay_count=Count('check_in_id'),
            avg_stay=Coalesce(Avg(
                Case(
                    When(
                        actual_check_out__isnull=False,
                        then=F('expected_check_out') - F('actual_check_in__date')
                    ),
                    default=Value(0),
                    output_field=IntegerField()  # 明确指定 output_field
                )
            ), 0)
        )
    except Exception as e:
        # 如果统计出错，提供默认值
        stay_stats = {
            'total_days': 0,
            'stay_count': checkin_history.count(),
            'avg_stay': 0
        }

    return render(request, 'customers/detail.html', {
        'customer': customer,
        'checkin_history': checkin_history[:10],
        'reservations': reservations[:10],
        'bills': bills[:10],
        'consumption_stats': consumption_stats,
        'stay_stats': stay_stats,
        'total_checkins': checkin_history.count(),
        'total_reservations': reservations.count(),
        'total_bills': bills.count()
    })
# @login_required
# def customer_detail(request, customer_id):
#     """客户详情视图"""
#     customer = get_object_or_404(Customer, customer_id=customer_id)
#
#     # 入住历史
#     checkin_history = CheckIn.objects.filter(
#         customer=customer
#     ).select_related('room').order_by('-actual_check_in')
#
#     # 预订记录
#     reservations = Reservation.objects.filter(
#         customer=customer
#     ).select_related('room').order_by('-create_time')
#
#     # 消费记录
#     bills = Bill.objects.filter(
#         check_in__customer=customer
#     ).select_related('check_in', 'check_in__room').order_by('-consumption_time')
#
#     # 消费统计
#     consumption_stats = bills.aggregate(
#         total_amount=Coalesce(Sum('amount'), Decimal('0')),
#         paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
#         unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
#         bill_count=Count('bill_id')
#     )
#
#     # 入住统计
#     stay_stats = checkin_history.aggregate(
#         total_days=Coalesce(Sum(
#             Case(
#                 When(
#                     actual_check_out__isnull=False,
#                     then=F('expected_check_out') - F('actual_check_in__date')
#                 ),
#                 default=Value(0),
#                 output_field=IntegerField()
#             )
#         ), 0),
#         stay_count=Count('check_in_id'),
#         avg_stay=Coalesce(Avg(
#             Case(
#                 When(
#                     actual_check_out__isnull=False,
#                     then=F('expected_check_out') - F('actual_check_in__date')
#                 ),
#                 default=Value(0),
#                 output_field=IntegerField()
#             )
#         ), 0)
#     )
#
#     return render(request, 'customers/detail.html', {
#         'customer': customer,
#         'checkin_history': checkin_history[:10],
#         'reservations': reservations[:10],
#         'bills': bills[:10],
#         'consumption_stats': consumption_stats,
#         'stay_stats': stay_stats,
#         'total_checkins': checkin_history.count(),
#         'total_reservations': reservations.count(),
#         'total_bills': bills.count()
#     })


@login_required
def customer_edit(request, customer_id):
    """编辑客户视图"""
    customer = get_object_or_404(Customer, customer_id=customer_id)

    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            customer = form.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='客户管理',
                action='修改',
                target_id=customer.customer_id,
                description=f'修改客户 {customer.name} 信息',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'客户 {customer.name} 更新成功！')
            return redirect('customer_detail', customer_id=customer.customer_id)
    else:
        form = CustomerForm(instance=customer)

    return render(request, 'customers/form.html', {
        'form': form,
        'title': f'编辑客户 {customer.name}',
        'submit_text': '更新'
    })


@login_required
def customer_search(request):
    """客户搜索视图"""
    query = request.GET.get('q', '')
    customers = []

    if query:
        customers = Customer.objects.filter(
            Q(name__icontains=query) |
            Q(phone__icontains=query) |
            Q(member_id__icontains=query) |
            Q(id_number__icontains=query)
        ).order_by('name')[:20]

    return render(request, 'customers/search.html', {
        'customers': customers,
        'query': query
    })


# ==================== 预订管理模块 ====================
@login_required
def reservation_list(request):
    """预订列表视图"""
    reservations = Reservation.objects.all().select_related(
        'customer', 'room', 'operator'
    ).order_by('-create_time')

    # 筛选条件
    status = request.GET.get('status')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    customer_name = request.GET.get('customer')
    room_id = request.GET.get('room')

    if status:
        reservations = reservations.filter(reservation_status=status)
    if date_from:
        reservations = reservations.filter(expected_check_in__gte=date_from)
    if date_to:
        reservations = reservations.filter(expected_check_in__lte=date_to)
    if customer_name:
        reservations = reservations.filter(customer__name__icontains=customer_name)
    if room_id:
        reservations = reservations.filter(room__room_id__icontains=room_id)

    # 统计信息
    stats = reservations.aggregate(
        total=Count('reservation_id'),
        pending=Count('reservation_id', filter=Q(reservation_status='待确认')),
        confirmed=Count('reservation_id', filter=Q(reservation_status='已确认')),
        checked_in=Count('reservation_id', filter=Q(reservation_status='已入住')),
        cancelled=Count('reservation_id', filter=Q(reservation_status='已取消'))
    )

    # 分页
    paginator = Paginator(reservations, 20)
    page = request.GET.get('page', 1)

    try:
        reservations_page = paginator.page(page)
    except PageNotAnInteger:
        reservations_page = paginator.page(1)
    except EmptyPage:
        reservations_page = paginator.page(paginator.num_pages)

    return render(request, 'reservations/list.html', {
        'reservations': reservations_page,
        'stats': stats,
        'status_choices': Reservation.RESERVATION_STATUS_CHOICES,
        'current_filters': {
            'status': status,
            'date_from': date_from,
            'date_to': date_to,
            'customer': customer_name,
            'room': room_id
        }
    })


@login_required
def reservation_add(request):
    """添加预订视图"""
    if request.method == 'POST':
        print("=" * 50)
        print("接收到预订表单提交")
        print(f"POST数据: {dict(request.POST)}")

        form = ReservationForm(request.POST)

        if form.is_valid():
            print("表单验证通过")
            reservation = form.save(commit=False)
            reservation.operator = request.user

            # 确保房间类型与所选房间一致
            if reservation.room:
                reservation.room_type = reservation.room.room_type
                print(f"设置房间类型: {reservation.room_type}")

            # 计算总价
            days = (reservation.expected_check_out - reservation.expected_check_in).days
            if days < 1:
                days = 1
            print(f"入住天数: {days}")

            room_price = reservation.room.price
            total_price = days * room_price
            if reservation.extra_bed:
                total_price += days * reservation.room.extra_bed_price

            reservation.total_price = total_price
            reservation.save()

            print(f"预订保存成功！ID: {reservation.reservation_id}")
            print(f"   客户: {reservation.customer.name}")
            print(f"   房间: {reservation.room.room_id}")
            print(f"   房型: {reservation.room_type}")
            print(f"   状态: {reservation.reservation_status}")
            print(f"   总价: {total_price}")

            # 更新房间状态
            if reservation.reservation_status == '已确认':
                reservation.room.status = '已预订'
                reservation.room.save()
                print(f"房间状态更新: {reservation.room.room_id} -> 已预订")

                # 记录房态日志
                RoomStatusLog.objects.create(
                    room=reservation.room,
                    old_status='空闲',
                    new_status='已预订',
                    change_reason=f'客户 {reservation.customer.name} 预订',
                    operator=request.user
                )
                print("房态日志记录完成")

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='预订管理',
                action='新增',
                target_id=reservation.reservation_id,
                description=f'为 {reservation.customer.name} 创建预订，房间 {reservation.room.room_id}',
                ip_address=get_client_ip(request)
            )
            print("操作日志记录完成")

            messages.success(request, f'预订创建成功！预订号: {reservation.reservation_id}')
            return redirect('reservation_detail', reservation_id=reservation.reservation_id)
        else:
            print(f"表单验证失败: {form.errors}")
            for field, errors in form.errors.items():
                print(f"  {field}: {errors}")
            messages.error(request, '请检查表单填写是否正确！')
    else:
        form = ReservationForm()
        print("显示空表单")

    # 获取所有房间供选择
    available_rooms = Room.objects.filter(status='空闲')

    # 获取今天和明天的日期
    today = timezone.now().date()
    tomorrow = today + timedelta(days=1)

    return render(request, 'reservations/form.html', {
        'form': form,
        'title': '创建预订',
        'submit_text': '创建',
        'available_rooms': available_rooms,
        'today': today.isoformat(),
        'tomorrow': tomorrow.isoformat(),
    })
# @login_required
# def reservation_add(request):
#     """添加预订视图"""
#     if request.method == 'POST':
#         form = ReservationForm(request.POST)
#         if form.is_valid():
#             reservation = form.save(commit=False)
#             reservation.operator = request.user
#
#             # 计算总价
#             days = (reservation.expected_check_out - reservation.expected_check_in).days
#             if days < 1:
#                 days = 1
#
#             room_price = reservation.room.price
#             total_price = days * room_price
#             if reservation.extra_bed:
#                 total_price += days * reservation.room.extra_bed_price
#
#             reservation.total_price = total_price
#             reservation.save()
#
#             # 更新房间状态
#             if reservation.reservation_status == '已确认':
#                 reservation.room.status = '已预订'
#                 reservation.room.save()
#
#                 # 记录房态日志
#                 RoomStatusLog.objects.create(
#                     room=reservation.room,
#                     old_status='空闲',
#                     new_status='已预订',
#                     change_reason=f'客户 {reservation.customer.name} 预订',
#                     operator=request.user
#                 )
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='预订管理',
#                 action='新增',
#                 target_id=reservation.reservation_id,
#                 description=f'为 {reservation.customer.name} 创建预订，房间 {reservation.room.room_id}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'预订创建成功！预订号: {reservation.reservation_id}')
#             return redirect('reservation_detail', reservation_id=reservation.reservation_id)
#     else:
#         form = ReservationForm()
#
#     return render(request, 'reservations/form.html', {
#         'form': form,
#         'title': '创建预订',
#         'submit_text': '创建'
#     })


@login_required
def reservation_detail(request, reservation_id):
    """预订详情视图"""
    reservation = get_object_or_404(Reservation, reservation_id=reservation_id)

    # 检查是否有入住记录
    checkin_record = CheckIn.objects.filter(reservation=reservation).first()

    return render(request, 'reservations/detail.html', {
        'reservation': reservation,
        'checkin_record': checkin_record
    })


@login_required
def reservation_confirm(request, reservation_id):
    """确认预订视图"""
    reservation = get_object_or_404(Reservation, reservation_id=reservation_id)

    if reservation.reservation_status != '待确认':
        messages.error(request, '只能确认待确认的预订！')
        return redirect('reservation_detail', reservation_id=reservation_id)

    reservation.reservation_status = '已确认'
    reservation.save()

    # 更新房间状态
    reservation.room.status = '已预订'
    reservation.room.save()

    # 记录房态日志
    RoomStatusLog.objects.create(
        room=reservation.room,
        old_status='空闲',
        new_status='已预订',
        change_reason=f'确认预订 #{reservation_id}',
        operator=request.user
    )

    # 记录操作日志
    OperationLog.objects.create(
        staff=request.user,
        module='预订管理',
        action='确认',
        target_id=reservation.reservation_id,
        description=f'确认预订 {reservation_id}',
        ip_address=get_client_ip(request)
    )

    messages.success(request, f'预订 {reservation_id} 已确认！')
    return redirect('reservation_detail', reservation_id=reservation_id)


@login_required
def reservation_cancel(request, reservation_id):
    """取消预订视图"""
    reservation = get_object_or_404(Reservation, reservation_id=reservation_id)

    if reservation.reservation_status in ['已取消', '已入住']:
        messages.error(request, f'该预订已{reservation.get_reservation_status_display()}！')
        return redirect('reservation_detail', reservation_id=reservation_id)

    if request.method == 'POST':
        cancel_reason = request.POST.get('cancel_reason', '客户取消')

        old_status = reservation.reservation_status
        reservation.reservation_status = '已取消'
        reservation.cancel_reason = cancel_reason
        reservation.cancel_time = timezone.now()
        reservation.save()

        # 如果之前已确认，恢复房间状态
        if old_status == '已确认':
            reservation.room.status = '空闲'
            reservation.room.save()

            # 记录房态日志
            RoomStatusLog.objects.create(
                room=reservation.room,
                old_status='已预订',
                new_status='空闲',
                change_reason=f'取消预订: {cancel_reason}',
                operator=request.user
            )

        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='预订管理',
            action='取消',
            target_id=reservation.reservation_id,
            description=f'取消预订 {reservation_id}，原因: {cancel_reason}',
            ip_address=get_client_ip(request)
        )

        messages.success(request, f'预订 {reservation_id} 已取消！')
        return redirect('reservation_detail', reservation_id=reservation_id)

    return render(request, 'reservations/cancel_confirm.html', {'reservation': reservation})


@login_required
def reservation_checkin(request, reservation_id):
    """为预订办理入住视图"""
    reservation = get_object_or_404(Reservation, reservation_id=reservation_id)

    if reservation.reservation_status != '已确认':
        messages.error(request, '只能为已确认的预订办理入住！')
        return redirect('reservation_detail', reservation_id=reservation_id)

    # 检查房间是否可用
    if reservation.room.status != '已预订':
        messages.error(request, f'房间 {reservation.room.room_id} 当前不可用！')
        return redirect('reservation_detail', reservation_id=reservation_id)

    if request.method == 'POST':
        print("=" * 50)
        print("POST请求接收到")
        print(f"POST数据: {dict(request.POST)}")

        # 手动处理 datetime-local 格式
        post_data = request.POST.copy()
        if 'actual_check_in' in post_data:
            # 将 datetime-local 字符串转换为 datetime 对象
            datetime_str = post_data['actual_check_in']
            try:
                if 'T' in datetime_str:
                    # 格式: YYYY-MM-DDTHH:MM
                    post_data['actual_check_in'] = timezone.make_aware(
                        datetime.strptime(datetime_str, '%Y-%m-%dT%H:%M')
                    )
                else:
                    # 格式: YYYY-MM-DD HH:MM:SS
                    post_data['actual_check_in'] = timezone.make_aware(
                        datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
                    )
            except ValueError as e:
                print(f"日期时间解析错误: {e}")
                messages.error(request, '入住时间格式错误！')
                return redirect('reservation_checkin', reservation_id=reservation_id)

        form = CheckInForm(post_data)
        print(f"表单是否有效: {form.is_valid()}")
        print(f"表单错误: {form.errors}")

        if form.is_valid():
            print("表单验证通过")
            try:
                checkin = form.save(commit=False)
                checkin.reservation = reservation
                checkin.customer = reservation.customer
                checkin.room = reservation.room
                checkin.operator = request.user
                checkin.check_in_status = '在住'  # 确保状态设置为在住

                # 计算房费
                actual_check_in = checkin.actual_check_in
                expected_check_out = checkin.expected_check_out

                print(f"实际入住时间: {actual_check_in}")
                print(f"预计离店日期: {expected_check_out}")

                # 确保是 date 对象
                if isinstance(expected_check_out, datetime):
                    expected_check_out_date = expected_check_out.date()
                else:
                    expected_check_out_date = expected_check_out

                if isinstance(actual_check_in, datetime):
                    actual_check_in_date = actual_check_in.date()
                else:
                    actual_check_in_date = actual_check_in

                days = (expected_check_out_date - actual_check_in_date).days
                if days < 1:
                    days = 1
                print(f"入住天数: {days}天")

                room_price = reservation.room.price
                extra_bed_price = checkin.extra_bed_count * reservation.room.extra_bed_price if checkin.extra_bed else 0
                total_price = days * (room_price + extra_bed_price)

                checkin.room_price = room_price
                checkin.extra_bed_price = extra_bed_price if checkin.extra_bed else 0
                checkin.total_price = total_price

                # 修复编码问题：使用 "元" 代替 "¥"
                print(f"房费计算: {days}天 × {room_price}元 = {days * room_price}元")
                if checkin.extra_bed:
                    print(
                        f"加床费计算: {days}天 × {checkin.extra_bed_count}床 × {reservation.room.extra_bed_price}元 = {extra_bed_price}元")
                print(f"总价: {total_price}元")

                # 保存入住记录
                checkin.save()
                print(f"入住记录保存成功！入住单号: {checkin.check_in_id}")

                # 更新预订状态
                reservation.reservation_status = '已入住'
                reservation.save()
                print(f"预订状态更新为: 已入住")

                # 更新房间状态
                room = reservation.room
                room.status = '已入住'
                room.save()
                print(f"房间状态更新为: 已入住")

                # 更新客户入住次数
                customer = reservation.customer
                customer.total_stay_days += days
                customer.last_visit_date = actual_check_in_date
                customer.save()
                print(f"客户入住信息更新")

                # 记录房态日志
                RoomStatusLog.objects.create(
                    room=room,
                    old_status='已预订',
                    new_status='已入住',
                    change_reason='办理入住',
                    operator=request.user
                )
                print("房态日志记录完成")

                # 创建房费账单
                Bill.objects.create(
                    check_in=checkin,
                    bill_type='房费',
                    item_name=f'{reservation.room.room_type}房费',
                    quantity=days,
                    unit_price=room_price,
                    amount=total_price - extra_bed_price,
                    consumption_time=checkin.actual_check_in,
                    payment_status='未结',
                    operator=request.user
                )
                print("房费账单创建成功")

                # 如果有加床费
                if checkin.extra_bed and extra_bed_price > 0:
                    Bill.objects.create(
                        check_in=checkin,
                        bill_type='房费',
                        item_name='加床费',
                        quantity=days * checkin.extra_bed_count,
                        unit_price=checkin.extra_bed_price / checkin.extra_bed_count if checkin.extra_bed_count > 0 else checkin.extra_bed_price,
                        amount=extra_bed_price,
                        consumption_time=checkin.actual_check_in,
                        payment_status='未结',
                        operator=request.user
                    )
                    print("加床费账单创建成功")

                # 记录操作日志
                OperationLog.objects.create(
                    staff=request.user,
                    module='入住管理',
                    action='办理入住',
                    target_id=checkin.check_in_id,
                    description=f'为预订 {reservation_id} 办理入住，入住单号: {checkin.check_in_id}',
                    ip_address=get_client_ip(request)
                )
                print("操作日志记录完成")

                messages.success(request, f'入住办理成功！入住单号: {checkin.check_in_id}')
                return redirect('checkin_detail', checkin_id=checkin.check_in_id)

            except Exception as e:
                print(f"保存过程中出错: {str(e)}")
                import traceback
                traceback.print_exc()
                messages.error(request, f'入住办理失败: {str(e)}')
        else:
            print(f"表单验证失败: {form.errors}")
            for field, errors in form.errors.items():
                print(f"  {field}: {errors}")
            messages.error(request, '请检查表单填写是否正确！')
    else:
        # 预填表单数据
        today = timezone.now()
        tomorrow = today + timedelta(days=1)

        initial_data = {
            'actual_check_in': today,
            'expected_check_out': reservation.expected_check_out,
            'adult_count': reservation.adult_count,
            'child_count': reservation.child_count,
            'extra_bed': reservation.extra_bed,
            'extra_bed_count': 1 if reservation.extra_bed else 0,
            'payment_method': reservation.payment_method or '现金',
        }
        form = CheckInForm(initial=initial_data)
        print("显示空表单")

    return render(request, 'reservations/checkin.html', {
        'form': form,
        'reservation': reservation,
        'title': '为预订办理入住',
        'today': timezone.now().strftime('%Y-%m-%dT%H:%M'),
    })


# @login_required
# def reservation_checkin(request, reservation_id):
#     """为预订办理入住视图"""
#     reservation = get_object_or_404(Reservation, reservation_id=reservation_id)
#
#     if reservation.reservation_status != '已确认':
#         messages.error(request, '只能为已确认的预订办理入住！')
#         return redirect('reservation_detail', reservation_id=reservation_id)
#
#     # 检查房间是否可用
#     if reservation.room.status != '已预订':
#         messages.error(request, f'房间 {reservation.room.room_id} 当前不可用！')
#         return redirect('reservation_detail', reservation_id=reservation_id)
#
#     if request.method == 'POST':
#         form = CheckInForm(request.POST)
#         if form.is_valid():
#             checkin = form.save(commit=False)
#             checkin.reservation = reservation
#             checkin.customer = reservation.customer
#             checkin.room = reservation.room
#             checkin.operator = request.user
#
#             # 计算房费
#             days = (checkin.expected_check_out - checkin.actual_check_in.date()).days
#             if days < 1:
#                 days = 1
#
#             room_price = reservation.room.price
#             extra_bed_price = checkin.extra_bed_count * reservation.room.extra_bed_price if checkin.extra_bed else 0
#             total_price = days * (room_price + extra_bed_price)
#
#             checkin.room_price = room_price
#             checkin.extra_bed_price = extra_bed_price if checkin.extra_bed else 0
#             checkin.total_price = total_price
#             checkin.save()
#
#             # 更新预订状态
#             reservation.reservation_status = '已入住'
#             reservation.save()
#
#             # 更新房间状态
#             reservation.room.status = '已入住'
#             reservation.room.save()
#
#             # 更新客户入住次数
#             customer = reservation.customer
#             customer.total_stay_days += days
#             customer.last_visit_date = checkin.actual_check_in.date()
#             customer.save()
#
#             # 记录房态日志
#             RoomStatusLog.objects.create(
#                 room=reservation.room,
#                 old_status='已预订',
#                 new_status='已入住',
#                 change_reason='办理入住',
#                 operator=request.user
#             )
#
#             # 创建房费账单
#             Bill.objects.create(
#                 check_in=checkin,
#                 bill_type='房费',
#                 item_name=f'{reservation.room.room_type}房费',
#                 quantity=days,
#                 unit_price=room_price,
#                 amount=total_price - extra_bed_price,
#                 consumption_time=checkin.actual_check_in,
#                 payment_status='未结',
#                 operator=request.user
#             )
#
#             # 如果有加床费
#             if checkin.extra_bed and extra_bed_price > 0:
#                 Bill.objects.create(
#                     check_in=checkin,
#                     bill_type='房费',
#                     item_name='加床费',
#                     quantity=days * checkin.extra_bed_count,
#                     unit_price=checkin.extra_bed_price,
#                     amount=extra_bed_price,
#                     consumption_time=checkin.actual_check_in,
#                     payment_status='未结',
#                     operator=request.user
#                 )
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='入住管理',
#                 action='办理入住',
#                 target_id=checkin.check_in_id,
#                 description=f'为预订 {reservation_id} 办理入住，入住单号: {checkin.check_in_id}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'入住办理成功！入住单号: {checkin.check_in_id}')
#             return redirect('checkin_detail', checkin_id=checkin.check_in_id)
#     else:
#         # 预填表单数据
#         initial_data = {
#             'actual_check_in': timezone.now(),
#             'expected_check_out': reservation.expected_check_out,
#             'adult_count': reservation.adult_count,
#             'child_count': reservation.child_count,
#             'extra_bed': reservation.extra_bed,
#         }
#         form = CheckInForm(initial=initial_data)
#
#     return render(request, 'reservations/checkin.html', {
#         'form': form,
#         'reservation': reservation,
#         'title': '为预订办理入住'
#     })


# ==================== 入住管理模块 ====================
@login_required
def checkin_list(request):
    """入住列表视图"""
    checkins = CheckIn.objects.all().select_related(
        'customer', 'room', 'operator', 'reservation'
    ).order_by('-create_time')

    # 筛选条件
    status = request.GET.get('status')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    customer_name = request.GET.get('customer')
    room_id = request.GET.get('room')
    today_only = request.GET.get('today') == '1'
    in_house = request.GET.get('in_house') == '1'

    if status:
        checkins = checkins.filter(check_in_status=status)
    if date_from:
        checkins = checkins.filter(actual_check_in__date__gte=date_from)
    if date_to:
        checkins = checkins.filter(actual_check_in__date__lte=date_to)
    if customer_name:
        checkins = checkins.filter(customer__name__icontains=customer_name)
    if room_id:
        checkins = checkins.filter(room__room_id__icontains=room_id)
    if today_only:
        today = timezone.now().date()
        checkins = checkins.filter(actual_check_in__date=today)
    if in_house:
        checkins = checkins.filter(check_in_status='在住')

    # 统计信息
    stats = checkins.aggregate(
        total=Count('check_in_id'),
        in_house=Count('check_in_id', filter=Q(check_in_status='在住')),
        checked_out=Count('check_in_id', filter=Q(check_in_status='已离店')),
        extended=Count('check_in_id', filter=Q(check_in_status='延期'))
    )

    # 分页
    paginator = Paginator(checkins, 20)
    page = request.GET.get('page', 1)

    try:
        checkins_page = paginator.page(page)
    except PageNotAnInteger:
        checkins_page = paginator.page(1)
    except EmptyPage:
        checkins_page = paginator.page(paginator.num_pages)

    return render(request, 'checkins/list.html', {
        'checkins': checkins_page,
        'stats': stats,
        'status_choices': CheckIn.CHECK_IN_STATUS_CHOICES,
        'current_filters': {
            'status': status,
            'date_from': date_from,
            'date_to': date_to,
            'customer': customer_name,
            'room': room_id,
            'today': today_only,
            'in_house': in_house
        }
    })


@login_required
def checkin_add(request):
    """添加入住视图（直接入住）"""
    if request.method == 'POST':
        print("=" * 50)
        print("接收到直接入住表单提交")
        print(f"POST数据: {dict(request.POST)}")

        # 特别检查关键字段
        print(f"customer: {request.POST.get('customer')}")
        print(f"room: {request.POST.get('room')}")
        print(f"actual_check_in: {request.POST.get('actual_check_in')}")
        print(f"expected_check_out: {request.POST.get('expected_check_out')}")

        form = DirectCheckInForm(request.POST)

        if form.is_valid():
            print("表单验证通过")
            checkin = form.save(commit=False)

            # 获取 Staff 实例
            try:
                staff_instance = request.user
                if not isinstance(staff_instance, Staff):
                    staff_instance = Staff.objects.get(username=request.user.username)
            except Staff.DoesNotExist:
                messages.error(request, '找不到对应的员工记录！')
                return redirect('checkin_list')

            checkin.operator = staff_instance
            checkin.check_in_status = '在住'  # 关键：设置入住状态

            # 计算房费
            try:
                days = (checkin.expected_check_out - checkin.actual_check_in.date()).days
                if days < 1:
                    days = 1

                room = checkin.room
                room_price = room.price
                extra_bed_price = checkin.extra_bed_count * room.extra_bed_price if checkin.extra_bed else 0
                total_price = days * (room_price + extra_bed_price)

                checkin.room_price = room_price
                checkin.extra_bed_price = extra_bed_price if checkin.extra_bed else 0
                checkin.total_price = total_price

                # 保存入住记录
                checkin.save()
                print(f"入住记录保存成功！ID: {checkin.check_in_id}")
                print(f"   客户: {checkin.customer.name}")
                print(f"   房间: {checkin.room.room_id}")
                print(f"   状态: {checkin.check_in_status}")
                print(f"   总价: {total_price}")

                # 更新房间状态
                room.status = '已入住'
                room.save()
                print(f"房间状态更新: {room.room_id} -> 已入住")

                # 更新客户入住次数
                customer = checkin.customer
                customer.total_stay_days += days
                customer.last_visit_date = checkin.actual_check_in.date()
                customer.save()
                print(f"客户信息更新: {customer.name}")

                # 记录房态日志
                RoomStatusLog.objects.create(
                    room=room,
                    old_status='空闲',
                    new_status='已入住',
                    change_reason='直接入住',
                    operator=staff_instance
                )

                # 创建房费账单
                Bill.objects.create(
                    check_in=checkin,
                    bill_type='房费',
                    item_name=f'{room.room_type}房费',
                    quantity=days,
                    unit_price=room_price,
                    amount=total_price - extra_bed_price,
                    consumption_time=checkin.actual_check_in,
                    payment_status='未结',
                    operator=staff_instance
                )
                print(f"房费账单创建成功")

                # 如果有加床费
                if checkin.extra_bed and extra_bed_price > 0:
                    Bill.objects.create(
                        check_in=checkin,
                        bill_type='房费',
                        item_name='加床费',
                        quantity=days * checkin.extra_bed_count,
                        unit_price=checkin.extra_bed_price,
                        amount=extra_bed_price,
                        consumption_time=checkin.actual_check_in,
                        payment_status='未结',
                        operator=staff_instance
                    )
                    print(f"加床费账单创建成功")

                # 记录操作日志
                OperationLog.objects.create(
                    staff=staff_instance,
                    module='入住管理',
                    action='直接入住',
                    target_id=checkin.check_in_id,
                    description=f'为 {checkin.customer.name} 办理直接入住，房间 {room.room_id}',
                    ip_address=get_client_ip(request)
                )
                print(f"操作日志记录完成")

                messages.success(request, f'入住办理成功！入住单号: {checkin.check_in_id}')
                return redirect('checkin_detail', checkin_id=checkin.check_in_id)

            except Exception as e:
                print(f"保存过程中出错: {str(e)}")
                import traceback
                traceback.print_exc()
                messages.error(request, f'入住办理失败: {str(e)}')
        else:
            print(f"表单验证失败: {form.errors}")
            for field, errors in form.errors.items():
                print(f"  {field}: {errors}")
            messages.error(request, '请检查表单填写是否正确！')

    else:
        form = DirectCheckInForm()
        print("显示空表单")

    # 获取所有可用房间（空闲状态的房间）
    available_rooms = Room.objects.filter(status='空闲')

    # 获取所有客户
    customers = Customer.objects.all()

    # 获取房间价格信息
    rooms_price_info = {}
    for room in available_rooms:
        rooms_price_info[room.room_id] = {
            'price': float(room.price),
            'extra_bed_price': float(room.extra_bed_price),
            'room_type': room.room_type,
            'capacity': room.capacity
        }

    # 获取今天和明天的日期
    today = timezone.now().date()
    tomorrow = today + timedelta(days=1)

    # 设置表单初始值
    form.fields['actual_check_in'].initial = timezone.now()
    form.fields['expected_check_out'].initial = tomorrow
    form.fields['adult_count'].initial = 1
    form.fields['child_count'].initial = 0

    context = {
        'form': form,
        'title': '直接入住',
        'submit_text': '办理入住',
        'available_rooms': available_rooms,
        'customers': customers,
        'rooms_price_info': rooms_price_info,
        'today': today.isoformat(),
        'tomorrow': tomorrow.isoformat(),
        'now': timezone.now().strftime('%Y-%m-%dT%H:%M'),  # datetime-local格式
    }

    return render(request, 'checkins/direct_form.html', context)

@login_required
def debug_checkins(request):
    """调试视图：查看所有入住记录"""
    # 获取所有入住记录
    all_checkins = CheckIn.objects.all().order_by('-create_time')

    # 获取最近10条记录
    recent_checkins = all_checkins[:10]

    # 统计
    stats = {
        'total': all_checkins.count(),
        'in_house': all_checkins.filter(check_in_status='在住').count(),
        'checked_out': all_checkins.filter(check_in_status='已离店').count(),
        'today': all_checkins.filter(create_time__date=timezone.now().date()).count(),
    }

    context = {
        'all_checkins': recent_checkins,
        'stats': stats,
        'total_count': all_checkins.count(),
    }

    return render(request, 'debug_checkins.html', context)


@login_required
def checkin_detail(request, checkin_id):
    """入住详情视图"""
    # 注意：这里使用 check_in_id（数据库字段名）来查询，但参数名是 checkin_id
    checkin = get_object_or_404(CheckIn, check_in_id=checkin_id)
    bills = Bill.objects.filter(check_in=checkin).order_by('-consumption_time')

    # 账单统计
    bill_stats = bills.aggregate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
        bill_count=Count('bill_id')
    )

    # 计算已住天数
    days_stayed = (timezone.now().date() - checkin.actual_check_in.date()).days
    if days_stayed < 0:
        days_stayed = 0

    # 剩余天数
    if checkin.check_in_status == '在住':
        days_left = (checkin.expected_check_out - timezone.now().date()).days
        if days_left < 0:
            days_left = 0
    else:
        days_left = 0

    return render(request, 'checkins/detail.html', {
        'checkin': checkin,
        'bills': bills,
        'bill_stats': bill_stats,
        'days_stayed': days_stayed,
        'days_left': days_left
    })


@login_required
def checkin_checkout(request, checkin_id):
    """办理离店视图"""
    # 注意：这里使用 check_in_id（数据库字段名）来查询，但参数名是 checkin_id
    checkin = get_object_or_404(CheckIn, check_in_id=checkin_id)

    if checkin.check_in_status != '在住':
        messages.error(request, '只能为在住客人办理离店！')
        return redirect('checkin_detail', checkin_id=checkin_id)

    # 检查是否有未结账单
    unpaid_bills = Bill.objects.filter(
        check_in=checkin,
        payment_status='未结'
    )

    if unpaid_bills.exists():
        total_unpaid = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
        if total_unpaid > 0:
            messages.warning(request, f'有未结账单，总计 ¥{total_unpaid}，请先结账！')
            return redirect('checkin_bills', checkin_id=checkin_id)

    if request.method == 'POST':
        # 更新入住状态
        checkin.check_in_status = '已离店'
        checkin.actual_check_out = timezone.now()
        checkin.save()

        # 更新房间状态
        room = checkin.room
        room.status = '空闲'
        room.save()

        # 更新客户消费总额
        total_consumption = Bill.objects.filter(
            check_in=checkin,
            payment_status='已结'
        ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

        customer = checkin.customer
        customer.total_consumption += total_consumption
        customer.save()

        # 记录房态日志
        RoomStatusLog.objects.create(
            room=room,
            old_status='已入住',
            new_status='空闲',
            change_reason='客人离店',
            operator=request.user
        )

        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='入住管理',
            action='办理离店',
            target_id=checkin.check_in_id,
            description=f'为 {checkin.customer.name} 办理离店，房间 {room.room_id}',
            ip_address=get_client_ip(request)
        )

        messages.success(request, f'{checkin.customer.name} 离店办理成功！')
        return redirect('checkin_detail', checkin_id=checkin_id)

    return render(request, 'checkins/checkout_confirm.html', {'checkin': checkin})


@login_required
def checkin_extend(request, checkin_id):
    """办理续住视图"""
    # 注意：这里使用 check_in_id（数据库字段名）来查询，但参数名是 checkin_id
    checkin = get_object_or_404(CheckIn, check_in_id=checkin_id)

    if checkin.check_in_status != '在住':
        messages.error(request, '只能为在住客人办理续住！')
        return redirect('checkin_detail', checkin_id=checkin_id)

    if request.method == 'POST':
        new_checkout_date = request.POST.get('new_checkout_date')

        try:
            new_checkout_date = datetime.strptime(new_checkout_date, '%Y-%m-%d').date()

            if new_checkout_date <= checkin.expected_check_out:
                messages.error(request, '续住日期必须晚于当前离店日期！')
            else:
                # 计算续住天数
                extra_days = (new_checkout_date - checkin.expected_check_out).days

                # 更新离店日期
                old_checkout_date = checkin.expected_check_out
                checkin.expected_check_out = new_checkout_date
                checkin.check_in_status = '延期'
                checkin.save()

                # 更新客户入住天数
                customer = checkin.customer
                customer.total_stay_days += extra_days
                customer.save()

                # 创建续住房费账单
                extra_amount = extra_days * checkin.room_price
                if checkin.extra_bed:
                    extra_amount += extra_days * checkin.extra_bed_price * checkin.extra_bed_count

                Bill.objects.create(
                    check_in=checkin,
                    bill_type='房费',
                    item_name='续住房费',
                    quantity=extra_days,
                    unit_price=checkin.room_price + (
                        checkin.extra_bed_price * checkin.extra_bed_count if checkin.extra_bed else 0),
                    amount=extra_amount,
                    consumption_time=timezone.now(),
                    payment_status='未结',
                    operator=request.user
                )

                # 记录操作日志
                OperationLog.objects.create(
                    staff=request.user,
                    module='入住管理',
                    action='办理续住',
                    target_id=checkin.check_in_id,
                    description=f'为 {checkin.customer.name} 办理续住，延长 {extra_days} 天 ({old_checkout_date} → {new_checkout_date})',
                    ip_address=get_client_ip(request)
                )

                messages.success(request, f'续住办理成功！续住 {extra_days} 天')
                return redirect('checkin_detail', checkin_id=checkin_id)

        except ValueError:
            messages.error(request, '日期格式错误！')

    # 默认续住到当前离店日期+1天
    default_date = checkin.expected_check_out + timedelta(days=1)

    return render(request, 'checkins/extend_form.html', {
        'checkin': checkin,
        'default_date': default_date.strftime('%Y-%m-%d')
    })


# ==================== 账单管理模块 ====================
@login_required
def bill_list(request):
    """账单列表视图"""
    bills = Bill.objects.all().select_related(
        'check_in', 'check_in__customer', 'check_in__room', 'operator'
    ).order_by('-consumption_time')

    # 筛选条件
    payment_status = request.GET.get('payment_status')
    bill_type = request.GET.get('bill_type')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    customer_id = request.GET.get('customer_id')
    checkin_id = request.GET.get('checkin_id')

    if payment_status:
        bills = bills.filter(payment_status=payment_status)
    if bill_type:
        bills = bills.filter(bill_type=bill_type)
    if date_from:
        bills = bills.filter(consumption_time__date__gte=date_from)
    if date_to:
        bills = bills.filter(consumption_time__date__lte=date_to)
    if customer_id:
        bills = bills.filter(check_in__customer_id=customer_id)
    if checkin_id:
        bills = bills.filter(check_in__check_in_id=checkin_id)

    # 统计信息
    stats = bills.aggregate(
        total=Count('bill_id'),
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0'))
    )

    # 分页
    paginator = Paginator(bills, 20)
    page = request.GET.get('page', 1)

    try:
        bills_page = paginator.page(page)
    except PageNotAnInteger:
        bills_page = paginator.page(1)
    except EmptyPage:
        bills_page = paginator.page(paginator.num_pages)

    return render(request, 'bills/list.html', {
        'bills': bills_page,
        'stats': stats,
        'payment_status_choices': Bill.PAYMENT_STATUS_CHOICES,
        'bill_type_choices': Bill.BILL_TYPE_CHOICES,
        'current_filters': {
            'payment_status': payment_status,
            'bill_type': bill_type,
            'date_from': date_from,
            'date_to': date_to,
            'customer_id': customer_id,
            'checkin_id': checkin_id
        }
    })


@login_required
def bill_add(request):
    """添加账单视图"""
    if request.method == 'POST':
        form = BillForm(request.POST)
        if form.is_valid():
            bill = form.save(commit=False)
            bill.operator = request.user
            bill.amount = bill.quantity * bill.unit_price
            bill.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='账务管理',
                action='新增',
                target_id=bill.bill_id,
                description=f'为 {bill.check_in.customer.name} 添加 {bill.bill_type} 账单: {bill.item_name} ¥{bill.amount}',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'账单添加成功！金额: ¥{bill.amount}')
            return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)
    else:
        checkin_id = request.GET.get('checkin_id')
        initial = {}
        if checkin_id:
            try:
                # 注意：这里使用 check_in_id（数据库字段名）来查询
                checkin = CheckIn.objects.get(check_in_id=checkin_id)
                initial['check_in'] = checkin
            except CheckIn.DoesNotExist:
                pass

        form = BillForm(initial=initial)

    return render(request, 'bills/form.html', {
        'form': form,
        'title': '添加消费账单',
        'submit_text': '添加'
    })


@login_required
def bill_pay(request, bill_id):
    """支付账单视图"""
    bill = get_object_or_404(Bill, bill_id=bill_id)

    if bill.payment_status == '已结':
        messages.error(request, '账单已支付！')
        return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)

    if request.method == 'POST':
        payment_method = request.POST.get('payment_method')
        remark = request.POST.get('remark', '')

        # 更新账单状态
        old_status = bill.payment_status
        bill.payment_status = '已结'
        bill.payment_method = payment_method
        bill.payment_time = timezone.now()
        bill.remark = remark
        bill.save()

        # 记录操作日志
        OperationLog.objects.create(
            staff=request.user,
            module='账务管理',
            action='支付',
            target_id=bill.bill_id,
            description=f'支付账单 {bill_id}，金额: ¥{bill.amount}，方式: {payment_method}',
            ip_address=get_client_ip(request)
        )

        messages.success(request, f'账单支付成功！金额: ¥{bill.amount}')
        return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)

    return render(request, 'bills/pay_form.html', {
        'bill': bill,
        'payment_method_choices': Bill.PAYMENT_METHOD_CHOICES
    })


@login_required
def checkin_bills(request, checkin_id):
    """入住账单视图"""
    # 注意：这里使用 check_in_id（数据库字段名）来查询，但参数名是 checkin_id
    checkin = get_object_or_404(CheckIn, check_in_id=checkin_id)
    bills = Bill.objects.filter(check_in=checkin).order_by('-consumption_time')

    # 账单统计
    bill_stats = bills.aggregate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
        bill_count=Count('bill_id')
    )

    return render(request, 'bills/checkin_bills.html', {
        'checkin': checkin,
        'bills': bills,
        'bill_stats': bill_stats
    })



# @login_required
# def checkin_list(request):
#     """入住列表视图"""
#     checkins = CheckIn.objects.all().select_related(
#         'customer', 'room', 'operator', 'reservation'
#     ).order_by('-create_time')
#
#     # 筛选条件
#     status = request.GET.get('status')
#     date_from = request.GET.get('date_from')
#     date_to = request.GET.get('date_to')
#     customer_name = request.GET.get('customer')
#     room_id = request.GET.get('room')
#     today_only = request.GET.get('today') == '1'
#     in_house = request.GET.get('in_house') == '1'
#
#     if status:
#         checkins = checkins.filter(check_in_status=status)
#     if date_from:
#         checkins = checkins.filter(actual_check_in__date__gte=date_from)
#     if date_to:
#         checkins = checkins.filter(actual_check_in__date__lte=date_to)
#     if customer_name:
#         checkins = checkins.filter(customer__name__icontains=customer_name)
#     if room_id:
#         checkins = checkins.filter(room__room_id__icontains=room_id)
#     if today_only:
#         today = timezone.now().date()
#         checkins = checkins.filter(actual_check_in__date=today)
#     if in_house:
#         checkins = checkins.filter(check_in_status='在住')
#
#     # 统计信息
#     stats = checkins.aggregate(
#         total=Count('check_in_id'),
#         in_house=Count('check_in_id', filter=Q(check_in_status='在住')),
#         checked_out=Count('check_in_id', filter=Q(check_in_status='已离店')),
#         extended=Count('check_in_id', filter=Q(check_in_status='延期'))
#     )
#
#     # 分页
#     paginator = Paginator(checkins, 20)
#     page = request.GET.get('page', 1)
#
#     try:
#         checkins_page = paginator.page(page)
#     except PageNotAnInteger:
#         checkins_page = paginator.page(1)
#     except EmptyPage:
#         checkins_page = paginator.page(paginator.num_pages)
#
#     return render(request, 'checkins/list.html', {
#         'checkins': checkins_page,
#         'stats': stats,
#         'status_choices': CheckIn.CHECK_IN_STATUS_CHOICES,
#         'current_filters': {
#             'status': status,
#             'date_from': date_from,
#             'date_to': date_to,
#             'customer': customer_name,
#             'room': room_id,
#             'today': today_only,
#             'in_house': in_house
#         }
#     })
#
#
# @login_required
# def checkin_add(request):
#     """添加入住视图（直接入住）"""
#     if request.method == 'POST':
#         print("=" * 50)
#         print("接收到直接入住表单提交")
#         print(f"POST数据: {dict(request.POST)}")
#
#         # 特别检查关键字段
#         print(f"customer: {request.POST.get('customer')}")
#         print(f"room: {request.POST.get('room')}")
#         print(f"actual_check_in: {request.POST.get('actual_check_in')}")
#         print(f"expected_check_out: {request.POST.get('expected_check_out')}")
#
#         form = DirectCheckInForm(request.POST)
#
#         if form.is_valid():
#             print("表单验证通过")
#             checkin = form.save(commit=False)
#
#             # 获取 Staff 实例
#             try:
#                 staff_instance = request.user
#                 if not isinstance(staff_instance, Staff):
#                     staff_instance = Staff.objects.get(username=request.user.username)
#             except Staff.DoesNotExist:
#                 messages.error(request, '找不到对应的员工记录！')
#                 return redirect('checkin_list')
#
#             checkin.operator = staff_instance
#             checkin.check_in_status = '在住'  # 关键：设置入住状态
#
#             # 计算房费
#             try:
#                 days = (checkin.expected_check_out - checkin.actual_check_in.date()).days
#                 if days < 1:
#                     days = 1
#
#                 room = checkin.room
#                 room_price = room.price
#                 extra_bed_price = checkin.extra_bed_count * room.extra_bed_price if checkin.extra_bed else 0
#                 total_price = days * (room_price + extra_bed_price)
#
#                 checkin.room_price = room_price
#                 checkin.extra_bed_price = extra_bed_price if checkin.extra_bed else 0
#                 checkin.total_price = total_price
#
#                 # 保存入住记录
#                 checkin.save()
#                 print(f"入住记录保存成功！ID: {checkin.check_in_id}")
#                 print(f"   客户: {checkin.customer.name}")
#                 print(f"   房间: {checkin.room.room_id}")
#                 print(f"   状态: {checkin.check_in_status}")
#                 print(f"   总价: {total_price}")
#
#                 # 更新房间状态
#                 room.status = '已入住'
#                 room.save()
#                 print(f"房间状态更新: {room.room_id} -> 已入住")
#
#                 # 更新客户入住次数
#                 customer = checkin.customer
#                 customer.total_stay_days += days
#                 customer.last_visit_date = checkin.actual_check_in.date()
#                 customer.save()
#                 print(f"客户信息更新: {customer.name}")
#
#                 # 记录房态日志
#                 RoomStatusLog.objects.create(
#                     room=room,
#                     old_status='空闲',
#                     new_status='已入住',
#                     change_reason='直接入住',
#                     operator=staff_instance
#                 )
#
#                 # 创建房费账单
#                 Bill.objects.create(
#                     check_in=checkin,
#                     bill_type='房费',
#                     item_name=f'{room.room_type}房费',
#                     quantity=days,
#                     unit_price=room_price,
#                     amount=total_price - extra_bed_price,
#                     consumption_time=checkin.actual_check_in,
#                     payment_status='未结',
#                     operator=staff_instance
#                 )
#                 print(f"房费账单创建成功")
#
#                 # 如果有加床费
#                 if checkin.extra_bed and extra_bed_price > 0:
#                     Bill.objects.create(
#                         check_in=checkin,
#                         bill_type='房费',
#                         item_name='加床费',
#                         quantity=days * checkin.extra_bed_count,
#                         unit_price=checkin.extra_bed_price,
#                         amount=extra_bed_price,
#                         consumption_time=checkin.actual_check_in,
#                         payment_status='未结',
#                         operator=staff_instance
#                     )
#                     print(f"加床费账单创建成功")
#
#                 # 记录操作日志
#                 OperationLog.objects.create(
#                     staff=staff_instance,
#                     module='入住管理',
#                     action='直接入住',
#                     target_id=checkin.check_in_id,
#                     description=f'为 {checkin.customer.name} 办理直接入住，房间 {room.room_id}',
#                     ip_address=get_client_ip(request)
#                 )
#                 print(f"操作日志记录完成")
#
#                 messages.success(request, f'入住办理成功！入住单号: {checkin.check_in_id}')
#                 return redirect('checkin_detail', checkin_id=checkin.check_in_id)
#
#             except Exception as e:
#                 print(f"保存过程中出错: {str(e)}")
#                 import traceback
#                 traceback.print_exc()
#                 messages.error(request, f'入住办理失败: {str(e)}')
#         else:
#             print(f"表单验证失败: {form.errors}")
#             for field, errors in form.errors.items():
#                 print(f"  {field}: {errors}")
#             messages.error(request, '请检查表单填写是否正确！')
#
#     else:
#         form = DirectCheckInForm()
#         print("显示空表单")
#
#     # 获取所有可用房间（空闲状态的房间）
#     available_rooms = Room.objects.filter(status='空闲')
#
#     # 获取所有客户
#     customers = Customer.objects.all()
#
#     # 获取房间价格信息
#     rooms_price_info = {}
#     for room in available_rooms:
#         rooms_price_info[room.room_id] = {
#             'price': float(room.price),
#             'extra_bed_price': float(room.extra_bed_price),
#             'room_type': room.room_type,
#             'capacity': room.capacity
#         }
#
#     # 获取今天和明天的日期
#     today = timezone.now().date()
#     tomorrow = today + timedelta(days=1)
#
#     # 设置表单初始值
#     form.fields['actual_check_in'].initial = timezone.now()
#     form.fields['expected_check_out'].initial = tomorrow
#     form.fields['adult_count'].initial = 1
#     form.fields['child_count'].initial = 0
#
#     context = {
#         'form': form,
#         'title': '直接入住',
#         'submit_text': '办理入住',
#         'available_rooms': available_rooms,
#         'customers': customers,
#         'rooms_price_info': rooms_price_info,
#         'today': today.isoformat(),
#         'tomorrow': tomorrow.isoformat(),
#         'now': timezone.now().strftime('%Y-%m-%dT%H:%M'),  # datetime-local格式
#     }
#
#     return render(request, 'checkins/direct_form.html', context)
#
# @login_required
# def debug_checkins(request):
#     """调试视图：查看所有入住记录"""
#     # 获取所有入住记录
#     all_checkins = CheckIn.objects.all().order_by('-create_time')
#
#     # 获取最近10条记录
#     recent_checkins = all_checkins[:10]
#
#     # 统计
#     stats = {
#         'total': all_checkins.count(),
#         'in_house': all_checkins.filter(check_in_status='在住').count(),
#         'checked_out': all_checkins.filter(check_in_status='已离店').count(),
#         'today': all_checkins.filter(create_time__date=timezone.now().date()).count(),
#     }
#
#     context = {
#         'all_checkins': recent_checkins,
#         'stats': stats,
#         'total_count': all_checkins.count(),
#     }
#
#     return render(request, 'debug_checkins.html', context)
#
#
# @login_required
# def checkin_detail(request, checkin_id):
#     """入住详情视图"""
#     checkin = get_object_or_404(CheckIn, checkin_id=checkin_id)
#     bills = Bill.objects.filter(check_in=checkin).order_by('-consumption_time')
#
#     # 账单统计
#     bill_stats = bills.aggregate(
#         total_amount=Coalesce(Sum('amount'), Decimal('0')),
#         paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
#         unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
#         bill_count=Count('bill_id')
#     )
#
#     # 计算已住天数
#     days_stayed = (timezone.now().date() - checkin.actual_check_in.date()).days
#     if days_stayed < 0:
#         days_stayed = 0
#
#     # 剩余天数
#     if checkin.check_in_status == '在住':
#         days_left = (checkin.expected_check_out - timezone.now().date()).days
#         if days_left < 0:
#             days_left = 0
#     else:
#         days_left = 0
#
#     return render(request, 'checkins/detail.html', {
#         'checkin': checkin,
#         'bills': bills,
#         'bill_stats': bill_stats,
#         'days_stayed': days_stayed,
#         'days_left': days_left
#     })
#
#
# @login_required
# def checkin_checkout(request, checkin_id):
#     """办理离店视图"""
#     checkin = get_object_or_404(CheckIn, checkin_id=checkin_id)
#
#     if checkin.check_in_status != '在住':
#         messages.error(request, '只能为在住客人办理离店！')
#         return redirect('checkin_detail', checkin_id=checkin_id)
#
#     # 检查是否有未结账单
#     unpaid_bills = Bill.objects.filter(
#         check_in=checkin,
#         payment_status='未结'
#     )
#
#     if unpaid_bills.exists():
#         total_unpaid = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
#         if total_unpaid > 0:
#             messages.warning(request, f'有未结账单，总计 ¥{total_unpaid}，请先结账！')
#             return redirect('checkin_bills', checkin_id=checkin_id)
#
#     if request.method == 'POST':
#         # 更新入住状态
#         checkin.check_in_status = '已离店'
#         checkin.actual_check_out = timezone.now()
#         checkin.save()
#
#         # 更新房间状态
#         room = checkin.room
#         room.status = '空闲'
#         room.save()
#
#         # 更新客户消费总额
#         total_consumption = Bill.objects.filter(
#             check_in=checkin,
#             payment_status='已结'
#         ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
#
#         customer = checkin.customer
#         customer.total_consumption += total_consumption
#         customer.save()
#
#         # 记录房态日志
#         RoomStatusLog.objects.create(
#             room=room,
#             old_status='已入住',
#             new_status='空闲',
#             change_reason='客人离店',
#             operator=request.user
#         )
#
#         # 记录操作日志
#         OperationLog.objects.create(
#             staff=request.user,
#             module='入住管理',
#             action='办理离店',
#             target_id=checkin.check_in_id,
#             description=f'为 {checkin.customer.name} 办理离店，房间 {room.room_id}',
#             ip_address=get_client_ip(request)
#         )
#
#         messages.success(request, f'{checkin.customer.name} 离店办理成功！')
#         return redirect('checkin_detail', checkin_id=checkin_id)
#
#     return render(request, 'checkins/checkout_confirm.html', {'checkin': checkin})
#
#
# @login_required
# def checkin_extend(request, checkin_id):
#     """办理续住视图"""
#     checkin = get_object_or_404(CheckIn, checkin_id=checkin_id)
#
#     if checkin.check_in_status != '在住':
#         messages.error(request, '只能为在住客人办理续住！')
#         return redirect('checkin_detail', checkin_id=checkin_id)
#
#     if request.method == 'POST':
#         new_checkout_date = request.POST.get('new_checkout_date')
#
#         try:
#             new_checkout_date = datetime.strptime(new_checkout_date, '%Y-%m-%d').date()
#
#             if new_checkout_date <= checkin.expected_check_out:
#                 messages.error(request, '续住日期必须晚于当前离店日期！')
#             else:
#                 # 计算续住天数
#                 extra_days = (new_checkout_date - checkin.expected_check_out).days
#
#                 # 更新离店日期
#                 old_checkout_date = checkin.expected_check_out
#                 checkin.expected_check_out = new_checkout_date
#                 checkin.check_in_status = '延期'
#                 checkin.save()
#
#                 # 更新客户入住天数
#                 customer = checkin.customer
#                 customer.total_stay_days += extra_days
#                 customer.save()
#
#                 # 创建续住房费账单
#                 extra_amount = extra_days * checkin.room_price
#                 if checkin.extra_bed:
#                     extra_amount += extra_days * checkin.extra_bed_price * checkin.extra_bed_count
#
#                 Bill.objects.create(
#                     check_in=checkin,
#                     bill_type='房费',
#                     item_name='续住房费',
#                     quantity=extra_days,
#                     unit_price=checkin.room_price + (
#                         checkin.extra_bed_price * checkin.extra_bed_count if checkin.extra_bed else 0),
#                     amount=extra_amount,
#                     consumption_time=timezone.now(),
#                     payment_status='未结',
#                     operator=request.user
#                 )
#
#                 # 记录操作日志
#                 OperationLog.objects.create(
#                     staff=request.user,
#                     module='入住管理',
#                     action='办理续住',
#                     target_id=checkin.check_in_id,
#                     description=f'为 {checkin.customer.name} 办理续住，延长 {extra_days} 天 ({old_checkout_date} → {new_checkout_date})',
#                     ip_address=get_client_ip(request)
#                 )
#
#                 messages.success(request, f'续住办理成功！续住 {extra_days} 天')
#                 return redirect('checkin_detail', checkin_id=checkin_id)
#
#         except ValueError:
#             messages.error(request, '日期格式错误！')
#
#     # 默认续住到当前离店日期+1天
#     default_date = checkin.expected_check_out + timedelta(days=1)
#
#     return render(request, 'checkins/extend_form.html', {
#         'checkin': checkin,
#         'default_date': default_date.strftime('%Y-%m-%d')
#     })
#
#
# # ==================== 账单管理模块 ====================
# @login_required
# def bill_list(request):
#     """账单列表视图"""
#     bills = Bill.objects.all().select_related(
#         'check_in', 'check_in__customer', 'check_in__room', 'operator'
#     ).order_by('-consumption_time')
#
#     # 筛选条件
#     payment_status = request.GET.get('payment_status')
#     bill_type = request.GET.get('bill_type')
#     date_from = request.GET.get('date_from')
#     date_to = request.GET.get('date_to')
#     customer_id = request.GET.get('customer_id')
#     checkin_id = request.GET.get('checkin_id')
#
#     if payment_status:
#         bills = bills.filter(payment_status=payment_status)
#     if bill_type:
#         bills = bills.filter(bill_type=bill_type)
#     if date_from:
#         bills = bills.filter(consumption_time__date__gte=date_from)
#     if date_to:
#         bills = bills.filter(consumption_time__date__lte=date_to)
#     if customer_id:
#         bills = bills.filter(check_in__customer_id=customer_id)
#     if checkin_id:
#         bills = bills.filter(check_in_id=checkin_id)
#
#     # 统计信息
#     stats = bills.aggregate(
#         total=Count('bill_id'),
#         total_amount=Coalesce(Sum('amount'), Decimal('0')),
#         paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
#         unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0'))
#     )
#
#     # 分页
#     paginator = Paginator(bills, 20)
#     page = request.GET.get('page', 1)
#
#     try:
#         bills_page = paginator.page(page)
#     except PageNotAnInteger:
#         bills_page = paginator.page(1)
#     except EmptyPage:
#         bills_page = paginator.page(paginator.num_pages)
#
#     return render(request, 'bills/list.html', {
#         'bills': bills_page,
#         'stats': stats,
#         'payment_status_choices': Bill.PAYMENT_STATUS_CHOICES,
#         'bill_type_choices': Bill.BILL_TYPE_CHOICES,
#         'current_filters': {
#             'payment_status': payment_status,
#             'bill_type': bill_type,
#             'date_from': date_from,
#             'date_to': date_to,
#             'customer_id': customer_id,
#             'checkin_id': checkin_id
#         }
#     })
#
#
# @login_required
# def bill_add(request):
#     """添加账单视图"""
#     if request.method == 'POST':
#         form = BillForm(request.POST)
#         if form.is_valid():
#             bill = form.save(commit=False)
#             bill.operator = request.user
#             bill.amount = bill.quantity * bill.unit_price
#             bill.save()
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='账务管理',
#                 action='新增',
#                 target_id=bill.bill_id,
#                 description=f'为 {bill.check_in.customer.name} 添加 {bill.bill_type} 账单: {bill.item_name} ¥{bill.amount}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'账单添加成功！金额: ¥{bill.amount}')
#             return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)
#     else:
#         checkin_id = request.GET.get('checkin_id')
#         initial = {}
#         if checkin_id:
#             try:
#                 checkin = CheckIn.objects.get(checkin_id=checkin_id)
#                 initial['check_in'] = checkin
#             except CheckIn.DoesNotExist:
#                 pass
#
#         form = BillForm(initial=initial)
#
#     return render(request, 'bills/form.html', {
#         'form': form,
#         'title': '添加消费账单',
#         'submit_text': '添加'
#     })
#
#
# @login_required
# def bill_pay(request, bill_id):
#     """支付账单视图"""
#     bill = get_object_or_404(Bill, bill_id=bill_id)
#
#     if bill.payment_status == '已结':
#         messages.error(request, '账单已支付！')
#         return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)
#
#     if request.method == 'POST':
#         payment_method = request.POST.get('payment_method')
#         remark = request.POST.get('remark', '')
#
#         # 更新账单状态
#         old_status = bill.payment_status
#         bill.payment_status = '已结'
#         bill.payment_method = payment_method
#         bill.payment_time = timezone.now()
#         bill.remark = remark
#         bill.save()
#
#         # 记录操作日志
#         OperationLog.objects.create(
#             staff=request.user,
#             module='账务管理',
#             action='支付',
#             target_id=bill.bill_id,
#             description=f'支付账单 {bill_id}，金额: ¥{bill.amount}，方式: {payment_method}',
#             ip_address=get_client_ip(request)
#         )
#
#         messages.success(request, f'账单支付成功！金额: ¥{bill.amount}')
#         return redirect('checkin_bills', checkin_id=bill.check_in.check_in_id)
#
#     return render(request, 'bills/pay_form.html', {
#         'bill': bill,
#         'payment_method_choices': Bill.PAYMENT_METHOD_CHOICES
#     })
#
#
# @login_required
# def checkin_bills(request, checkin_id):
#     """入住账单视图"""
#     checkin = get_object_or_404(CheckIn, checkin_id=checkin_id)
#     bills = Bill.objects.filter(check_in=checkin).order_by('-consumption_time')
#
#     # 账单统计
#     bill_stats = bills.aggregate(
#         total_amount=Coalesce(Sum('amount'), Decimal('0')),
#         paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
#         unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
#         bill_count=Count('bill_id')
#     )
#
#     return render(request, 'bills/checkin_bills.html', {
#         'checkin': checkin,
#         'bills': bills,
#         'bill_stats': bill_stats
#     })


# ==================== 报表查询模块 ====================

@login_required
def report_room_status(request):
    """房态统计报表"""
    # 整体房态统计
    room_status = Room.objects.values('status').annotate(
        count=Count('room_id'),
        percentage=Count('room_id') * 100.0 / Room.objects.count()
    )

    # 按楼层统计
    floor_stats = Room.objects.values('floor').annotate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    ).order_by('floor')

    # 按房型统计
    type_stats = Room.objects.values('room_type').annotate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    )

    # 计算汇总值（新增代码）
    total_rooms = Room.objects.count()

    # 计算楼层统计的汇总值
    total_occupied = 0
    total_available = 0
    total_reserved = 0
    total_maintenance = 0

    for stat in floor_stats:
        total_available += stat['available']
        total_occupied += stat['occupied']
        total_reserved += stat['reserved']
        total_maintenance += stat['maintenance']

    return render(request, 'reports/room_status.html', {
        'room_status': room_status,
        'floor_stats': list(floor_stats),  # 转换为列表
        'type_stats': list(type_stats),  # 转换为列表
        'total_rooms': total_rooms,
        'total_occupied': total_occupied,
        'total_available': total_available,
        'total_reserved': total_reserved,
        'total_maintenance': total_maintenance,
        'now': timezone.now(),  # 添加当前时间
    })
# @login_required
# def report_room_status(request):
#     """房态统计报表"""
#     # 整体房态统计
#     room_status = Room.objects.values('status').annotate(
#         count=Count('room_id'),
#         percentage=Count('room_id') * 100.0 / Room.objects.count()
#     )
#
#     # 按楼层统计
#     floor_stats = Room.objects.values('floor').annotate(
#         total=Count('room_id'),
#         available=Count('room_id', filter=Q(status='空闲')),
#         occupied=Count('room_id', filter=Q(status='已入住')),
#         reserved=Count('room_id', filter=Q(status='已预订')),
#         maintenance=Count('room_id', filter=Q(status='维修中'))
#     ).order_by('floor')
#
#     # 按房型统计
#     type_stats = Room.objects.values('room_type').annotate(
#         total=Count('room_id'),
#         available=Count('room_id', filter=Q(status='空闲')),
#         occupied=Count('room_id', filter=Q(status='已入住')),
#         reserved=Count('room_id', filter=Q(status='已预订')),
#         maintenance=Count('room_id', filter=Q(status='维修中'))
#     )
#
#     return render(request, 'reports/room_status.html', {
#         'room_status': room_status,
#         'floor_stats': floor_stats,
#         'type_stats': type_stats,
#         'total_rooms': Room.objects.count(),
#     })


@login_required
def report_occupancy(request):
    """出租率报表"""
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if not start_date:
        start_date = (timezone.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = timezone.now().strftime('%Y-%m-%d')

    # 日出租率统计
    daily_occupancy = []
    current_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date()

    total_rooms = Room.objects.count()

    while current_date <= end_date_obj:
        # 计算当日在住房间数
        occupied_rooms = CheckIn.objects.filter(
            Q(actual_check_in__date__lte=current_date) &
            (
                    Q(actual_check_out__date__gt=current_date) |
                    Q(actual_check_out__isnull=True) &
                    Q(expected_check_out__gte=current_date)
            ) &
            Q(check_in_status='在住')
        ).values('room').distinct().count()

        occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0

        daily_occupancy.append({
            'date': current_date,
            'occupied_rooms': occupied_rooms,
            'total_rooms': total_rooms,
            'occupancy_rate': round(occupancy_rate, 2)
        })

        current_date += timedelta(days=1)

    # 月出租率统计
    monthly_occupancy = []
    current_month = datetime.strptime(start_date[:7] + '-01', '%Y-%m-%d').date()

    while current_month <= end_date_obj:
        next_month = (current_month.replace(day=28) + timedelta(days=4)).replace(day=1)
        month_end = next_month - timedelta(days=1)

        # 计算当月平均出租率
        month_days = []
        temp_date = current_month
        while temp_date <= month_end and temp_date <= end_date_obj:
            occupied_rooms = CheckIn.objects.filter(
                Q(actual_check_in__date__lte=temp_date) &
                (
                        Q(actual_check_out__date__gt=temp_date) |
                        Q(actual_check_out__isnull=True) &
                        Q(expected_check_out__gte=temp_date)
                ) &
                Q(check_in_status='在住')
            ).values('room').distinct().count()

            occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0
            month_days.append(occupancy_rate)

            temp_date += timedelta(days=1)

        if month_days:
            avg_occupancy = sum(month_days) / len(month_days)
            monthly_occupancy.append({
                'month': current_month.strftime('%Y-%m'),
                'avg_occupancy': round(avg_occupancy, 2)
            })

        current_month = next_month

    return render(request, 'reports/occupancy.html', {
        'start_date': start_date,
        'end_date': end_date,
        'daily_occupancy': daily_occupancy,
        'monthly_occupancy': monthly_occupancy,
        'total_rooms': total_rooms,
    })


@login_required
def report_daily_arrivals(request):
    """当日抵店客人报表"""
    today = timezone.now().date()

    # 支持日期筛选
    selected_date = request.GET.get('date')
    if selected_date:
        try:
            today = datetime.strptime(selected_date, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            today = timezone.now().date()

    # 今日预订入住
    reservation_arrivals = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')

    # 今日直接入住
    direct_arrivals = CheckIn.objects.filter(
        actual_check_in__date=today,
        reservation__isnull=True
    ).select_related('customer', 'room')

    # 统计信息
    total_arrivals = reservation_arrivals.count() + direct_arrivals.count()

    # 房间占用统计
    rooms_occupied = CheckIn.objects.filter(
        Q(actual_check_in__date__lte=today) &
        (Q(actual_check_out__date__gt=today) | Q(actual_check_out__isnull=True)) &
        Q(check_in_status='在住')
    ).count()

    # 出租率
    total_rooms = Room.objects.count()
    occupancy_rate = round((rooms_occupied / total_rooms * 100), 2) if total_rooms > 0 else 0

    return render(request, 'reports/daily_arrivals.html', {
        'today': today,
        'reservation_arrivals': reservation_arrivals,
        'direct_arrivals': direct_arrivals,
        'total_arrivals': total_arrivals,
        'rooms_occupied': rooms_occupied,
        'occupancy_rate': occupancy_rate,
        'total_rooms': total_rooms,
        'walkin_percentage': round((direct_arrivals.count() / total_arrivals * 100), 2) if total_arrivals > 0 else 0,
    })

@login_required
@require_GET
def api_today_arrivals(request):
    """当日抵店实时数据API"""
    today = timezone.now().date()

    # 支持日期筛选
    selected_date = request.GET.get('date')
    if selected_date:
        try:
            today = datetime.strptime(selected_date, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            today = timezone.now().date()

    # 今日预订入住
    reservation_arrivals = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')

    # 今日直接入住
    direct_arrivals = CheckIn.objects.filter(
        actual_check_in__date=today,
        reservation__isnull=True
    ).select_related('customer', 'room')

    # 计算房间占用
    rooms_occupied = CheckIn.objects.filter(check_in_status='在住').count()
    total_rooms = Room.objects.count()
    occupancy_rate = round((rooms_occupied / total_rooms * 100), 1) if total_rooms > 0 else 0

    # 转换为JSON格式
    reservation_data = []
    for arr in reservation_arrivals:
        reservation_data.append({
            'id': arr.reservation_id,
            'customer_name': arr.customer.name,
            'customer_phone': arr.customer.phone or '未提供',
            'room_id': arr.room.room_id,
            'room_type': arr.room.room_type,
            'expected_check_in': arr.expected_check_in.strftime('%Y-%m-%d'),
            'expected_check_out': arr.expected_check_out.strftime('%Y-%m-%d'),
            'adult_count': arr.adult_count,
            'child_count': arr.child_count,
            'extra_bed': arr.extra_bed,
            'status': arr.reservation_status,
            'total_price': float(arr.total_price),
            'checkin_url': f"/reservations/{arr.reservation_id}/checkin/"
        })

    direct_data = []
    for arr in direct_arrivals:
        direct_data.append({
            'id': arr.check_in_id,
            'customer_name': arr.customer.name,
            'customer_phone': arr.customer.phone or '未提供',
            'room_id': arr.room.room_id,
            'room_type': arr.room.room_type,
            'actual_check_in': arr.actual_check_in.strftime('%Y-%m-%d %H:%M'),
            'expected_check_out': arr.expected_check_out.strftime('%Y-%m-%d'),
            'adult_count': arr.adult_count,
            'child_count': arr.child_count,
            'status': arr.check_in_status,
            'detail_url': f"/checkins/{arr.check_in_id}/"
        })

    return JsonResponse({
        'success': True,
        'today': today.strftime('%Y-%m-%d'),
        'reservation_arrivals': reservation_data,
        'direct_arrivals': direct_data,
        'total_arrivals': reservation_arrivals.count() + direct_arrivals.count(),
        'reservation_count': reservation_arrivals.count(),
        'direct_count': direct_arrivals.count(),
        'rooms_occupied': rooms_occupied,
        'occupancy_rate': occupancy_rate,
        'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
    })
# @login_required
# @require_GET
# def api_today_arrivals(request):
#     """当日抵店实时数据API"""
#     today = timezone.now().date()
#
#     # 支持日期筛选
#     selected_date = request.GET.get('date')
#     if selected_date:
#         try:
#             today = datetime.strptime(selected_date, '%Y-%m-%d').date()
#         except (ValueError, TypeError):
#             today = timezone.now().date()
#
#     # 今日预订入住
#     reservation_arrivals = Reservation.objects.filter(
#         expected_check_in=today,
#         reservation_status='已确认'
#     ).select_related('customer', 'room')
#
#     # 今日直接入住
#     direct_arrivals = CheckIn.objects.filter(
#         actual_check_in__date=today,
#         reservation__isnull=True
#     ).select_related('customer', 'room')
#
#     # 转换为JSON格式
#     reservation_data = []
#     for arr in reservation_arrivals:
#         reservation_data.append({
#             'id': arr.reservation_id,
#             'customer_name': arr.customer.name,
#             'customer_phone': arr.customer.phone or '未提供',
#             'room_id': arr.room.room_id,
#             'room_type': arr.room.room_type,
#             'expected_check_in': arr.expected_check_in.strftime('%Y-%m-%d'),
#             'expected_check_out': arr.expected_check_out.strftime('%Y-%m-%d'),
#             'adult_count': arr.adult_count,
#             'child_count': arr.child_count,
#             'extra_bed': arr.extra_bed,
#             'status': arr.reservation_status,
#             'total_price': float(arr.total_price),
#             'checkin_url': f"/reservations/{arr.reservation_id}/checkin/"
#         })
#
#     direct_data = []
#     for arr in direct_arrivals:
#         direct_data.append({
#             'id': arr.check_in_id,
#             'customer_name': arr.customer.name,
#             'customer_phone': arr.customer.phone or '未提供',
#             'room_id': arr.room.room_id,
#             'room_type': arr.room.room_type,
#             'actual_check_in': arr.actual_check_in.strftime('%Y-%m-%d %H:%M'),
#             'expected_check_out': arr.expected_check_out.strftime('%Y-%m-%d'),
#             'adult_count': arr.adult_count,
#             'child_count': arr.child_count,
#             'status': arr.check_in_status,
#             'detail_url': f"/checkins/{arr.check_in_id}/"
#         })
#
#     return JsonResponse({
#         'success': True,
#         'today': today.strftime('%Y-%m-%d'),
#         'reservation_arrivals': reservation_data,
#         'direct_arrivals': direct_data,
#         'total_arrivals': reservation_arrivals.count() + direct_arrivals.count(),
#         'reservation_count': reservation_arrivals.count(),
#         'direct_count': direct_arrivals.count(),
#         'timestamp': timezone.now().strftime('%Y-%m-%d %H:%M:%S')
#     })


@login_required
@require_GET
def export_daily_arrivals(request):
    """导出当日抵店报表"""
    import pandas as pd
    from io import BytesIO

    today = timezone.now().date()
    selected_date = request.GET.get('date')
    if selected_date:
        try:
            today = datetime.strptime(selected_date, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            today = timezone.now().date()

    # 今日预订入住
    reservation_arrivals = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')

    # 今日直接入住
    direct_arrivals = CheckIn.objects.filter(
        actual_check_in__date=today,
        reservation__isnull=True
    ).select_related('customer', 'room')

    # 准备数据
    data = []

    # 添加预订抵店
    for arr in reservation_arrivals:
        data.append({
            '类型': '预订抵店',
            '客户姓名': arr.customer.name,
            '联系电话': arr.customer.phone or '',
            '证件号码': arr.customer.id_number or '',
            '房间号': arr.room.room_id,
            '房型': arr.room.room_type,
            '入住日期': arr.expected_check_in,
            '离店日期': arr.expected_check_out,
            '成人数': arr.adult_count,
            '儿童数': arr.child_count,
            '加床': '是' if arr.extra_bed else '否',
            '总价': float(arr.total_price),
            '订金': float(arr.deposit),
            '状态': arr.reservation_status,
        })

    # 添加直接入住
    for arr in direct_arrivals:
        data.append({
            '类型': '直接入住',
            '客户姓名': arr.customer.name,
            '联系电话': arr.customer.phone or '',
            '证件号码': arr.customer.id_number or '',
            '房间号': arr.room.room_id,
            '房型': arr.room.room_type,
            '入住时间': arr.actual_check_in.strftime('%Y-%m-%d %H:%M'),
            '离店日期': arr.expected_check_out,
            '成人数': arr.adult_count,
            '儿童数': arr.child_count,
            '加床': '是' if arr.extra_bed else '否',
            '房价': float(arr.room_price),
            '总价': float(arr.total_price),
            '状态': arr.check_in_status,
        })

    # 创建DataFrame
    df = pd.DataFrame(data)

    # 创建Excel文件
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name=f'当日抵店报表_{today}', index=False)

        # 调整列宽
        worksheet = writer.sheets[f'当日抵店报表_{today}']
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 30)
            worksheet.column_dimensions[column_letter].width = adjusted_width

    output.seek(0)

    # 创建响应
    response = HttpResponse(
        output.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="当日抵店报表_{today}.xlsx"'

    return response
# @login_required
# def export_daily_arrivals(request):
#     """导出当日抵店数据"""
#     today = timezone.now().date()
#
#     # 支持日期筛选
#     selected_date = request.GET.get('date')
#     if selected_date:
#         try:
#             today = datetime.strptime(selected_date, '%Y-%m-%d').date()
#         except (ValueError, TypeError):
#             today = timezone.now().date()
#
#     # 获取数据
#     reservation_arrivals = Reservation.objects.filter(
#         expected_check_in=today,
#         reservation_status='已确认'
#     ).select_related('customer', 'room')
#
#     direct_arrivals = CheckIn.objects.filter(
#         actual_check_in__date=today,
#         reservation__isnull=True
#     ).select_related('customer', 'room')
#
#     # 创建Excel响应
#     response = HttpResponse(content_type='application/vnd.ms-excel')
#     response['Content-Disposition'] = f'attachment; filename="当日抵店报表_{today}.xlsx"'
#
#     # 使用openpyxl创建Excel
#     try:
#         from openpyxl import Workbook
#         from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
#         from openpyxl.utils import get_column_letter
#
#         wb = Workbook()
#         ws = wb.active
#         ws.title = f"当日抵店报表_{today}"
#
#         # 标题样式
#         title_font = Font(name='Microsoft YaHei', size=16, bold=True)
#         header_font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
#         cell_font = Font(name='Microsoft YaHei', size=10)
#
#         # 边框样式
#         thin_border = Border(
#             left=Side(style='thin'),
#             right=Side(style='thin'),
#             top=Side(style='thin'),
#             bottom=Side(style='thin')
#         )
#
#         # 填充样式
#         header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
#
#         # 写入标题
#         ws.merge_cells('A1:K1')
#         ws['A1'] = f'当日抵店客人报表 - {today}'
#         ws['A1'].font = title_font
#         ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
#
#         # 写入统计信息
#         ws['A3'] = '报表统计'
#         ws['A3'].font = Font(name='Microsoft YaHei', size=12, bold=True)
#         ws['A4'] = '总抵店人数'
#         ws['B4'] = reservation_arrivals.count() + direct_arrivals.count()
#         ws['A5'] = '预订抵店'
#         ws['B5'] = reservation_arrivals.count()
#         ws['A6'] = '直接入住'
#         ws['B6'] = direct_arrivals.count()
#         ws['A7'] = '生成时间'
#         ws['B7'] = timezone.now().strftime('%Y-%m-%d %H:%M:%S')
#
#         # 写入预订抵店数据
#         ws['A9'] = '预订抵店详情'
#         ws['A9'].font = Font(name='Microsoft YaHei', size=12, bold=True)
#
#         headers = ['客户姓名', '联系电话', '房间号', '房型', '预计入住', '预计离店', '成人数', '儿童数', '是否加床',
#                    '状态', '总价']
#         for col, header in enumerate(headers, 1):
#             cell = ws.cell(row=10, column=col, value=header)
#             cell.font = header_font
#             cell.fill = header_fill
#             cell.alignment = Alignment(horizontal='center', vertical='center')
#             cell.border = thin_border
#             ws.column_dimensions[get_column_letter(col)].width = 15
#
#         for row, arrival in enumerate(reservation_arrivals, 11):
#             ws.cell(row=row, column=1, value=arrival.customer.name)
#             ws.cell(row=row, column=2, value=arrival.customer.phone or '')
#             ws.cell(row=row, column=3, value=arrival.room.room_id)
#             ws.cell(row=row, column=4, value=arrival.room.room_type)
#             ws.cell(row=row, column=5, value=arrival.expected_check_in.strftime('%Y-%m-%d'))
#             ws.cell(row=row, column=6, value=arrival.expected_check_out.strftime('%Y-%m-%d'))
#             ws.cell(row=row, column=7, value=arrival.adult_count)
#             ws.cell(row=row, column=8, value=arrival.child_count)
#             ws.cell(row=row, column=9, value='是' if arrival.extra_bed else '否')
#             ws.cell(row=row, column=10, value=arrival.reservation_status)
#             ws.cell(row=row, column=11, value=float(arrival.total_price))
#
#             for col in range(1, 12):
#                 ws.cell(row=row, column=col).font = cell_font
#                 ws.cell(row=row, column=col).border = thin_border
#
#         # 写入直接入住数据
#         start_row = row + 3
#         ws.cell(row=start_row, column=1, value='直接入住详情')
#         ws.cell(row=start_row, column=1).font = Font(name='Microsoft YaHei', size=12, bold=True)
#
#         headers2 = ['客户姓名', '联系电话', '房间号', '房型', '实际入住时间', '预计离店', '成人数', '儿童数', '状态',
#                     '入住单号']
#         for col, header in enumerate(headers2, 1):
#             cell = ws.cell(row=start_row + 1, column=col, value=header)
#             cell.font = header_font
#             cell.fill = header_fill
#             cell.alignment = Alignment(horizontal='center', vertical='center')
#             cell.border = thin_border
#             ws.column_dimensions[get_column_letter(col)].width = 15
#
#         for row_idx, arrival in enumerate(direct_arrivals, start_row + 2):
#             ws.cell(row=row_idx, column=1, value=arrival.customer.name)
#             ws.cell(row=row_idx, column=2, value=arrival.customer.phone or '')
#             ws.cell(row=row_idx, column=3, value=arrival.room.room_id)
#             ws.cell(row=row_idx, column=4, value=arrival.room.room_type)
#             ws.cell(row=row_idx, column=5, value=arrival.actual_check_in.strftime('%Y-%m-%d %H:%M'))
#             ws.cell(row=row_idx, column=6, value=arrival.expected_check_out.strftime('%Y-%m-%d'))
#             ws.cell(row=row_idx, column=7, value=arrival.adult_count)
#             ws.cell(row=row_idx, column=8, value=arrival.child_count)
#             ws.cell(row=row_idx, column=9, value=arrival.check_in_status)
#             ws.cell(row=row_idx, column=10, value=arrival.check_in_id)
#
#             for col in range(1, 11):
#                 ws.cell(row=row_idx, column=col).font = cell_font
#                 ws.cell(row=row_idx, column=col).border = thin_border
#
#         # 保存Excel
#         wb.save(response)
#
#     except ImportError:
#         # 如果openpyxl不可用，使用CSV格式
#         response = HttpResponse(content_type='text/csv')
#         response['Content-Disposition'] = f'attachment; filename="当日抵店报表_{today}.csv"'
#
#         writer = csv.writer(response)
#         writer.writerow(['当日抵店客人报表', f'日期: {today}', f'生成时间: {timezone.now()}'])
#         writer.writerow([])
#         writer.writerow(['预订抵店详情'])
#         writer.writerow(
#             ['客户姓名', '联系电话', '房间号', '房型', '预计入住', '预计离店', '成人数', '儿童数', '是否加床', '状态',
#              '总价'])
#
#         for arrival in reservation_arrivals:
#             writer.writerow([
#                 arrival.customer.name,
#                 arrival.customer.phone or '',
#                 arrival.room.room_id,
#                 arrival.room.room_type,
#                 arrival.expected_check_in.strftime('%Y-%m-%d'),
#                 arrival.expected_check_out.strftime('%Y-%m-%d'),
#                 arrival.adult_count,
#                 arrival.child_count,
#                 '是' if arrival.extra_bed else '否',
#                 arrival.reservation_status,
#                 arrival.total_price
#             ])
#
#         writer.writerow([])
#         writer.writerow(['直接入住详情'])
#         writer.writerow(
#             ['客户姓名', '联系电话', '房间号', '房型', '实际入住时间', '预计离店', '成人数', '儿童数', '状态',
#              '入住单号'])
#
#         for arrival in direct_arrivals:
#             writer.writerow([
#                 arrival.customer.name,
#                 arrival.customer.phone or '',
#                 arrival.room.room_id,
#                 arrival.room.room_type,
#                 arrival.actual_check_in.strftime('%Y-%m-%d %H:%M'),
#                 arrival.expected_check_out.strftime('%Y-%m-%d'),
#                 arrival.adult_count,
#                 arrival.child_count,
#                 arrival.check_in_status,
#                 arrival.check_in_id
#             ])
#
#     return response


# @login_required
# def report_daily_arrivals(request):
#     """当日抵店客人报表"""
#     today = timezone.now().date()
#
#     # 今日预订入住
#     reservation_arrivals = Reservation.objects.filter(
#         expected_check_in=today,
#         reservation_status='已确认'
#     ).select_related('customer', 'room')
#
#     # 今日直接入住
#     direct_arrivals = CheckIn.objects.filter(
#         actual_check_in__date=today,
#         reservation__isnull=True
#     ).select_related('customer', 'room')
#
#     # 统计信息
#     total_arrivals = reservation_arrivals.count() + direct_arrivals.count()
#
#     return render(request, 'reports/daily_arrivals.html', {
#         'today': today,
#         'reservation_arrivals': reservation_arrivals,
#         'direct_arrivals': direct_arrivals,
#         'total_arrivals': total_arrivals,
#     })


@login_required
def report_daily_departures(request):
    """当日离店客人报表"""
    today = timezone.now().date()

    # 今日预计离店
    expected_departures = CheckIn.objects.filter(
        expected_check_out=today,
        check_in_status='在住'
    ).select_related('customer', 'room')

    # 今日实际离店
    actual_departures = CheckIn.objects.filter(
        actual_check_out__date=today,
        check_in_status='已离店'
    ).select_related('customer', 'room')

    # 离店统计
    departure_stats = {
        'expected': expected_departures.count(),
        'actual': actual_departures.count(),
        'pending': expected_departures.count() - actual_departures.count()
    }

    return render(request, 'reports/daily_departures.html', {
        'today': today,
        'expected_departures': expected_departures,
        'actual_departures': actual_departures,
        'departure_stats': departure_stats,
    })


@login_required
def report_daily_arrivals(request):
    """当日抵店客人报表"""
    today = timezone.now().date()

    # 获取选择的日期
    selected_date = request.GET.get('date')
    if selected_date:
        try:
            today = datetime.strptime(selected_date, '%Y-%m-%d').date()
        except (ValueError, TypeError):
            today = timezone.now().date()

    # 今日预订入住
    reservation_arrivals = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')

    # 今日直接入住
    direct_arrivals = CheckIn.objects.filter(
        actual_check_in__date=today,
        reservation__isnull=True
    ).select_related('customer', 'room')

    # 统计信息
    reservation_count = reservation_arrivals.count()
    direct_count = direct_arrivals.count()
    total_arrivals = reservation_count + direct_count

    # 计算百分比
    if total_arrivals > 0:
        reservation_percent = round((reservation_count / total_arrivals) * 100, 1)
        direct_percent = round((direct_count / total_arrivals) * 100, 1)
    else:
        reservation_percent = 0
        direct_percent = 0

    # 计算房间占用情况
    rooms_occupied = CheckIn.objects.filter(
        check_in_status='在住'
    ).count()

    total_rooms = Room.objects.count()
    occupancy_rate = round((rooms_occupied / total_rooms * 100), 1) if total_rooms > 0 else 0

    return render(request, 'reports/daily_arrivals.html', {
        'today': today,
        'reservation_arrivals': reservation_arrivals,
        'direct_arrivals': direct_arrivals,
        'total_arrivals': total_arrivals,
        'reservation_count': reservation_count,
        'direct_count': direct_count,
        'reservation_percent': reservation_percent,
        'direct_percent': direct_percent,
        'rooms_occupied': rooms_occupied,
        'occupancy_rate': occupancy_rate,
        'total_rooms': total_rooms,
    })
@login_required
def report_revenue(request):
    """营收报表"""
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if not start_date:
        start_date = (timezone.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = timezone.now().strftime('%Y-%m-%d')

    # 日营收统计
    daily_revenue = Bill.objects.filter(
        payment_time__date__range=[start_date, end_date],
        payment_status='已结'
    ).values('payment_time__date').annotate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        bill_count=Count('bill_id')
    ).order_by('payment_time__date')

    # 按消费类型统计
    type_revenue = Bill.objects.filter(
        payment_time__date__range=[start_date, end_date],
        payment_status='已结'
    ).values('bill_type').annotate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        bill_count=Count('bill_id'),
        avg_amount=Coalesce(Avg('amount'), Decimal('0'))
    ).order_by('-total_amount')

    # 按支付方式统计
    method_revenue = Bill.objects.filter(
        payment_time__date__range=[start_date, end_date],
        payment_status='已结'
    ).values('payment_method').annotate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        bill_count=Count('bill_id')
    ).order_by('-total_amount')

    # 总统计
    total_stats = Bill.objects.filter(
        payment_time__date__range=[start_date, end_date],
        payment_status='已结'
    ).aggregate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        total_bills=Count('bill_id'),
        avg_amount=Coalesce(Avg('amount'), Decimal('0')),
        max_amount=Coalesce(Max('amount'), Decimal('0')),
        min_amount=Coalesce(Min('amount'), Decimal('0'))
    )

    # 月营收统计
    monthly_revenue = []
    current_month = datetime.strptime(start_date[:7] + '-01', '%Y-%m-%d').date()
    end_month = datetime.strptime(end_date[:7] + '-01', '%Y-%m-%d').date()

    while current_month <= end_month:
        month_str = current_month.strftime('%Y-%m')
        month_revenue = Bill.objects.filter(
            payment_time__year=current_month.year,
            payment_time__month=current_month.month,
            payment_status='已结'
        ).aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            bill_count=Count('bill_id')
        )

        monthly_revenue.append({
            'month': month_str,
            'total_amount': month_revenue['total_amount'],
            'bill_count': month_revenue['bill_count']
        })

        # 下个月
        if current_month.month == 12:
            current_month = current_month.replace(year=current_month.year + 1, month=1)
        else:
            current_month = current_month.replace(month=current_month.month + 1)

    return render(request, 'reports/revenue.html', {
        'start_date': start_date,
        'end_date': end_date,
        'daily_revenue': daily_revenue,
        'type_revenue': type_revenue,
        'method_revenue': method_revenue,
        'total_stats': total_stats,
        'monthly_revenue': monthly_revenue,
    })


@login_required
def report_billing_summary(request):
    """账单汇总报表"""
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    if not start_date:
        start_date = (timezone.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    if not end_date:
        end_date = timezone.now().strftime('%Y-%m-%d')

    # 账单汇总统计
    billing_summary = Bill.objects.filter(
        consumption_time__date__range=[start_date, end_date]
    ).values('check_in__room__room_type').annotate(
        room_type=F('check_in__room__room_type'),
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
        bill_count=Count('bill_id')
    ).order_by('-total_amount')

    # 客户消费排行
    customer_consumption = Bill.objects.filter(
        consumption_time__date__range=[start_date, end_date]
    ).values('check_in__customer__name', 'check_in__customer__customer_type').annotate(
        customer_name=F('check_in__customer__name'),
        customer_type=F('check_in__customer__customer_type'),
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        bill_count=Count('bill_id')
    ).order_by('-total_amount')[:10]

    # 账单状态统计
    billing_status = Bill.objects.filter(
        consumption_time__date__range=[start_date, end_date]
    ).values('payment_status').annotate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        bill_count=Count('bill_id')
    ).order_by('payment_status')

    # 总统计
    total_stats = Bill.objects.filter(
        consumption_time__date__range=[start_date, end_date]
    ).aggregate(
        total_amount=Coalesce(Sum('amount'), Decimal('0')),
        total_bills=Count('bill_id'),
        avg_amount=Coalesce(Avg('amount'), Decimal('0')),
        paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
        unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0'))
    )

    return render(request, 'reports/billing_summary.html', {
        'start_date': start_date,
        'end_date': end_date,
        'billing_summary': billing_summary,
        'customer_consumption': customer_consumption,
        'billing_status': billing_status,
        'total_stats': total_stats,
    })


@login_required
def report_customer_statistics(request):
    """客户统计报表"""
    # 按客户类型统计
    customer_type_stats = Customer.objects.values('customer_type').annotate(
        count=Count('customer_id'),
        total_stay_days=Coalesce(Sum('total_stay_days'), 0),
        total_consumption=Coalesce(Sum('total_consumption'), Decimal('0'))
    )

    # 处理 customer_type_stats，手动计算平均消费
    customer_type_stats_list = []
    for stat in customer_type_stats:
        stat_dict = {
            'customer_type': stat['customer_type'],
            'count': stat['count'],
            'total_stay_days': stat['total_stay_days'],
            'total_consumption': stat['total_consumption']
        }
        # 手动计算平均消费
        if stat['count'] > 0:
            stat_dict['avg_consumption'] = stat['total_consumption'] / stat['count']
        else:
            stat_dict['avg_consumption'] = Decimal('0')
        customer_type_stats_list.append(stat_dict)

    # 按会员等级统计
    member_level_stats = Customer.objects.exclude(member_level__isnull=True).values('member_level').annotate(
        count=Count('customer_id'),
        total_stay_days=Coalesce(Sum('total_stay_days'), 0),
        total_consumption=Coalesce(Sum('total_consumption'), Decimal('0'))
    )

    # 处理 member_level_stats，手动计算平均消费
    member_level_stats_list = []
    for stat in member_level_stats:
        stat_dict = {
            'member_level': stat['member_level'],
            'count': stat['count'],
            'total_stay_days': stat['total_stay_days'],
            'total_consumption': stat['total_consumption']
        }
        # 手动计算平均消费
        if stat['count'] > 0:
            stat_dict['avg_consumption'] = stat['total_consumption'] / stat['count']
        else:
            stat_dict['avg_consumption'] = Decimal('0')
        member_level_stats_list.append(stat_dict)

    # 消费排行
    top_customers = Customer.objects.order_by('-total_consumption')[:10]

    # 入住次数排行
    frequent_customers = Customer.objects.order_by('-total_stay_days')[:10]

    # 新客户统计（最近30天）
    thirty_days_ago = timezone.now() - timedelta(days=30)
    new_customers = Customer.objects.filter(
        create_time__gte=thirty_days_ago
    ).count()

    # 活跃客户统计（最近90天有入住）
    ninety_days_ago = timezone.now() - timedelta(days=90)
    active_customers = Customer.objects.filter(
        last_visit_date__gte=ninety_days_ago
    ).count()

    return render(request, 'reports/customer_statistics.html', {
        'customer_type_stats': customer_type_stats_list,  # 使用处理后的列表
        'member_level_stats': member_level_stats_list,    # 使用处理后的列表
        'top_customers': top_customers,
        'frequent_customers': frequent_customers,
        'total_customers': Customer.objects.count(),
        'new_customers': new_customers,
        'active_customers': active_customers,
        'thirty_days_ago': thirty_days_ago.date(),
        'ninety_days_ago': ninety_days_ago.date(),
    })


@login_required
def report_room_status(request):
    """房态统计报表"""
    # 整体房态统计
    room_status = Room.objects.values('status').annotate(
        count=Count('room_id'),
        percentage=Count('room_id') * 100.0 / Room.objects.count()
    )

    # 按楼层统计
    floor_stats = Room.objects.values('floor').annotate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    ).order_by('floor')

    # 计算每个楼层的百分比
    floor_stats_list = []
    for floor in floor_stats:
        total = floor['total']
        if total > 0:
            floor['available_percent'] = round(floor['available'] * 100.0 / total, 2)
            floor['occupied_percent'] = round(floor['occupied'] * 100.0 / total, 2)
            floor['reserved_percent'] = round(floor['reserved'] * 100.0 / total, 2)
            floor['maintenance_percent'] = round(floor['maintenance'] * 100.0 / total, 2)
            floor['occupancy_rate'] = round(floor['occupied'] * 100.0 / total, 2)
        else:
            floor['available_percent'] = 0
            floor['occupied_percent'] = 0
            floor['reserved_percent'] = 0
            floor['maintenance_percent'] = 0
            floor['occupancy_rate'] = 0
        floor_stats_list.append(floor)

    # 按房型统计
    type_stats = Room.objects.values('room_type').annotate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    )

    # 计算每个房型的百分比
    type_stats_list = []
    for room_type in type_stats:
        total = room_type['total']
        if total > 0:
            room_type['available_percent'] = round(room_type['available'] * 100.0 / total, 2)
            room_type['occupied_percent'] = round(room_type['occupied'] * 100.0 / total, 2)
            room_type['reserved_percent'] = round(room_type['reserved'] * 100.0 / total, 2)
            room_type['maintenance_percent'] = round(room_type['maintenance'] * 100.0 / total, 2)
        else:
            room_type['available_percent'] = 0
            room_type['occupied_percent'] = 0
            room_type['reserved_percent'] = 0
            room_type['maintenance_percent'] = 0
        type_stats_list.append(room_type)

    # 计算汇总值
    total_rooms = Room.objects.count()
    total_occupied = Room.objects.filter(status='已入住').count()
    total_available = Room.objects.filter(status='空闲').count()
    total_reserved = Room.objects.filter(status='已预订').count()
    total_maintenance = Room.objects.filter(status='维修中').count()

    # 整体百分比
    if total_rooms > 0:
        total_available_percent = round(total_available * 100.0 / total_rooms, 2)
        total_occupied_percent = round(total_occupied * 100.0 / total_rooms, 2)
        total_reserved_percent = round(total_reserved * 100.0 / total_rooms, 2)
        total_maintenance_percent = round(total_maintenance * 100.0 / total_rooms, 2)
        overall_occupancy_rate = round(total_occupied * 100.0 / total_rooms, 2)
        # 可用率 = 空闲房间数 / 总房间数
        total_available_rate = round(total_available * 100.0 / total_rooms, 2)
    else:
        total_available_percent = 0
        total_occupied_percent = 0
        total_reserved_percent = 0
        total_maintenance_percent = 0
        overall_occupancy_rate = 0
        total_available_rate = 0

    return render(request, 'reports/room_status.html', {
        'room_status': room_status,
        'floor_stats': floor_stats_list,
        'type_stats': type_stats_list,
        'total_rooms': total_rooms,
        'total_available': total_available,
        'total_occupied': total_occupied,
        'total_reserved': total_reserved,
        'total_maintenance': total_maintenance,
        'total_available_percent': total_available_percent,
        'total_occupied_percent': total_occupied_percent,
        'total_reserved_percent': total_reserved_percent,
        'total_maintenance_percent': total_maintenance_percent,
        'overall_occupancy_rate': overall_occupancy_rate,
        'total_available_rate': total_available_rate,  # 新增：可用率
        'now': timezone.now(),
    })


# ==================== 实时查询模块 ====================

@login_required
def live_room_status(request):
    """实时房态显示"""
    rooms = Room.objects.all().order_by('floor', 'room_id')

    # 按楼层分组，并计算每个楼层的统计信息
    floors = {}
    for room in rooms:
        floor = room.floor
        if floor not in floors:
            floors[floor] = {
                'rooms': [],  # 房间列表
                'stats': {  # 楼层统计信息
                    'total': 0,
                    'available': 0,
                    'occupied': 0,
                    'reserved': 0,
                    'maintenance': 0
                }
            }
        floors[floor]['rooms'].append(room)

        # 更新楼层统计信息
        floors[floor]['stats']['total'] += 1
        if room.status == '空闲':
            floors[floor]['stats']['available'] += 1
        elif room.status == '已入住':
            floors[floor]['stats']['occupied'] += 1
        elif room.status == '已预订':
            floors[floor]['stats']['reserved'] += 1
        elif room.status == '维修中':
            floors[floor]['stats']['maintenance'] += 1

    # 整体房态统计
    room_stats = {
        'total': rooms.count(),
        'available': rooms.filter(status='空闲').count(),
        'occupied': rooms.filter(status='已入住').count(),
        'reserved': rooms.filter(status='已预订').count(),
        'maintenance': rooms.filter(status='维修中').count(),
    }

    return render(request, 'live/room_status.html', {
        'floors': dict(sorted(floors.items())),
        'room_stats': room_stats,
    })


@login_required
def live_guests_in_house(request):
    """在住客人清单"""
    guests = CheckIn.objects.filter(
        check_in_status='在住'
    ).select_related('customer', 'room').order_by('room__floor', 'room__room_id')

    # 统计信息
    guest_stats = {
        'total': guests.count(),
        'by_room_type': guests.values('room__room_type').annotate(
            count=Count('check_in_id')
        ),
        'by_floor': guests.values('room__floor').annotate(
            count=Count('check_in_id')
        ).order_by('room__floor')
    }

    return render(request, 'live/guests_in_house.html', {
        'guests': guests,
        'guest_stats': guest_stats,
    })


@login_required
def live_expected_departures(request):
    """预计离店清单"""
    today = timezone.now().date()

    # 今日预计离店
    today_departures = CheckIn.objects.filter(
        expected_check_out=today,
        check_in_status='在住'
    ).select_related('customer', 'room')

    # 明日预计离店
    tomorrow = today + timedelta(days=1)
    tomorrow_departures = CheckIn.objects.filter(
        expected_check_out=tomorrow,
        check_in_status='在住'
    ).select_related('customer', 'room')

    # 未来3天预计离店
    future_date = today + timedelta(days=3)
    future_departures = CheckIn.objects.filter(
        expected_check_out__range=[tomorrow + timedelta(days=1), future_date],
        check_in_status='在住'
    ).select_related('customer', 'room')

    # 统计信息
    departure_stats = {
        'today': today_departures.count(),
        'tomorrow': tomorrow_departures.count(),
        'future': future_departures.count(),
        'total': today_departures.count() + tomorrow_departures.count() + future_departures.count()
    }

    return render(request, 'live/expected_departures.html', {
        'today': today,
        'tomorrow': tomorrow,
        'today_departures': today_departures,
        'tomorrow_departures': tomorrow_departures,
        'future_departures': future_departures,
        'departure_stats': departure_stats,
    })


@login_required
def live_today_summary(request):
    """今日摘要"""
    today = timezone.now().date()

    # 今日入住
    today_checkins = CheckIn.objects.filter(
        actual_check_in__date=today
    ).select_related('customer', 'room')

    # 今日离店
    today_checkouts = CheckIn.objects.filter(
        actual_check_out__date=today,
        check_in_status='已离店'
    ).select_related('customer', 'room')

    # 今日预订
    today_reservations = Reservation.objects.filter(
        expected_check_in=today,
        reservation_status='已确认'
    ).select_related('customer', 'room')

    # 今日营收
    today_revenue = Bill.objects.filter(
        payment_time__date=today,
        payment_status='已结'
    ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

    # 今日新增客户
    today_customers = Customer.objects.filter(
        create_time__date=today
    ).count()

    # 当前在住
    current_guests = CheckIn.objects.filter(
        check_in_status='在住'
    ).count()

    # 可用房间
    available_rooms = Room.objects.filter(status='空闲').count()

    return render(request, 'live/today_summary.html', {
        'today': today,
        'today_checkins': today_checkins,
        'today_checkouts': today_checkouts,
        'today_reservations': today_reservations,
        'today_revenue': today_revenue,
        'today_customers': today_customers,
        'current_guests': current_guests,
        'available_rooms': available_rooms,
        'total_rooms': Room.objects.count(),
    })


# ==================== 综合查询模块 ====================
@login_required
def query_room_availability(request):
    """客房可用性查询"""
    if request.method == 'GET':
        checkin_date = request.GET.get('checkin_date')
        checkout_date = request.GET.get('checkout_date')
        room_type = request.GET.get('room_type')
        floor = request.GET.get('floor')

        available_rooms = Room.objects.filter(status='空闲')

        if checkin_date and checkout_date:
            try:
                checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
                checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

                # 查找被占用的房间
                occupied_rooms = CheckIn.objects.filter(
                    Q(actual_check_in__date__lt=checkout_date) &
                    (
                            Q(actual_check_out__date__gt=checkin_date) |
                            Q(actual_check_out__isnull=True) &
                            Q(expected_check_out__gte=checkin_date)
                    ) &
                    Q(check_in_status='在住')
                ).values_list('room_id', flat=True)

                # 查找被预订的房间
                reserved_rooms = Reservation.objects.filter(
                    Q(expected_check_in__lt=checkout_date) &
                    Q(expected_check_out__gt=checkin_date) &
                    Q(reservation_status='已确认')
                ).values_list('room_id', flat=True)

                # 排除不可用的房间
                unavailable_rooms = set(list(occupied_rooms) + list(reserved_rooms))
                available_rooms = available_rooms.exclude(room_id__in=unavailable_rooms)

            except ValueError:
                messages.error(request, '日期格式错误！')

        if room_type:
            available_rooms = available_rooms.filter(room_type=room_type)

        if floor:
            available_rooms = available_rooms.filter(floor=floor)

        # 获取筛选选项
        room_types = Room.objects.values_list('room_type', flat=True).distinct()
        floors = Room.objects.values_list('floor', flat=True).distinct().order_by('floor')

        return render(request, 'query/room_availability.html', {
            'available_rooms': available_rooms,
            'room_types': room_types,
            'floors': floors,
            'checkin_date': checkin_date,
            'checkout_date': checkout_date,
            'selected_room_type': room_type,
            'selected_floor': floor,
        })

    return render(request, 'query/room_availability.html')


@login_required
def query_guest_history(request):
    """客人历史查询"""
    if request.method == 'GET':
        customer_id = request.GET.get('customer_id')
        phone = request.GET.get('phone')
        id_number = request.GET.get('id_number')
        name = request.GET.get('name')

        checkins = CheckIn.objects.all().select_related('customer', 'room')

        if customer_id:
            checkins = checkins.filter(customer_id=customer_id)
        if phone:
            checkins = checkins.filter(customer__phone__icontains=phone)
        if id_number:
            checkins = checkins.filter(customer__id_number__icontains=id_number)
        if name:
            checkins = checkins.filter(customer__name__icontains=name)

        # 统计信息
        if checkins.exists():
            stats = checkins.aggregate(
                total_stays=Count('check_in_id'),
                total_days=Coalesce(Sum(
                    Case(
                        When(
                            actual_check_out__isnull=False,
                            then=F('expected_check_out') - F('actual_check_in__date')
                        ),
                        default=Value(0),
                        output_field=IntegerField()
                    )
                ), 0),
                total_consumption=Coalesce(Sum(
                    Bill.objects.filter(check_in__in=checkins, payment_status='已结').values('amount')
                ), Decimal('0'))
            )
        else:
            stats = None

        return render(request, 'query/guest_history.html', {
            'checkins': checkins,
            'stats': stats,
            'customer_id': customer_id,
            'phone': phone,
            'id_number': id_number,
            'name': name,
        })

    return render(request, 'query/guest_history.html')


@login_required
def query_billing_details(request):
    """账单明细查询"""
    if request.method == 'GET':
        customer_id = request.GET.get('customer_id')
        checkin_id = request.GET.get('checkin_id')
        bill_type = request.GET.get('bill_type')
        payment_status = request.GET.get('payment_status')
        date_from = request.GET.get('date_from')
        date_to = request.GET.get('date_to')

        bills = Bill.objects.all().select_related(
            'check_in', 'check_in__customer', 'check_in__room'
        )

        if customer_id:
            bills = bills.filter(check_in__customer_id=customer_id)
        if checkin_id:
            bills = bills.filter(check_in_id=checkin_id)
        if bill_type:
            bills = bills.filter(bill_type=bill_type)
        if payment_status:
            bills = bills.filter(payment_status=payment_status)
        if date_from:
            bills = bills.filter(consumption_time__date__gte=date_from)
        if date_to:
            bills = bills.filter(consumption_time__date__lte=date_to)

        # 统计信息
        stats = bills.aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
            unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
            bill_count=Count('bill_id')
        )

        return render(request, 'query/billing_details.html', {
            'bills': bills,
            'stats': stats,
            'bill_type_choices': Bill.BILL_TYPE_CHOICES,
            'payment_status_choices': Bill.PAYMENT_STATUS_CHOICES,
            'customer_id': customer_id,
            'checkin_id': checkin_id,
            'bill_type': bill_type,
            'payment_status': payment_status,
            'date_from': date_from,
            'date_to': date_to,
        })

    return render(request, 'query/billing_details.html')


@login_required
def query_reservation_status(request):
    """预订状态查询"""
    if request.method == 'GET':
        reservation_id = request.GET.get('reservation_id')
        customer_id = request.GET.get('customer_id')
        phone = request.GET.get('phone')
        status = request.GET.get('status')

        reservations = Reservation.objects.all().select_related('customer', 'room')

        if reservation_id:
            reservations = reservations.filter(reservation_id=reservation_id)
        if customer_id:
            reservations = reservations.filter(customer_id=customer_id)
        if phone:
            reservations = reservations.filter(customer__phone__icontains=phone)
        if status:
            reservations = reservations.filter(reservation_status=status)

        return render(request, 'query/reservation_status.html', {
            'reservations': reservations,
            'status_choices': Reservation.RESERVATION_STATUS_CHOICES,
            'reservation_id': reservation_id,
            'customer_id': customer_id,
            'phone': phone,
            'status': status,
        })

    return render(request, 'query/reservation_status.html')


# ==================== API接口 ====================
@login_required
@require_GET
def api_available_rooms(request):
    """获取可用房间API"""
    checkin_date = request.GET.get('checkin_date')
    checkout_date = request.GET.get('checkout_date')
    room_type = request.GET.get('room_type')

    try:
        if not checkin_date or not checkout_date:
            return JsonResponse({'success': False, 'error': '缺少日期参数'})

        checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

        if checkin_date >= checkout_date:
            return JsonResponse({'success': False, 'error': '离店日期必须晚于入住日期'})

        # 查找被占用的房间
        occupied_rooms = CheckIn.objects.filter(
            Q(actual_check_in__date__lt=checkout_date) &
            (
                    Q(actual_check_out__date__gt=checkin_date) |
                    Q(actual_check_out__isnull=True) &
                    Q(expected_check_out__gte=checkin_date)
            ) &
            Q(check_in_status='在住')
        ).values_list('room_id', flat=True)

        # 查找被预订的房间
        reserved_rooms = Reservation.objects.filter(
            Q(expected_check_in__lt=checkout_date) &
            Q(expected_check_out__gt=checkin_date) &
            Q(reservation_status='已确认')
        ).values_list('room_id', flat=True)

        # 排除不可用的房间
        unavailable_rooms = set(list(occupied_rooms) + list(reserved_rooms))

        # 查询可用房间
        available_rooms = Room.objects.filter(
            status='空闲'
        ).exclude(
            room_id__in=unavailable_rooms
        )

        if room_type:
            available_rooms = available_rooms.filter(room_type=room_type)

        results = []
        for room in available_rooms:
            results.append({
                'room_id': room.room_id,
                'room_type': room.room_type,
                'floor': room.floor,
                'price': str(room.price),
                'capacity': room.capacity,
                'extra_bed': room.extra_bed,
                'extra_bed_price': str(room.extra_bed_price) if room.extra_bed else '0',
                'description': room.description,
            })

        return JsonResponse({'success': True, 'rooms': results})

    except ValueError as e:
        return JsonResponse({'success': False, 'error': f'日期格式错误: {str(e)}'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_room_status(request, room_id):
    """获取房间状态API"""
    try:
        room = Room.objects.get(room_id=room_id)

        # 获取当前入住信息
        current_checkin = CheckIn.objects.filter(
            room=room,
            check_in_status='在住'
        ).first()

        checkin_info = None
        if current_checkin:
            checkin_info = {
                'checkin_id': current_checkin.check_in_id,
                'customer_name': current_checkin.customer.name,
                'customer_id': current_checkin.customer.customer_id,
                'checkin_date': current_checkin.actual_check_in.strftime('%Y-%m-%d'),
                'checkout_date': current_checkin.expected_check_out.strftime('%Y-%m-%d'),
                'days_stayed': (timezone.now().date() - current_checkin.actual_check_in.date()).days
            }

        # 获取即将到来的预订
        upcoming_reservation = Reservation.objects.filter(
            room=room,
            expected_check_in__gte=date.today(),
            reservation_status='已确认'
        ).order_by('expected_check_in').first()

        reservation_info = None
        if upcoming_reservation:
            reservation_info = {
                'reservation_id': upcoming_reservation.reservation_id,
                'customer_name': upcoming_reservation.customer.name,
                'checkin_date': upcoming_reservation.expected_check_in.strftime('%Y-%m-%d'),
                'checkout_date': upcoming_reservation.expected_check_out.strftime('%Y-%m-%d'),
            }

        return JsonResponse({
            'success': True,
            'room_id': room.room_id,
            'room_type': room.room_type,
            'floor': room.floor,
            'status': room.status,
            'status_display': room.get_status_display(),
            'price': str(room.price),
            'capacity': room.capacity,
            'current_checkin': checkin_info,
            'upcoming_reservation': reservation_info,
        })

    except Room.DoesNotExist:
        return JsonResponse({'success': False, 'error': '房间不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_POST
def api_update_room_status(request):
    """更新房态API"""
    try:
        data = json.loads(request.body)
        room_id = data.get('room_id')
        new_status = data.get('status')
        reason = data.get('reason', '手动更新')

        if not room_id or not new_status:
            return JsonResponse({'success': False, 'error': '缺少必要参数'})

        room = Room.objects.get(room_id=room_id)
        old_status = room.status

        # 验证状态转换
        if not is_valid_status_transition(old_status, new_status):
            return JsonResponse({'success': False, 'error': f'无效的状态转换: {old_status} -> {new_status}'})

        # 更新房态
        room.status = new_status
        room.save()

        # 记录房态日志
        RoomStatusLog.objects.create(
            room=room,
            old_status=old_status,
            new_status=new_status,
            change_reason=reason,
            operator=request.user
        )

        return JsonResponse({
            'success': True,
            'room_id': room_id,
            'old_status': old_status,
            'new_status': new_status,
            'status_display': room.get_status_display()
        })

    except Room.DoesNotExist:
        return JsonResponse({'success': False, 'error': '房间不存在'})
    except json.JSONDecodeError:
        return JsonResponse({'success': False, 'error': 'JSON解析错误'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_customer_info(request, customer_id):
    """获取客户信息API"""
    try:
        customer = Customer.objects.get(customer_id=customer_id)

        # 获取最近入住记录
        recent_checkins = CheckIn.objects.filter(
            customer=customer
        ).order_by('-actual_check_in')[:3]

        checkin_history = []
        for checkin in recent_checkins:
            checkin_history.append({
                'checkin_id': checkin.check_in_id,
                'room_id': checkin.room.room_id,
                'checkin_date': checkin.actual_check_in.strftime('%Y-%m-%d'),
                'checkout_date': checkin.expected_check_out.strftime('%Y-%m-%d'),
                'status': checkin.check_in_status
            })

        return JsonResponse({
            'success': True,
            'customer_id': customer.customer_id,
            'name': customer.name,
            'phone': customer.phone,
            'email': customer.email,
            'customer_type': customer.customer_type,
            'member_level': customer.member_level,
            'member_id': customer.member_id,
            'total_stay_days': customer.total_stay_days,
            'total_consumption': str(customer.total_consumption),
            'last_visit_date': customer.last_visit_date.strftime('%Y-%m-%d') if customer.last_visit_date else None,
            'checkin_history': checkin_history
        })

    except Customer.DoesNotExist:
        return JsonResponse({'success': False, 'error': '客户不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_search_customers(request):
    """搜索客户API"""
    try:
        query = request.GET.get('q', '')
        limit = int(request.GET.get('limit', 10))

        if not query or len(query) < 2:
            return JsonResponse({'success': True, 'results': []})

        customers = Customer.objects.filter(
            Q(name__icontains=query) |
            Q(phone__icontains=query) |
            Q(member_id__icontains=query) |
            Q(id_number__icontains=query)
        ).order_by('name')[:limit]

        results = []
        for customer in customers:
            results.append({
                'id': customer.customer_id,
                'name': customer.name,
                'phone': customer.phone,
                'member_id': customer.member_id,
                'customer_type': customer.customer_type,
                'member_level': customer.member_level,
                'text': f"{customer.name} ({customer.phone}) - {customer.customer_type}"
            })

        return JsonResponse({'success': True, 'results': results})

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_customer_history(request, customer_id):
    """客户历史API"""
    try:
        customer = Customer.objects.get(customer_id=customer_id)

        # 入住历史
        checkins = CheckIn.objects.filter(
            customer=customer
        ).select_related('room').order_by('-actual_check_in')

        checkin_history = []
        for checkin in checkins:
            bills = Bill.objects.filter(check_in=checkin).aggregate(
                total=Coalesce(Sum('amount'), Decimal('0'))
            )

            checkin_history.append({
                'checkin_id': checkin.check_in_id,
                'room_id': checkin.room.room_id,
                'room_type': checkin.room.room_type,
                'checkin_date': checkin.actual_check_in.strftime('%Y-%m-%d'),
                'checkout_date': checkin.expected_check_out.strftime('%Y-%m-%d'),
                'actual_checkout_date': checkin.actual_check_out.strftime(
                    '%Y-%m-%d') if checkin.actual_check_out else None,
                'status': checkin.check_in_status,
                'total_price': str(checkin.total_price),
                'total_bills': str(bills['total']),
                'days': (checkin.expected_check_out - checkin.actual_check_in.date()).days
            })

        # 预订历史
        reservations = Reservation.objects.filter(
            customer=customer
        ).select_related('room').order_by('-create_time')

        reservation_history = []
        for reservation in reservations:
            reservation_history.append({
                'reservation_id': reservation.reservation_id,
                'room_id': reservation.room.room_id,
                'room_type': reservation.room.room_type,
                'checkin_date': reservation.expected_check_in.strftime('%Y-%m-%d'),
                'checkout_date': reservation.expected_check_out.strftime('%Y-%m-%d'),
                'status': reservation.reservation_status,
                'total_price': str(reservation.total_price),
                'create_time': reservation.create_time.strftime('%Y-%m-%d %H:%M')
            })

        return JsonResponse({
            'success': True,
            'customer': {
                'id': customer.customer_id,
                'name': customer.name,
                'phone': customer.phone,
                'customer_type': customer.customer_type,
                'member_level': customer.member_level
            },
            'checkin_history': checkin_history,
            'reservation_history': reservation_history,
            'total_checkins': checkins.count(),
            'total_reservations': reservations.count()
        })

    except Customer.DoesNotExist:
        return JsonResponse({'success': False, 'error': '客户不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_check_reservation(request):
    """检查预订API"""
    try:
        reservation_id = request.GET.get('reservation_id')
        phone = request.GET.get('phone')

        if not reservation_id and not phone:
            return JsonResponse({'success': False, 'error': '请提供预订号或手机号'})

        reservations = Reservation.objects.all().select_related('customer', 'room')

        if reservation_id:
            reservations = reservations.filter(reservation_id=reservation_id)
        if phone:
            reservations = reservations.filter(customer__phone=phone)

        results = []
        for reservation in reservations:
            results.append({
                'reservation_id': reservation.reservation_id,
                'customer_name': reservation.customer.name,
                'customer_phone': reservation.customer.phone,
                'room_id': reservation.room.room_id,
                'room_type': reservation.room.room_type,
                'checkin_date': reservation.expected_check_in.strftime('%Y-%m-%d'),
                'checkout_date': reservation.expected_check_out.strftime('%Y-%m-%d'),
                'status': reservation.reservation_status,
                'status_display': reservation.get_reservation_status_display(),
                'total_price': str(reservation.total_price),
                'create_time': reservation.create_time.strftime('%Y-%m-%d %H:%M')
            })

        return JsonResponse({'success': True, 'reservations': results})

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_reservation_details(request, reservation_id):
    """预订详情API"""
    try:
        reservation = Reservation.objects.get(reservation_id=reservation_id)

        # 检查是否有入住记录
        checkin_record = CheckIn.objects.filter(reservation=reservation).first()

        return JsonResponse({
            'success': True,
            'reservation_id': reservation.reservation_id,
            'customer_id': reservation.customer.customer_id,
            'customer_name': reservation.customer.name,
            'customer_phone': reservation.customer.phone,
            'room_id': reservation.room.room_id,
            'room_type': reservation.room.room_type,
            'checkin_date': reservation.expected_check_in.strftime('%Y-%m-%d'),
            'checkout_date': reservation.expected_check_out.strftime('%Y-%m-%d'),
            'adult_count': reservation.adult_count,
            'child_count': reservation.child_count,
            'extra_bed': reservation.extra_bed,
            'status': reservation.reservation_status,
            'status_display': reservation.get_reservation_status_display(),
            'total_price': str(reservation.total_price),
            'deposit': str(reservation.deposit),
            'payment_method': reservation.payment_method,
            'source': reservation.source,
            'remark': reservation.remark,
            'create_time': reservation.create_time.strftime('%Y-%m-%d %H:%M'),
            'checkin_record': {
                'checkin_id': checkin_record.check_in_id,
                'actual_checkin': checkin_record.actual_check_in.strftime('%Y-%m-%d %H:%M') if checkin_record else None,
                'status': checkin_record.check_in_status if checkin_record else None
            } if checkin_record else None
        })

    except Reservation.DoesNotExist:
        return JsonResponse({'success': False, 'error': '预订不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_checkin_details(request, checkin_id):
    """入住详情API"""
    try:
        checkin = CheckIn.objects.get(checkin_id=checkin_id)

        # 获取账单
        bills = Bill.objects.filter(check_in=checkin)

        bill_list = []
        for bill in bills:
            bill_list.append({
                'bill_id': bill.bill_id,
                'bill_type': bill.bill_type,
                'item_name': bill.item_name,
                'quantity': bill.quantity,
                'unit_price': str(bill.unit_price),
                'amount': str(bill.amount),
                'payment_status': bill.payment_status,
                'payment_method': bill.payment_method,
                'consumption_time': bill.consumption_time.strftime('%Y-%m-%d %H:%M')
            })

        # 账单统计
        bill_stats = bills.aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
            unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0'))
        )

        return JsonResponse({
            'success': True,
            'checkin_id': checkin.check_in_id,
            'customer_id': checkin.customer.customer_id,
            'customer_name': checkin.customer.name,
            'room_id': checkin.room.room_id,
            'room_type': checkin.room.room_type,
            'checkin_date': checkin.actual_check_in.strftime('%Y-%m-%d %H:%M'),
            'expected_checkout': checkin.expected_check_out.strftime('%Y-%m-%d'),
            'actual_checkout': checkin.actual_check_out.strftime(
                '%Y-%m-%d %H:%M') if checkin.actual_check_out else None,
            'adult_count': checkin.adult_count,
            'child_count': checkin.child_count,
            'extra_bed': checkin.extra_bed,
            'extra_bed_count': checkin.extra_bed_count,
            'status': checkin.check_in_status,
            'status_display': checkin.get_check_in_status_display(),
            'room_price': str(checkin.room_price),
            'extra_bed_price': str(checkin.extra_bed_price),
            'total_price': str(checkin.total_price),
            'payment_method': checkin.payment_method,
            'remark': checkin.remark,
            'create_time': checkin.create_time.strftime('%Y-%m-%d %H:%M'),
            'bills': bill_list,
            'bill_stats': bill_stats
        })

    except CheckIn.DoesNotExist:
        return JsonResponse({'success': False, 'error': '入住记录不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_guest_bills(request, checkin_id):
    """客人账单API"""
    try:
        checkin = CheckIn.objects.get(checkin_id=checkin_id)
        bills = Bill.objects.filter(check_in=checkin).order_by('-consumption_time')

        bill_list = []
        for bill in bills:
            bill_list.append({
                'bill_id': bill.bill_id,
                'bill_type': bill.bill_type,
                'item_name': bill.item_name,
                'quantity': bill.quantity,
                'unit_price': str(bill.unit_price),
                'amount': str(bill.amount),
                'payment_status': bill.payment_status,
                'payment_status_display': bill.get_payment_status_display(),
                'payment_method': bill.payment_method,
                'consumption_time': bill.consumption_time.strftime('%Y-%m-%d %H:%M'),
                'payment_time': bill.payment_time.strftime('%Y-%m-%d %H:%M') if bill.payment_time else None,
                'remark': bill.remark
            })

        # 账单统计
        bill_stats = bills.aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
            unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0')),
            bill_count=Count('bill_id')
        )

        return JsonResponse({
            'success': True,
            'checkin_id': checkin.check_in_id,
            'customer_name': checkin.customer.name,
            'room_id': checkin.room.room_id,
            'bills': bill_list,
            'bill_stats': bill_stats
        })

    except CheckIn.DoesNotExist:
        return JsonResponse({'success': False, 'error': '入住记录不存在'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_dashboard_stats(request):
    """仪表板统计API"""
    try:
        today = timezone.now().date()

        # 房态统计
        room_stats = Room.objects.aggregate(
            total=Count('room_id'),
            available=Count('room_id', filter=Q(status='空闲')),
            occupied=Count('room_id', filter=Q(status='已入住')),
            reserved=Count('room_id', filter=Q(status='已预订')),
            maintenance=Count('room_id', filter=Q(status='维修中'))
        )

        # 今日统计
        today_stats = {
            'checkins': CheckIn.objects.filter(actual_check_in__date=today).count(),
            'checkouts': CheckIn.objects.filter(actual_check_out__date=today, check_in_status='已离店').count(),
            'reservations': Reservation.objects.filter(expected_check_in=today, reservation_status='已确认').count(),
            'guests_in_house': CheckIn.objects.filter(check_in_status='在住').count(),
            'revenue': Bill.objects.filter(payment_time__date=today, payment_status='已结').aggregate(
                total=Coalesce(Sum('amount'), Decimal('0'))
            )['total'],
            'unpaid_bills': Bill.objects.filter(payment_status='未结').aggregate(
                total=Coalesce(Sum('amount'), Decimal('0'))
            )['total']
        }

        # 即将离店（今天和明天）
        upcoming_checkouts = CheckIn.objects.filter(
            expected_check_out__lte=today + timedelta(days=1),
            check_in_status='在住'
        ).count()

        # 今日抵达
        today_arrivals = Reservation.objects.filter(
            expected_check_in=today,
            reservation_status='已确认'
        ).count()

        return JsonResponse({
            'success': True,
            'today': today.strftime('%Y-%m-%d'),
            'room_stats': room_stats,
            'today_stats': today_stats,
            'upcoming_checkouts': upcoming_checkouts,
            'today_arrivals': today_arrivals
        })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_revenue_chart(request):
    """营收图表API"""
    try:
        days = int(request.GET.get('days', 30))
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=days - 1)

        revenue_data = []
        for i in range(days):
            current_date = start_date + timedelta(days=i)
            day_revenue = Bill.objects.filter(
                payment_time__date=current_date,
                payment_status='已结'
            ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

            revenue_data.append({
                'date': current_date.strftime('%m-%d'),
                'revenue': float(day_revenue)
            })

        # 月度营收
        monthly_revenue = []
        current_month = datetime(end_date.year, end_date.month, 1).date()

        for i in range(6):
            month = current_month - timedelta(days=current_month.day - 1)
            month_start = month.replace(day=1)
            if i > 0:
                month_start = month_start.replace(day=1) - timedelta(days=1)
                month_start = month_start.replace(day=1)

            month_end = month_start.replace(day=28) + timedelta(days=4)
            month_end = month_end.replace(day=1) - timedelta(days=1)

            month_revenue = Bill.objects.filter(
                payment_time__date__range=[month_start, month_end],
                payment_status='已结'
            ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

            monthly_revenue.append({
                'month': month_start.strftime('%Y-%m'),
                'revenue': float(month_revenue)
            })

            current_month = month_start - timedelta(days=1)

        monthly_revenue.reverse()

        return JsonResponse({
            'success': True,
            'revenue_data': revenue_data,
            'monthly_revenue': monthly_revenue
        })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_GET
def api_occupancy_chart(request):
    """出租率图表API"""
    try:
        days = int(request.GET.get('days', 30))
        end_date = timezone.now().date()
        start_date = end_date - timedelta(days=days - 1)

        total_rooms = Room.objects.count()
        occupancy_data = []

        for i in range(days):
            current_date = start_date + timedelta(days=i)

            # 计算当日在住房间数
            occupied_rooms = CheckIn.objects.filter(
                Q(actual_check_in__date__lte=current_date) &
                (
                        Q(actual_check_out__date__gt=current_date) |
                        Q(actual_check_out__isnull=True) &
                        Q(expected_check_out__gte=current_date)
                ) &
                Q(check_in_status='在住')
            ).values('room').distinct().count()

            occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0

            occupancy_data.append({
                'date': current_date.strftime('%m-%d'),
                'occupancy_rate': round(occupancy_rate, 1),
                'occupied_rooms': occupied_rooms,
                'total_rooms': total_rooms
            })

        return JsonResponse({
            'success': True,
            'occupancy_data': occupancy_data,
            'total_rooms': total_rooms
        })

    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


# ==================== 系统功能 ====================
@login_required
@permission_required('hotel_app.view_operationlog', raise_exception=True)
def system_logs(request):
    """系统日志视图"""
    logs = OperationLog.objects.all().select_related('staff').order_by('-operation_time')

    # 筛选条件
    module = request.GET.get('module')
    action = request.GET.get('action')
    staff_id = request.GET.get('staff_id')
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')

    if module:
        logs = logs.filter(module__icontains=module)
    if action:
        logs = logs.filter(action__icontains=action)
    if staff_id:
        logs = logs.filter(staff_id=staff_id)
    if date_from:
        logs = logs.filter(operation_time__date__gte=date_from)
    if date_to:
        logs = logs.filter(operation_time__date__lte=date_to)

    # 统计信息
    stats = logs.aggregate(
        total=Count('log_id'),
        today=Count('log_id', filter=Q(operation_time__date=timezone.now().date()))
    )

    # 分页
    paginator = Paginator(logs, 50)
    page = request.GET.get('page', 1)

    try:
        logs_page = paginator.page(page)
    except PageNotAnInteger:
        logs_page = paginator.page(1)
    except EmptyPage:
        logs_page = paginator.page(paginator.num_pages)

    # 获取员工列表
    staff_list = Staff.objects.all()

    return render(request, 'system/logs.html', {
        'logs': logs_page,
        'stats': stats,
        'staff_list': staff_list,
        'current_filters': {
            'module': module,
            'action': action,
            'staff_id': staff_id,
            'date_from': date_from,
            'date_to': date_to
        }
    })


@login_required
@permission_required('hotel_app.view_roomstatuslog', raise_exception=True)
def system_backup(request):
    """系统备份视图"""
    if request.method == 'POST':
        backup_type = request.POST.get('backup_type')

        if backup_type == 'database':
            # 导出数据库
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="hotel_backup.csv"'

            writer = csv.writer(response)
            writer.writerow(['Table', 'Record Count', 'Backup Time'])

            tables = [
                ('Room', Room.objects.count()),
                ('Customer', Customer.objects.count()),
                ('Reservation', Reservation.objects.count()),
                ('CheckIn', CheckIn.objects.count()),
                ('Bill', Bill.objects.count()),
                ('Staff', Staff.objects.count())
            ]

            for table_name, count in tables:
                writer.writerow([table_name, count, timezone.now().strftime('%Y-%m-%d %H:%M:%S')])

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='系统管理',
                action='数据库备份',
                description='导出数据库备份文件',
                ip_address=get_client_ip(request)
            )

            messages.success(request, '数据库备份导出成功！')
            return response

        elif backup_type == 'reports':
            # 生成报表备份
            today = timezone.now().date()

            # 这里可以添加具体的报表生成逻辑
            messages.success(request, '报表备份生成成功！')

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='系统管理',
                action='报表备份',
                description='生成系统报表备份',
                ip_address=get_client_ip(request)
            )

            return redirect('system_backup')

    return render(request, 'system/backup.html')


@login_required
@permission_required('hotel_app.change_staff', raise_exception=True)
def system_settings(request):
    """系统设置视图"""
    return render(request, 'system/settings.html')


# ==================== 员工管理 ====================
@login_required
@permission_required('hotel_app.view_staff', raise_exception=True)
def staff_list(request):
    """员工列表视图"""
    staffs = Staff.objects.all().order_by('staff_id')

    # 筛选条件
    department = request.GET.get('department')
    role = request.GET.get('role')
    status = request.GET.get('status')
    search = request.GET.get('search')

    if department:
        staffs = staffs.filter(department=department)
    if role:
        staffs = staffs.filter(role=role)
    if status:
        staffs = staffs.filter(status=status)
    if search:
        staffs = staffs.filter(
            Q(name__icontains=search) |
            Q(username__icontains=search) |
            Q(phone__icontains=search) |
            Q(email__icontains=search)
        )

    # 统计信息
    stats = staffs.aggregate(
        total=Count('staff_id'),
        active=Count('staff_id', filter=Q(status='在职')),
        inactive=Count('staff_id', filter=Q(status='离职'))
    )

    # 获取筛选选项
    departments = Staff.objects.values_list('department', flat=True).distinct()
    roles = Staff.objects.values_list('role', flat=True).distinct()
    statuses = Staff.objects.values_list('status', flat=True).distinct()

    return render(request, 'staff/list.html', {
        'staffs': staffs,
        'stats': stats,
        'departments': departments,
        'roles': roles,
        'statuses': statuses,
        'current_filters': {
            'department': department,
            'role': role,
            'status': status,
            'search': search
        }
    })


@login_required
@permission_required('hotel_app.add_staff', raise_exception=True)
def staff_add(request):
    """添加员工视图"""
    if request.method == 'POST':
        form = StaffForm(request.POST)
        if form.is_valid():
            staff = form.save(commit=False)
            staff.set_password(form.cleaned_data['password'])
            staff.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='员工管理',
                action='新增',
                target_id=staff.staff_id,
                description=f'新增员工 {staff.name} ({staff.username})',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'员工 {staff.name} 添加成功！')
            return redirect('staff_list')
    else:
        form = StaffForm()

    return render(request, 'staff/form.html', {
        'form': form,
        'title': '添加员工',
        'submit_text': '添加'
    })


@login_required
@permission_required('hotel_app.change_staff', raise_exception=True)
def staff_edit(request, staff_id):
    """编辑员工视图"""
    staff = get_object_or_404(Staff, staff_id=staff_id)

    if request.method == 'POST':
        form = StaffForm(request.POST, instance=staff)
        if form.is_valid():
            staff = form.save()

            # 如果密码被修改
            if form.cleaned_data['password']:
                staff.set_password(form.cleaned_data['password'])
                staff.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='员工管理',
                action='修改',
                target_id=staff.staff_id,
                description=f'修改员工 {staff.name} 信息',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'员工 {staff.name} 更新成功！')
            return redirect('staff_list')
    else:
        form = StaffForm(instance=staff)

    return render(request, 'staff/form.html', {
        'form': form,
        'title': f'编辑员工 {staff.name}',
        'submit_text': '更新'
    })


@login_required
def staff_profile(request, staff_id):
    """员工档案视图"""
    staff = get_object_or_404(Staff, staff_id=staff_id)

    # 获取最近的操作日志
    recent_logs = OperationLog.objects.filter(
        staff=staff
    ).order_by('-operation_time')[:10]

    return render(request, 'staff/profile.html', {
        'staff': staff,
        'recent_logs': recent_logs
    })


# # ==================== 快速操作 ====================
@login_required
def quick_checkin(request):
    """快速入住视图"""
    if request.method == 'POST':
        form = QuickCheckInForm(request.POST)
        if form.is_valid():
            try:
                # 从表单获取数据
                customer = form.cleaned_data['customer']
                room = form.cleaned_data['room']
                expected_check_out = form.cleaned_data['expected_check_out']
                adult_count = form.cleaned_data.get('adult_count', 1)
                payment_method = form.cleaned_data.get('payment_method', '现金')

                # 检查房间是否可用
                if room.status != '空闲':
                    messages.error(request, f'房间 {room.room_id} 当前不可用！')
                    return render(request, 'quick/checkin.html', {
                        'form': form,
                        'title': '快速入住'
                    })

                # 创建入住记录
                checkin = CheckIn.objects.create(
                    customer=customer,
                    room=room,
                    actual_check_in=timezone.now(),
                    expected_check_out=expected_check_out,
                    adult_count=adult_count,
                    check_in_status='在住',
                    operator=request.user,
                    payment_method=payment_method,
                    room_price=room.price,
                    total_price=0  # 先设为0，后面计算
                )

                # 计算房费
                days = (checkin.expected_check_out - checkin.actual_check_in.date()).days
                if days < 1:
                    days = 1

                room_price = room.price
                total_price = days * room_price

                # 更新入住记录的价格
                checkin.room_price = room_price
                checkin.total_price = total_price
                checkin.save()

                # 更新房间状态
                room.status = '已入住'
                room.save()

                # 更新客户入住次数
                customer.total_stay_days += days
                customer.last_visit_date = checkin.actual_check_in.date()
                customer.save()

                # 记录房态日志
                RoomStatusLog.objects.create(
                    room=room,
                    old_status='空闲',
                    new_status='已入住',
                    change_reason='快速入住',
                    operator=request.user
                )

                # 创建房费账单
                Bill.objects.create(
                    check_in=checkin,
                    bill_type='房费',
                    item_name=f'{room.room_type}房费',
                    quantity=days,
                    unit_price=room_price,
                    amount=total_price,
                    consumption_time=checkin.actual_check_in,
                    payment_status='未结',
                    operator=request.user
                )

                # 记录操作日志
                OperationLog.objects.create(
                    staff=request.user,
                    module='快速操作',
                    action='快速入住',
                    target_id=checkin.check_in_id,
                    description=f'快速入住: {customer.name} -> {room.room_id}',
                    ip_address=get_client_ip(request)
                )

                messages.success(request, f'快速入住成功！入住单号: {checkin.check_in_id}')
                return redirect('checkin_detail', checkin_id=checkin.check_in_id)

            except Exception as e:
                messages.error(request, f'快速入住失败: {str(e)}')
    else:
        form = QuickCheckInForm()

    return render(request, 'quick/checkin.html', {
        'form': form,
        'title': '快速入住'
    })


@login_required
def quick_checkout(request):
    """快速离店视图"""
    if request.method == 'POST':
        checkin_id = request.POST.get('checkin_id')

        try:
            # 注意：这里使用 check_in_id（数据库字段名）
            checkin = CheckIn.objects.get(check_in_id=checkin_id, check_in_status='在住')

            # 检查是否有未结账单
            unpaid_bills = Bill.objects.filter(
                check_in=checkin,
                payment_status='未结'
            )

            if unpaid_bills.exists():
                total_unpaid = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

                # 如果有未结账单，先结账
                for bill in unpaid_bills:
                    bill.payment_status = '已结'
                    bill.payment_method = '现金'
                    bill.payment_time = timezone.now()
                    bill.save()

                messages.info(request, f'已结清未付账单 ¥{total_unpaid}')

            # 办理离店
            checkin.check_in_status = '已离店'
            checkin.actual_check_out = timezone.now()
            checkin.save()

            # 更新房间状态
            room = checkin.room
            room.status = '空闲'
            room.save()

            # 更新客户消费总额
            total_consumption = Bill.objects.filter(
                check_in=checkin,
                payment_status='已结'
            ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

            customer = checkin.customer
            customer.total_consumption += total_consumption
            customer.save()

            # 记录房态日志
            RoomStatusLog.objects.create(
                room=room,
                old_status='已入住',
                new_status='空闲',
                change_reason='快速离店',
                operator=request.user
            )

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='快速操作',
                action='快速离店',
                target_id=checkin.check_in_id,
                description=f'快速离店: {checkin.customer.name} -> {room.room_id}',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'{checkin.customer.name} 快速离店成功！')
            return redirect('checkin_detail', checkin_id=checkin.check_in_id)

        except CheckIn.DoesNotExist:
            messages.error(request, '入住记录不存在或客人已离店！')

    return render(request, 'quick/checkout.html', {
        'title': '快速离店'
    })


@login_required
def quick_reservation(request):
    """快速预订视图"""
    if request.method == 'POST':
        form = QuickReservationForm(request.POST)
        if form.is_valid():
            try:
                # 从表单获取数据
                customer = form.cleaned_data['customer']
                room = form.cleaned_data['room']
                expected_check_in = form.cleaned_data['expected_check_in']
                expected_check_out = form.cleaned_data['expected_check_out']
                deposit = form.cleaned_data.get('deposit', 0)

                # 检查房间是否可用
                if room.status != '空闲':
                    messages.error(request, f'房间 {room.room_id} 当前不可用！')
                    return render(request, 'quick/reservation.html', {
                        'form': form,
                        'title': '快速预订'
                    })

                # 计算总价
                days = (expected_check_out - expected_check_in).days
                if days < 1:
                    days = 1

                room_price = room.price
                total_price = days * room_price

                # 创建预订记录
                reservation = Reservation.objects.create(
                    customer=customer,
                    room=room,
                    room_type=room.room_type,
                    expected_check_in=expected_check_in,
                    expected_check_out=expected_check_out,
                    total_price=total_price,
                    deposit=deposit,
                    reservation_status='已确认',
                    operator=request.user
                )

                # 更新房间状态
                room.status = '已预订'
                room.save()

                # 记录房态日志
                RoomStatusLog.objects.create(
                    room=room,
                    old_status='空闲',
                    new_status='已预订',
                    change_reason='快速预订',
                    operator=request.user
                )

                # 记录操作日志
                OperationLog.objects.create(
                    staff=request.user,
                    module='快速操作',
                    action='快速预订',
                    target_id=reservation.reservation_id,
                    description=f'快速预订: {customer.name} -> {room.room_id}',
                    ip_address=get_client_ip(request)
                )

                messages.success(request, f'快速预订成功！预订号: {reservation.reservation_id}')
                return redirect('reservation_detail', reservation_id=reservation.reservation_id)

            except Exception as e:
                messages.error(request, f'快速预订失败: {str(e)}')
    else:
        form = QuickReservationForm()

    return render(request, 'quick/reservation.html', {
        'form': form,
        'title': '快速预订'
    })


@login_required
def quick_billing(request):
    """快速结账视图"""
    if request.method == 'POST':
        checkin_id = request.POST.get('checkin_id')
        payment_method = request.POST.get('payment_method')

        try:
            # 注意：这里使用 check_in_id（数据库字段名）
            checkin = CheckIn.objects.get(check_in_id=checkin_id, check_in_status='在住')

            # 获取未结账单
            unpaid_bills = Bill.objects.filter(
                check_in=checkin,
                payment_status='未结'
            )

            if not unpaid_bills.exists():
                messages.error(request, '没有未结账单！')
                return redirect('quick_billing')

            total_amount = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']

            # 结清所有未结账单
            for bill in unpaid_bills:
                bill.payment_status = '已结'
                bill.payment_method = payment_method
                bill.payment_time = timezone.now()
                bill.save()

            # 记录操作日志
            OperationLog.objects.create(
                staff=request.user,
                module='快速操作',
                action='快速结账',
                target_id=checkin.check_in_id,
                description=f'快速结账: {checkin.customer.name} -> ¥{total_amount} ({payment_method})',
                ip_address=get_client_ip(request)
            )

            messages.success(request, f'快速结账成功！金额: ¥{total_amount}')
            return redirect('checkin_detail', checkin_id=checkin.check_in_id)

        except CheckIn.DoesNotExist:
            messages.error(request, '入住记录不存在！')

    return render(request, 'quick/billing.html', {
        'title': '快速结账',
        'payment_method_choices': Bill.PAYMENT_METHOD_CHOICES
    })
# @login_required
# def quick_checkin(request):
#     """快速入住视图"""
#     if request.method == 'POST':
#         form = QuickCheckInForm(request.POST)
#         if form.is_valid():
#             checkin = form.save(commit=False)
#             checkin.operator = request.user
#
#             # 计算房费
#             days = (checkin.expected_check_out - checkin.actual_check_in.date()).days
#             if days < 1:
#                 days = 1
#
#             room = checkin.room
#             room_price = room.price
#             total_price = days * room_price
#
#             checkin.room_price = room_price
#             checkin.total_price = total_price
#             checkin.save()
#
#             # 更新房间状态
#             room.status = '已入住'
#             room.save()
#
#             # 更新客户入住次数
#             customer = checkin.customer
#             customer.total_stay_days += days
#             customer.last_visit_date = checkin.actual_check_in.date()
#             customer.save()
#
#             # 记录房态日志
#             RoomStatusLog.objects.create(
#                 room=room,
#                 old_status='空闲',
#                 new_status='已入住',
#                 change_reason='快速入住',
#                 operator=request.user
#             )
#
#             # 创建房费账单
#             Bill.objects.create(
#                 check_in=checkin,
#                 bill_type='房费',
#                 item_name=f'{room.room_type}房费',
#                 quantity=days,
#                 unit_price=room_price,
#                 amount=total_price,
#                 consumption_time=checkin.actual_check_in,
#                 payment_status='未结',
#                 operator=request.user
#             )
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='快速操作',
#                 action='快速入住',
#                 target_id=checkin.check_in_id,
#                 description=f'快速入住: {checkin.customer.name} -> {room.room_id}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'快速入住成功！入住单号: {checkin.check_in_id}')
#             return redirect('checkin_detail', checkin_id=checkin.check_in_id)
#     else:
#         form = QuickCheckInForm()
#
#     return render(request, 'quick/checkin.html', {
#         'form': form,
#         'title': '快速入住'
#     })
#
#
# @login_required
# def quick_checkout(request):
#     """快速离店视图"""
#     if request.method == 'POST':
#         checkin_id = request.POST.get('checkin_id')
#
#         try:
#             checkin = CheckIn.objects.get(checkin_id=checkin_id, check_in_status='在住')
#
#             # 检查是否有未结账单
#             unpaid_bills = Bill.objects.filter(
#                 check_in=checkin,
#                 payment_status='未结'
#             )
#
#             if unpaid_bills.exists():
#                 total_unpaid = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
#
#                 # 如果有未结账单，先结账
#                 for bill in unpaid_bills:
#                     bill.payment_status = '已结'
#                     bill.payment_method = '现金'
#                     bill.payment_time = timezone.now()
#                     bill.save()
#
#                 messages.info(request, f'已结清未付账单 ¥{total_unpaid}')
#
#             # 办理离店
#             checkin.check_in_status = '已离店'
#             checkin.actual_check_out = timezone.now()
#             checkin.save()
#
#             # 更新房间状态
#             room = checkin.room
#             room.status = '空闲'
#             room.save()
#
#             # 更新客户消费总额
#             total_consumption = Bill.objects.filter(
#                 check_in=checkin,
#                 payment_status='已结'
#             ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
#
#             customer = checkin.customer
#             customer.total_consumption += total_consumption
#             customer.save()
#
#             # 记录房态日志
#             RoomStatusLog.objects.create(
#                 room=room,
#                 old_status='已入住',
#                 new_status='空闲',
#                 change_reason='快速离店',
#                 operator=request.user
#             )
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='快速操作',
#                 action='快速离店',
#                 target_id=checkin.check_in_id,
#                 description=f'快速离店: {checkin.customer.name} -> {room.room_id}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'{checkin.customer.name} 快速离店成功！')
#             return redirect('checkin_detail', checkin_id=checkin.check_in_id)
#
#         except CheckIn.DoesNotExist:
#             messages.error(request, '入住记录不存在或客人已离店！')
#
#     return render(request, 'quick/checkout.html', {
#         'title': '快速离店'
#     })
#
#
# @login_required
# def quick_reservation(request):
#     """快速预订视图"""
#     if request.method == 'POST':
#         form = QuickReservationForm(request.POST)
#         if form.is_valid():
#             reservation = form.save(commit=False)
#             reservation.operator = request.user
#             reservation.reservation_status = '已确认'
#
#             # 计算总价
#             days = (reservation.expected_check_out - reservation.expected_check_in).days
#             if days < 1:
#                 days = 1
#
#             room_price = reservation.room.price
#             total_price = days * room_price
#
#             reservation.total_price = total_price
#             reservation.save()
#
#             # 更新房间状态
#             reservation.room.status = '已预订'
#             reservation.room.save()
#
#             # 记录房态日志
#             RoomStatusLog.objects.create(
#                 room=reservation.room,
#                 old_status='空闲',
#                 new_status='已预订',
#                 change_reason='快速预订',
#                 operator=request.user
#             )
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='快速操作',
#                 action='快速预订',
#                 target_id=reservation.reservation_id,
#                 description=f'快速预订: {reservation.customer.name} -> {reservation.room.room_id}',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'快速预订成功！预订号: {reservation.reservation_id}')
#             return redirect('reservation_detail', reservation_id=reservation.reservation_id)
#     else:
#         form = QuickReservationForm()
#
#     return render(request, 'quick/reservation.html', {
#         'form': form,
#         'title': '快速预订'
#     })
#
#
# @login_required
# def quick_billing(request):
#     """快速结账视图"""
#     if request.method == 'POST':
#         checkin_id = request.POST.get('checkin_id')
#         payment_method = request.POST.get('payment_method')
#
#         try:
#             checkin = CheckIn.objects.get(checkin_id=checkin_id, check_in_status='在住')
#
#             # 获取未结账单
#             unpaid_bills = Bill.objects.filter(
#                 check_in=checkin,
#                 payment_status='未结'
#             )
#
#             if not unpaid_bills.exists():
#                 messages.error(request, '没有未结账单！')
#                 return redirect('quick_billing')
#
#             total_amount = unpaid_bills.aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total']
#
#             # 结清所有未结账单
#             for bill in unpaid_bills:
#                 bill.payment_status = '已结'
#                 bill.payment_method = payment_method
#                 bill.payment_time = timezone.now()
#                 bill.save()
#
#             # 记录操作日志
#             OperationLog.objects.create(
#                 staff=request.user,
#                 module='快速操作',
#                 action='快速结账',
#                 target_id=checkin.check_in_id,
#                 description=f'快速结账: {checkin.customer.name} -> ¥{total_amount} ({payment_method})',
#                 ip_address=get_client_ip(request)
#             )
#
#             messages.success(request, f'快速结账成功！金额: ¥{total_amount}')
#             return redirect('checkin_detail', checkin_id=checkin.check_in_id)
#
#         except CheckIn.DoesNotExist:
#             messages.error(request, '入住记录不存在！')
#
#     return render(request, 'quick/billing.html', {
#         'title': '快速结账',
#         'payment_method_choices': Bill.PAYMENT_METHOD_CHOICES
#     })


# ==================== 工具函数 ====================
def get_client_ip(request):
    """获取客户端IP地址"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def is_valid_status_transition(old_status, new_status):
    """验证房态转换是否合法"""
    valid_transitions = {
        '空闲': ['已预订', '已入住', '维修中'],
        '已预订': ['空闲', '已入住', '已取消'],
        '已入住': ['空闲', '维修中'],
        '维修中': ['空闲'],
        '已取消': ['空闲']
    }

    return old_status in valid_transitions and new_status in valid_transitions[old_status]

@login_required
@require_GET
def api_calculate_price(request):
    """计算价格API"""
    try:
        checkin_date = request.GET.get('checkin')
        checkout_date = request.GET.get('checkout')
        room_id = request.GET.get('room_id')
        extra_bed = request.GET.get('extra_bed') == 'true'

        if not all([checkin_date, checkout_date, room_id]):
            return JsonResponse({'success': False, 'error': '缺少必要参数'})

        checkin_date = datetime.strptime(checkin_date, '%Y-%m-%d').date()
        checkout_date = datetime.strptime(checkout_date, '%Y-%m-%d').date()

        if checkin_date >= checkout_date:
            return JsonResponse({'success': False, 'error': '离店日期必须晚于入住日期'})

        days = (checkout_date - checkin_date).days
        if days < 1:
            days = 1

        try:
            room = Room.objects.get(room_id=room_id)
        except Room.DoesNotExist:
            return JsonResponse({'success': False, 'error': '房间不存在'})

        room_price = days * room.price
        extra_bed_price = days * room.extra_bed_price if extra_bed else 0
        total_price = room_price + extra_bed_price

        return JsonResponse({
            'success': True,
            'days': days,
            'room_price': str(room_price),
            'extra_bed_price': str(extra_bed_price),
            'total_price': str(total_price),
            'room_type': room.room_type,
            'room_capacity': room.capacity
        })

    except ValueError as e:
        return JsonResponse({'success': False, 'error': f'日期格式错误: {str(e)}'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})