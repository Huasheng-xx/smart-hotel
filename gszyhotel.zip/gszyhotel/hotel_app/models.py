# models.py
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.utils import timezone


# 员工自定义管理器
class StaffManager(BaseUserManager):
    def create_user(self, username, password=None, **extra_fields):
        if not username:
            raise ValueError('用户名是必需的')

        user = self.model(username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', 'admin')
        extra_fields.setdefault('status', '在职')

        return self.create_user(username, password, **extra_fields)


# 1. 员工表 (Staff)
class Staff(AbstractBaseUser, PermissionsMixin):
    staff_id = models.AutoField(primary_key=True, verbose_name='员工ID')
    username = models.CharField(max_length=50, unique=True, verbose_name='用户名')
    password = models.CharField(max_length=255, verbose_name='密码')  # 明文存储
    name = models.CharField(max_length=100, verbose_name='姓名')
    gender = models.CharField(max_length=10, null=True, blank=True, verbose_name='性别')
    phone = models.CharField(max_length=20, null=True, blank=True, verbose_name='手机')
    email = models.CharField(max_length=100, null=True, blank=True, verbose_name='邮箱')
    department = models.CharField(max_length=50, null=True, blank=True, verbose_name='部门')
    position = models.CharField(max_length=50, null=True, blank=True, verbose_name='职位')
    role = models.CharField(max_length=20, default='staff', verbose_name='角色')
    status = models.CharField(max_length=20, default='在职', verbose_name='状态')
    last_login = models.DateTimeField(null=True, blank=True, verbose_name='最后登录时间')
    login_ip = models.CharField(max_length=50, null=True, blank=True, verbose_name='登录IP')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    is_staff = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)

    # 关键：明确指定groups和user_permissions字段
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='用户组',
        blank=True,
        help_text='用户所属的组。',
        related_name="staff_user_set",  # 修改related_name
        related_query_name="staff_user",
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='用户权限',
        blank=True,
        help_text='用户的特定权限。',
        related_name="staff_user_set",  # 修改related_name
        related_query_name="staff_user",
    )

    objects = StaffManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['name']

    class Meta:
        db_table = 'staff'
        verbose_name = '员工'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name} ({self.username})"


# 2. 客房表 (Room)
class Room(models.Model):
    ROOM_STATUS_CHOICES = [
        ('空闲', '空闲'),
        ('已预订', '已预订'),
        ('已入住', '已入住'),
        ('维修中', '维修中'),
    ]

    room_id = models.CharField(max_length=20, primary_key=True, verbose_name='客房编号')
    room_type = models.CharField(max_length=50, verbose_name='客房类型')
    floor = models.IntegerField(verbose_name='楼层')
    status = models.CharField(max_length=20, choices=ROOM_STATUS_CHOICES, default='空闲', verbose_name='房态')
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='标准价格')
    description = models.TextField(null=True, blank=True, verbose_name='客房描述')
    capacity = models.IntegerField(default=1, verbose_name='可住人数')
    extra_bed = models.BooleanField(default=False, verbose_name='是否可加床')
    extra_bed_price = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='加床价格')
    room_features = models.TextField(null=True, blank=True, verbose_name='客房特色')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'room'
        verbose_name = '客房'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.room_id} - {self.room_type}"


# 3. 客户表 (Customer)
class Customer(models.Model):
    CUSTOMER_TYPE_CHOICES = [
        ('散客', '散客'),
        ('会员', '会员'),
        ('VIP', 'VIP'),
    ]

    ID_TYPE_CHOICES = [
        ('身份证', '身份证'),
        ('护照', '护照'),
        ('军官证', '军官证'),
        ('其他', '其他'),
    ]

    customer_id = models.AutoField(primary_key=True, verbose_name='客户ID')
    name = models.CharField(max_length=100, verbose_name='客户姓名')
    id_type = models.CharField(max_length=20, choices=ID_TYPE_CHOICES, default='身份证', verbose_name='证件类型')
    id_number = models.CharField(max_length=50, verbose_name='证件号码')
    phone = models.CharField(max_length=20, null=True, blank=True, verbose_name='手机号码')
    email = models.CharField(max_length=100, null=True, blank=True, verbose_name='电子邮箱')
    gender = models.CharField(max_length=10, null=True, blank=True, verbose_name='性别')
    birthday = models.DateField(null=True, blank=True, verbose_name='生日')
    customer_type = models.CharField(max_length=20, choices=CUSTOMER_TYPE_CHOICES, default='散客',
                                     verbose_name='客户类型')
    member_level = models.CharField(max_length=20, null=True, blank=True, verbose_name='会员等级')
    member_id = models.CharField(max_length=50, null=True, blank=True, unique=True, verbose_name='会员卡号')
    total_stay_days = models.IntegerField(default=0, verbose_name='累计入住天数')
    total_consumption = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name='累计消费金额')
    last_visit_date = models.DateField(null=True, blank=True, verbose_name='最后入住日期')
    is_blacklist = models.BooleanField(default=False, verbose_name='是否黑名单')
    blacklist_reason = models.TextField(null=True, blank=True, verbose_name='黑名单原因')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'customer'
        verbose_name = '客户'
        verbose_name_plural = verbose_name
        unique_together = ['id_type', 'id_number']

    def __str__(self):
        return f"{self.name} ({self.customer_type})"


# 4. 预订表 (Reservation)
class Reservation(models.Model):
    RESERVATION_STATUS_CHOICES = [
        ('待确认', '待确认'),
        ('已确认', '已确认'),
        ('已取消', '已取消'),
        ('已入住', '已入住'),
    ]

    PAYMENT_METHOD_CHOICES = [
        ('现金', '现金'),
        ('微信支付', '微信支付'),
        ('支付宝', '支付宝'),
        ('信用卡', '信用卡'),
        ('其他', '其他'),
    ]

    SOURCE_CHOICES = [
        ('官网', '官网'),
        ('OTA', 'OTA'),
        ('电话', '电话'),
        ('前台', '前台'),
        ('其他', '其他'),
    ]

    reservation_id = models.AutoField(primary_key=True, verbose_name='预订单号')
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name='客户')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name='预订房间')
    room_type = models.CharField(max_length=50, verbose_name='预订房型')
    expected_check_in = models.DateField(verbose_name='预计入住日期')
    expected_check_out = models.DateField(verbose_name='预计离店日期')
    actual_room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='actual_reservations', verbose_name='实际分配房间')
    adult_count = models.IntegerField(default=1, verbose_name='成人数')
    child_count = models.IntegerField(default=0, verbose_name='儿童数')
    extra_bed = models.BooleanField(default=False, verbose_name='是否加床')
    total_price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='预订总价')
    deposit = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='订金')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, null=True, blank=True,
                                      verbose_name='支付方式')
    reservation_status = models.CharField(max_length=20, choices=RESERVATION_STATUS_CHOICES, default='待确认',
                                          verbose_name='预订状态')
    cancel_reason = models.TextField(null=True, blank=True, verbose_name='取消原因')
    cancel_time = models.DateTimeField(null=True, blank=True, verbose_name='取消时间')
    remark = models.TextField(null=True, blank=True, verbose_name='备注')
    source = models.CharField(max_length=50, choices=SOURCE_CHOICES, null=True, blank=True, verbose_name='预订来源')
    operator = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='操作员工')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'reservation'
        verbose_name = '预订'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"预订{self.reservation_id}: {self.customer.name}"


# 5. 入住登记表 (CheckIn)
class CheckIn(models.Model):
    CHECK_IN_STATUS_CHOICES = [
        ('在住', '在住'),
        ('已离店', '已离店'),
        ('延期', '延期'),
    ]

    PAYMENT_METHOD_CHOICES = [
        ('现金', '现金'),
        ('微信支付', '微信支付'),
        ('支付宝', '支付宝'),
        ('信用卡', '信用卡'),
        ('挂账', '挂账'),
        ('其他', '其他'),
    ]

    check_in_id = models.AutoField(primary_key=True, verbose_name='入住单号')
    reservation = models.ForeignKey(Reservation, on_delete=models.SET_NULL, null=True, blank=True,
                                    verbose_name='关联预订')
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, verbose_name='客户')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name='房间')
    actual_check_in = models.DateTimeField(verbose_name='实际入住时间')
    expected_check_out = models.DateField(verbose_name='预计离店日期')
    actual_check_out = models.DateTimeField(null=True, blank=True, verbose_name='实际离店时间')
    adult_count = models.IntegerField(default=1, verbose_name='成人数')
    child_count = models.IntegerField(default=0, verbose_name='儿童数')
    extra_bed = models.BooleanField(default=False, verbose_name='是否加床')
    extra_bed_count = models.IntegerField(default=0, verbose_name='加床数量')
    room_price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='房价')
    extra_bed_price = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name='加床价格')
    total_price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='房费总额')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, null=True, blank=True,
                                      verbose_name='支付方式')
    check_in_status = models.CharField(max_length=20, choices=CHECK_IN_STATUS_CHOICES, default='在住',
                                       verbose_name='入住状态')
    remark = models.TextField(null=True, blank=True, verbose_name='备注')
    operator = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='办理员工')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'check_in'
        verbose_name = '入住登记'
        verbose_name_plural = '入住登记'

    def __str__(self):
        return f"入住{self.check_in_id}: {self.customer.name} - {self.room.room_id}"


# 6. 账单表 (Bill)
class Bill(models.Model):
    BILL_TYPE_CHOICES = [
        ('房费', '房费'),
        ('餐饮', '餐饮'),
        ('洗衣', '洗衣'),
        ('电话', '电话'),
        ('其他', '其他'),
    ]

    PAYMENT_STATUS_CHOICES = [
        ('未结', '未结'),
        ('已结', '已结'),
        ('挂账', '挂账'),
    ]

    PAYMENT_METHOD_CHOICES = [
        ('现金', '现金'),
        ('微信支付', '微信支付'),
        ('支付宝', '支付宝'),
        ('信用卡', '信用卡'),
        ('挂房账', '挂房账'),
        ('其他', '其他'),
    ]

    bill_id = models.AutoField(primary_key=True, verbose_name='账单ID')
    check_in = models.ForeignKey(CheckIn, on_delete=models.CASCADE, verbose_name='入住单')
    bill_type = models.CharField(max_length=20, choices=BILL_TYPE_CHOICES, verbose_name='消费类型')
    item_name = models.CharField(max_length=100, verbose_name='项目名称')
    quantity = models.IntegerField(default=1, verbose_name='数量')
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='单价')
    amount = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='金额')
    consumption_time = models.DateTimeField(verbose_name='消费时间')
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='未结',
                                      verbose_name='支付状态')
    payment_time = models.DateTimeField(null=True, blank=True, verbose_name='支付时间')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, null=True, blank=True,
                                      verbose_name='支付方式')
    remark = models.TextField(null=True, blank=True, verbose_name='备注')
    operator = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='操作员工')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        db_table = 'bill'
        verbose_name = '账单'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"账单{self.bill_id}: {self.item_name} - ¥{self.amount}"


# 7. 房态日志表 (RoomStatusLog)
class RoomStatusLog(models.Model):
    log_id = models.AutoField(primary_key=True, verbose_name='日志ID')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, verbose_name='房间')
    old_status = models.CharField(max_length=20, null=True, blank=True, verbose_name='原状态')
    new_status = models.CharField(max_length=20, verbose_name='新状态')
    change_reason = models.CharField(max_length=100, null=True, blank=True, verbose_name='变更原因')
    operator = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='操作员工')
    change_time = models.DateTimeField(auto_now_add=True, verbose_name='变更时间')

    class Meta:
        db_table = 'room_status_log'
        verbose_name = '房态日志'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"房态变更: {self.room.room_id} {self.old_status}->{self.new_status}"


# 8. 操作日志表 (OperationLog)
class OperationLog(models.Model):
    log_id = models.AutoField(primary_key=True, verbose_name='日志ID')
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE, verbose_name='操作员工')
    module = models.CharField(max_length=50, verbose_name='操作模块')
    action = models.CharField(max_length=50, verbose_name='操作动作')
    target_id = models.CharField(max_length=100, null=True, blank=True, verbose_name='操作对象ID')
    description = models.TextField(null=True, blank=True, verbose_name='操作描述')
    ip_address = models.CharField(max_length=50, null=True, blank=True, verbose_name='IP地址')
    operation_time = models.DateTimeField(auto_now_add=True, verbose_name='操作时间')

    class Meta:
        db_table = 'operation_log'
        verbose_name = '操作日志'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.staff.name} - {self.module}.{self.action}"
