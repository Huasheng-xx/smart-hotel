# admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Staff, Room, Customer, Reservation, CheckIn, Bill, RoomStatusLog, OperationLog
from django.utils.html import format_html


# 员工Admin
class StaffAdmin(UserAdmin):
    list_display = ('username', 'name', 'department', 'position', 'role', 'status', 'last_login')
    list_filter = ('department', 'role', 'status')
    search_fields = ('username', 'name', 'phone', 'email')
    ordering = ('username',)

    fieldsets = (
        ('登录信息', {'fields': ('username', 'password')}),
        ('个人信息', {'fields': ('name', 'gender', 'phone', 'email')}),
        ('工作信息', {'fields': ('department', 'position', 'role', 'status')}),
        ('权限信息', {'fields': ('is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
        ('登录记录', {'fields': ('last_login', 'login_ip')}),
        ('时间信息', {'fields': ('create_time', 'update_time')}),
    )

    readonly_fields = ('create_time', 'update_time', 'last_login')

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # 确保密码字段显示为明文输入
        if 'password' in form.base_fields:
            form.base_fields['password'].widget.attrs['type'] = 'text'
        return form

    def save_model(self, request, obj, form, change):
        # 如果密码被修改，保存明文密码
        if 'password' in form.changed_data:
            obj.set_password(form.cleaned_data['password'])
        super().save_model(request, obj, form, change)


# 客房Admin
class RoomAdmin(admin.ModelAdmin):
    list_display = ('room_id', 'room_type', 'floor', 'status', 'price', 'capacity', 'extra_bed')
    list_filter = ('room_type', 'floor', 'status', 'extra_bed')
    search_fields = ('room_id', 'room_type', 'description')
    list_editable = ('status', 'price')
    fieldsets = (
        ('基本信息', {'fields': ('room_id', 'room_type', 'floor', 'status')}),
        ('价格信息', {'fields': ('price', 'extra_bed', 'extra_bed_price')}),
        ('房间详情', {'fields': ('capacity', 'description', 'room_features')}),
        ('时间信息', {'fields': ('create_time', 'update_time')}),
    )
    readonly_fields = ('create_time', 'update_time')


# 客户Admin
class CustomerAdmin(admin.ModelAdmin):
    list_display = (
    'name', 'customer_type', 'member_level', 'phone', 'total_stay_days', 'total_consumption', 'last_visit_date',
    'is_blacklist')
    list_filter = ('customer_type', 'member_level', 'gender', 'is_blacklist')
    search_fields = ('name', 'phone', 'email', 'id_number', 'member_id')
    fieldsets = (
        ('基本信息', {'fields': ('name', 'gender', 'birthday', 'phone', 'email')}),
        ('证件信息', {'fields': ('id_type', 'id_number')}),
        ('会员信息', {'fields': ('customer_type', 'member_level', 'member_id')}),
        ('消费统计', {'fields': ('total_stay_days', 'total_consumption', 'last_visit_date')}),
        ('黑名单管理', {'fields': ('is_blacklist', 'blacklist_reason')}),
        ('时间信息', {'fields': ('create_time', 'update_time')}),
    )
    readonly_fields = ('create_time', 'update_time')


# 预订Admin
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('reservation_id', 'customer', 'room_type', 'expected_check_in', 'expected_check_out',
                    'total_price', 'reservation_status', 'source')
    list_filter = ('reservation_status', 'source', 'payment_method', 'room_type')
    search_fields = ('customer__name', 'customer__phone', 'reservation_id')
    date_hierarchy = 'expected_check_in'
    fieldsets = (
        ('预订信息', {'fields': ('customer', 'room', 'room_type', 'expected_check_in', 'expected_check_out')}),
        ('客人信息', {'fields': ('adult_count', 'child_count', 'extra_bed', 'actual_room')}),
        ('费用信息', {'fields': ('total_price', 'deposit', 'payment_method')}),
        ('状态信息', {'fields': ('reservation_status', 'cancel_reason', 'cancel_time')}),
        ('其他信息', {'fields': ('remark', 'source', 'operator')}),
        ('时间信息', {'fields': ('create_time', 'update_time')}),
    )
    readonly_fields = ('create_time', 'update_time')


# 入住登记Admin
class CheckInAdmin(admin.ModelAdmin):
    list_display = ('check_in_id', 'customer', 'room', 'actual_check_in', 'expected_check_out',
                    'check_in_status', 'total_price', 'payment_method')
    list_filter = ('check_in_status', 'payment_method', 'extra_bed')
    search_fields = ('customer__name', 'room__room_id', 'check_in_id')
    date_hierarchy = 'actual_check_in'
    fieldsets = (
        ('入住信息',
         {'fields': ('reservation', 'customer', 'room', 'actual_check_in', 'expected_check_out', 'actual_check_out')}),
        ('客人信息', {'fields': ('adult_count', 'child_count', 'extra_bed', 'extra_bed_count')}),
        ('费用信息', {'fields': ('room_price', 'extra_bed_price', 'total_price', 'payment_method')}),
        ('状态信息', {'fields': ('check_in_status', 'remark', 'operator')}),
        ('时间信息', {'fields': ('create_time', 'update_time')}),
    )
    readonly_fields = ('create_time', 'update_time')


# 账单Admin
class BillAdmin(admin.ModelAdmin):
    list_display = ('bill_id', 'check_in', 'bill_type', 'item_name', 'quantity', 'unit_price',
                    'amount', 'payment_status', 'consumption_time')
    list_filter = ('bill_type', 'payment_status', 'payment_method')
    search_fields = ('check_in__customer__name', 'item_name', 'bill_id')
    date_hierarchy = 'consumption_time'
    fieldsets = (
        ('账单信息', {'fields': ('check_in', 'bill_type', 'item_name')}),
        ('费用详情', {'fields': ('quantity', 'unit_price', 'amount')}),
        ('支付信息', {'fields': ('payment_status', 'payment_time', 'payment_method')}),
        ('时间信息', {'fields': ('consumption_time', 'create_time')}),
        ('其他信息', {'fields': ('remark', 'operator')}),
    )
    readonly_fields = ('create_time',)


# 房态日志Admin
class RoomStatusLogAdmin(admin.ModelAdmin):
    list_display = ('room', 'old_status', 'new_status', 'change_reason', 'operator', 'change_time')
    list_filter = ('new_status', 'old_status')
    search_fields = ('room__room_id', 'change_reason')
    date_hierarchy = 'change_time'
    readonly_fields = ('log_id', 'room', 'old_status', 'new_status', 'change_reason', 'operator', 'change_time')

    def has_add_permission(self, request):
        # 房态日志只能通过系统自动生成，不允许手动添加
        return False


# 操作日志Admin
class OperationLogAdmin(admin.ModelAdmin):
    list_display = ('staff', 'module', 'action', 'target_id', 'ip_address', 'operation_time')
    list_filter = ('module', 'action')
    search_fields = ('staff__name', 'module', 'action', 'description')
    date_hierarchy = 'operation_time'
    readonly_fields = ('log_id', 'staff', 'module', 'action', 'target_id', 'description',
                       'ip_address', 'operation_time')

    def has_add_permission(self, request):
        # 操作日志只能通过系统自动生成，不允许手动添加
        return False


# 注册所有模型到Admin
admin.site.register(Staff, StaffAdmin)
admin.site.register(Room, RoomAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(Reservation, ReservationAdmin)
admin.site.register(CheckIn, CheckInAdmin)
admin.site.register(Bill, BillAdmin)
admin.site.register(RoomStatusLog, RoomStatusLogAdmin)
admin.site.register(OperationLog, OperationLogAdmin)

# 设置Admin标题
admin.site.site_header = '酒店管理系统后台'
admin.site.site_title = '酒店管理系统'
admin.site.index_title = '系统管理'
