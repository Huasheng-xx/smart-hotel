
from django.db.models import Q, Sum, Count, Avg, F, ExpressionWrapper, DecimalField
from django.db.models.functions import Coalesce
from django.utils import timezone
from datetime import datetime, date, timedelta
from decimal import Decimal
import json
import csv
import logging
from io import StringIO
from .models import *
from .forms import *
logger = logging.getLogger(__name__)
from gszyhotel import settings

# ==================== 日期时间工具 ====================
def get_date_range(days=30):
    """获取日期范围"""
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=days - 1)
    return start_date, end_date


def format_date_range(start_date, end_date):
    """格式化日期范围"""
    if start_date == end_date:
        return start_date.strftime('%Y年%m月%d日')
    else:
        return f"{start_date.strftime('%Y年%m月%d日')} - {end_date.strftime('%Y年%m月%d日')}"


def get_month_range(year=None, month=None):
    """获取月份范围"""
    if year is None:
        year = timezone.now().year
    if month is None:
        month = timezone.now().month

    month_start = date(year, month, 1)
    if month == 12:
        month_end = date(year + 1, 1, 1) - timedelta(days=1)
    else:
        month_end = date(year, month + 1, 1) - timedelta(days=1)

    return month_start, month_end


def is_valid_date(date_str, format='%Y-%m-%d'):
    """检查日期格式是否有效"""
    try:
        datetime.strptime(date_str, format)
        return True
    except ValueError:
        return False


# ==================== 客房相关工具 ====================
def get_room_stats():
    """获取房态统计"""
    stats = Room.objects.aggregate(
        total=Count('room_id'),
        available=Count('room_id', filter=Q(status='空闲')),
        occupied=Count('room_id', filter=Q(status='已入住')),
        reserved=Count('room_id', filter=Q(status='已预订')),
        maintenance=Count('room_id', filter=Q(status='维修中'))
    )

    if stats['total'] > 0:
        stats['available_rate'] = round(stats['available'] / stats['total'] * 100, 1)
        stats['occupied_rate'] = round(stats['occupied'] / stats['total'] * 100, 1)
        stats['reserved_rate'] = round(stats['reserved'] / stats['total'] * 100, 1)
        stats['maintenance_rate'] = round(stats['maintenance'] / stats['total'] * 100, 1)
    else:
        stats.update({
            'available_rate': 0,
            'occupied_rate': 0,
            'reserved_rate': 0,
            'maintenance_rate': 0
        })

    return stats


def get_room_availability(checkin_date, checkout_date, room_type=None):
    """获取可用房间"""
    try:
        if not isinstance(checkin_date, date):
            checkin_date = datetime.strptime(str(checkin_date), '%Y-%m-%d').date()
        if not isinstance(checkout_date, date):
            checkout_date = datetime.strptime(str(checkout_date), '%Y-%m-%d').date()

        if checkin_date >= checkout_date:
            return []

        # 查找被占用的房间
        occupied_rooms = CheckIn.objects.filter(
            Q(actual_check_in__date__lt=checkout_date) &
            (
                    Q(actual_check_out__date__gt=checkin_date) |
                    Q(actual_check_out__isnull=True) &
                    Q(expected_check_out__gte=checkin_date)
            ) &
            Q(check_in_status='在住')
        ).values_list('room_id', flat=True)

        # 查找被预订的房间
        reserved_rooms = Reservation.objects.filter(
            Q(expected_check_in__lt=checkout_date) &
            Q(expected_check_out__gt=checkin_date) &
            Q(reservation_status='已确认')
        ).values_list('room_id', flat=True)

        # 排除不可用的房间
        unavailable_rooms = set(list(occupied_rooms) + list(reserved_rooms))

        # 查询可用房间
        available_rooms = Room.objects.filter(
            status='空闲'
        ).exclude(
            room_id__in=unavailable_rooms
        )

        if room_type:
            available_rooms = available_rooms.filter(room_type=room_type)

        return list(available_rooms)

    except Exception as e:
        logger.error(f"获取可用房间失败: {str(e)}")
        return []


def calculate_room_price(room, checkin_date, checkout_date, extra_bed_count=0):
    """计算房费"""
    try:
        if not isinstance(checkin_date, date):
            checkin_date = datetime.strptime(str(checkin_date), '%Y-%m-%d').date()
        if not isinstance(checkout_date, date):
            checkout_date = datetime.strptime(str(checkout_date), '%Y-%m-%d').date()

        days = (checkout_date - checkin_date).days
        if days < 1:
            days = 1

        room_price = room.price * days
        extra_bed_price = extra_bed_count * room.extra_bed_price * days if room.extra_bed else Decimal('0')

        total_price = room_price + extra_bed_price

        return {
            'days': days,
            'room_price': room_price,
            'extra_bed_price': extra_bed_price,
            'total_price': total_price,
            'daily_rate': room.price,
            'extra_bed_daily_rate': room.extra_bed_price if room.extra_bed else Decimal('0')
        }

    except Exception as e:
        logger.error(f"计算房费失败: {str(e)}")
        return {
            'days': 0,
            'room_price': Decimal('0'),
            'extra_bed_price': Decimal('0'),
            'total_price': Decimal('0'),
            'daily_rate': Decimal('0'),
            'extra_bed_daily_rate': Decimal('0')
        }


def update_room_status(room, new_status, operator, reason=''):
    """更新房态并记录日志"""
    try:
        old_status = room.status

        if old_status == new_status:
            return True

        # 验证状态转换
        if not is_valid_room_status_transition(old_status, new_status):
            logger.error(f"无效的房态转换: {old_status} -> {new_status}")
            return False

        # 更新房态
        room.status = new_status
        room.save()

        # 记录房态日志
        RoomStatusLog.objects.create(
            room=room,
            old_status=old_status,
            new_status=new_status,
            change_reason=reason,
            operator=operator
        )

        logger.info(f"房间 {room.room_id} 房态更新: {old_status} -> {new_status}")
        return True

    except Exception as e:
        logger.error(f"更新房态失败: {str(e)}")
        return False


def is_valid_room_status_transition(old_status, new_status):
    """验证房态转换是否合法"""
    valid_transitions = {
        '空闲': ['已预订', '已入住', '维修中'],
        '已预订': ['空闲', '已入住', '已取消'],
        '已入住': ['空闲', '维修中'],
        '维修中': ['空闲'],
        '已取消': ['空闲']
    }

    return old_status in valid_transitions and new_status in valid_transitions[old_status]


# ==================== 客户相关工具 ====================
def search_customers(keyword, limit=10):
    """搜索客户"""
    if not keyword or len(keyword) < 2:
        return []

    customers = Customer.objects.filter(
        Q(name__icontains=keyword) |
        Q(phone__icontains=keyword) |
        Q(member_id__icontains=keyword) |
        Q(id_number__icontains=keyword) |
        Q(email__icontains=keyword)
    ).order_by('name')[:limit]

    return list(customers)


def get_customer_stats(customer_id):
    """获取客户统计信息"""
    try:
        customer = Customer.objects.get(customer_id=customer_id)

        # 入住统计
        checkins = CheckIn.objects.filter(customer=customer)
        stay_stats = checkins.aggregate(
            total_stays=Count('check_in_id'),
            total_days=Sum(
                ExpressionWrapper(
                    F('expected_check_out') - F('actual_check_in__date'),
                    output_field=DecimalField()
                )
            )
        )

        # 消费统计
        bills = Bill.objects.filter(check_in__customer=customer)
        consumption_stats = bills.aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            paid_amount=Coalesce(Sum('amount', filter=Q(payment_status='已结')), Decimal('0')),
            unpaid_amount=Coalesce(Sum('amount', filter=Q(payment_status='未结')), Decimal('0'))
        )

        # 预订统计
        reservations = Reservation.objects.filter(customer=customer)
        reservation_stats = reservations.aggregate(
            total_reservations=Count('reservation_id'),
            confirmed=Count('reservation_id', filter=Q(reservation_status='已确认')),
            cancelled=Count('reservation_id', filter=Q(reservation_status='已取消'))
        )

        return {
            'customer': customer,
            'stay_stats': stay_stats,
            'consumption_stats': consumption_stats,
            'reservation_stats': reservation_stats,
            'last_checkin': checkins.order_by('-actual_check_in').first(),
            'favorite_room_type': checkins.values('room__room_type').annotate(
                count=Count('check_in_id')
            ).order_by('-count').first()
        }

    except Customer.DoesNotExist:
        logger.error(f"客户不存在: {customer_id}")
        return None
    except Exception as e:
        logger.error(f"获取客户统计失败: {str(e)}")
        return None


def update_customer_stats(customer_id):
    """更新客户统计信息"""
    try:
        customer = Customer.objects.get(customer_id=customer_id)

        # 重新计算入住天数
        checkins = CheckIn.objects.filter(customer=customer)
        total_stay_days = checkins.aggregate(
            total_days=Sum(
                ExpressionWrapper(
                    F('expected_check_out') - F('actual_check_in__date'),
                    output_field=DecimalField()
                )
            )
        )['total_days'] or 0

        # 重新计算消费总额
        bills = Bill.objects.filter(
            check_in__customer=customer,
            payment_status='已结'
        )
        total_consumption = bills.aggregate(
            total=Coalesce(Sum('amount'), Decimal('0'))
        )['total']

        # 获取最后入住日期
        last_checkin = checkins.order_by('-actual_check_in').first()
        last_visit_date = last_checkin.actual_check_in.date() if last_checkin else None

        # 更新客户信息
        customer.total_stay_days = total_stay_days
        customer.total_consumption = total_consumption
        customer.last_visit_date = last_visit_date
        customer.save()

        logger.info(f"客户 {customer.name} 统计信息已更新")
        return True

    except Exception as e:
        logger.error(f"更新客户统计失败: {str(e)}")
        return False


# ==================== 财务相关工具 ====================
def calculate_revenue(start_date, end_date):
    """计算营收"""
    try:
        if not isinstance(start_date, date):
            start_date = datetime.strptime(str(start_date), '%Y-%m-%d').date()
        if not isinstance(end_date, date):
            end_date = datetime.strptime(str(end_date), '%Y-%m-%d').date()

        # 营收统计
        revenue_stats = Bill.objects.filter(
            payment_time__date__range=[start_date, end_date],
            payment_status='已结'
        ).aggregate(
            total_amount=Coalesce(Sum('amount'), Decimal('0')),
            bill_count=Count('bill_id'),
            avg_amount=Coalesce(Avg('amount'), Decimal('0'))
        )

        # 按消费类型统计
        revenue_by_type = Bill.objects.filter(
            payment_time__date__range=[start_date, end_date],
            payment_status='已结'
        ).values('bill_type').annotate(
            amount=Coalesce(Sum('amount'), Decimal('0')),
            count=Count('bill_id')
        ).order_by('-amount')

        # 按支付方式统计
        revenue_by_method = Bill.objects.filter(
            payment_time__date__range=[start_date, end_date],
            payment_status='已结'
        ).values('payment_method').annotate(
            amount=Coalesce(Sum('amount'), Decimal('0')),
            count=Count('bill_id')
        ).order_by('-amount')

        # 日营收趋势
        daily_revenue = []
        current_date = start_date
        while current_date <= end_date:
            day_revenue = Bill.objects.filter(
                payment_time__date=current_date,
                payment_status='已结'
            ).aggregate(
                amount=Coalesce(Sum('amount'), Decimal('0'))
            )['amount']

            daily_revenue.append({
                'date': current_date,
                'amount': day_revenue,
                'date_str': current_date.strftime('%m-%d')
            })

            current_date += timedelta(days=1)

        return {
            'stats': revenue_stats,
            'by_type': list(revenue_by_type),
            'by_method': list(revenue_by_method),
            'daily': daily_revenue,
            'period': f"{start_date} 至 {end_date}"
        }

    except Exception as e:
        logger.error(f"计算营收失败: {str(e)}")
        return {
            'stats': {
                'total_amount': Decimal('0'),
                'bill_count': 0,
                'avg_amount': Decimal('0')
            },
            'by_type': [],
            'by_method': [],
            'daily': [],
            'period': '',
            'error': str(e)
        }


def get_occupancy_rate(start_date, end_date):
    """计算出租率"""
    try:
        if not isinstance(start_date, date):
            start_date = datetime.strptime(str(start_date), '%Y-%m-%d').date()
        if not isinstance(end_date, date):
            end_date = datetime.strptime(str(end_date), '%Y-%m-%d').date()

        total_rooms = Room.objects.count()
        if total_rooms == 0:
            return []

        occupancy_data = []
        current_date = start_date

        while current_date <= end_date:
            # 计算当日在住房间数
            occupied_rooms = CheckIn.objects.filter(
                Q(actual_check_in__date__lte=current_date) &
                (
                        Q(actual_check_out__date__gt=current_date) |
                        Q(actual_check_out__isnull=True) &
                        Q(expected_check_out__gte=current_date)
                ) &
                Q(check_in_status='在住')
            ).values('room').distinct().count()

            occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0

            occupancy_data.append({
                'date': current_date,
                'occupied_rooms': occupied_rooms,
                'total_rooms': total_rooms,
                'occupancy_rate': round(occupancy_rate, 2),
                'date_str': current_date.strftime('%m-%d')
            })

            current_date += timedelta(days=1)

        return occupancy_data

    except Exception as e:
        logger.error(f"计算出租率失败: {str(e)}")
        return []


# ==================== 报表生成工具 ====================
def generate_daily_report(date=None):
    """生成日报表"""
    if date is None:
        date = timezone.now().date()

    try:
        # 今日统计
        today_stats = {
            'date': date,
            'checkins': CheckIn.objects.filter(actual_check_in__date=date).count(),
            'checkouts': CheckIn.objects.filter(
                actual_check_out__date=date,
                check_in_status='已离店'
            ).count(),
            'reservations': Reservation.objects.filter(
                expected_check_in=date,
                reservation_status='已确认'
            ).count(),
            'cancellations': Reservation.objects.filter(
                cancel_time__date=date,
                reservation_status='已取消'
            ).count(),
            'revenue': Bill.objects.filter(
                payment_time__date=date,
                payment_status='已结'
            ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total'],
            'new_customers': Customer.objects.filter(create_time__date=date).count()
        }

        # 房态统计
        room_stats = get_room_stats()

        # 在住客人统计
        in_house_stats = CheckIn.objects.filter(
            check_in_status='在住'
        ).aggregate(
            total=Count('check_in_id'),
            by_room_type=Count('check_in_id', filter=Q(room__room_type='标准间')),
            by_floor=Count('check_in_id', filter=Q(room__floor=1))
        )

        # 即将离店
        upcoming_checkouts = CheckIn.objects.filter(
            expected_check_out=date + timedelta(days=1),
            check_in_status='在住'
        ).count()

        return {
            'today': today_stats,
            'rooms': room_stats,
            'in_house': in_house_stats,
            'upcoming_checkouts': upcoming_checkouts,
            'generated_at': timezone.now()
        }

    except Exception as e:
        logger.error(f"生成日报表失败: {str(e)}")
        return {
            'error': str(e),
            'today': {},
            'rooms': {},
            'in_house': {},
            'upcoming_checkouts': 0,
            'generated_at': timezone.now()
        }


def generate_monthly_report(year=None, month=None):
    """生成月报表"""
    if year is None:
        year = timezone.now().year
    if month is None:
        month = timezone.now().month

    try:
        month_start, month_end = get_month_range(year, month)

        # 月度统计
        monthly_stats = {
            'year': year,
            'month': month,
            'period': f"{year}年{month}月",
            'checkins': CheckIn.objects.filter(
                actual_check_in__date__range=[month_start, month_end]
            ).count(),
            'checkouts': CheckIn.objects.filter(
                actual_check_out__date__range=[month_start, month_end],
                check_in_status='已离店'
            ).count(),
            'reservations': Reservation.objects.filter(
                expected_check_in__range=[month_start, month_end],
                reservation_status='已确认'
            ).count(),
            'revenue': Bill.objects.filter(
                payment_time__date__range=[month_start, month_end],
                payment_status='已结'
            ).aggregate(total=Coalesce(Sum('amount'), Decimal('0')))['total'],
            'new_customers': Customer.objects.filter(
                create_time__date__range=[month_start, month_end]
            ).count()
        }

        # 房型营收统计
        revenue_by_room_type = Bill.objects.filter(
            payment_time__date__range=[month_start, month_end],
            payment_status='已结',
            bill_type='房费'
        ).values('check_in__room__room_type').annotate(
            amount=Coalesce(Sum('amount'), Decimal('0')),
            count=Count('bill_id')
        ).order_by('-amount')

        # 客户消费排行
        top_customers = Bill.objects.filter(
            payment_time__date__range=[month_start, month_end],
            payment_status='已结'
        ).values('check_in__customer__name', 'check_in__customer__customer_type').annotate(
            customer_name=F('check_in__customer__name'),
            amount=Coalesce(Sum('amount'), Decimal('0')),
            count=Count('bill_id')
        ).order_by('-amount')[:10]

        # 出租率统计
        occupancy_data = get_occupancy_rate(month_start, month_end)
        avg_occupancy = sum(item['occupancy_rate'] for item in occupancy_data) / len(
            occupancy_data) if occupancy_data else 0

        return {
            'monthly': monthly_stats,
            'revenue_by_room_type': list(revenue_by_room_type),
            'top_customers': list(top_customers),
            'occupancy': {
                'data': occupancy_data,
                'average': round(avg_occupancy, 2)
            },
            'generated_at': timezone.now()
        }

    except Exception as e:
        logger.error(f"生成月报表失败: {str(e)}")
        return {
            'error': str(e),
            'monthly': {},
            'revenue_by_room_type': [],
            'top_customers': [],
            'occupancy': {'data': [], 'average': 0},
            'generated_at': timezone.now()
        }


# ==================== 导出工具 ====================
def export_to_csv(queryset, fields, filename):
    """导出数据到CSV"""
    try:
        output = StringIO()
        writer = csv.writer(output)

        # 写入表头
        writer.writerow(fields)

        # 写入数据
        for obj in queryset:
            row = []
            for field in fields:
                if hasattr(obj, field):
                    value = getattr(obj, field)
                    if callable(value):
                        value = value()
                elif '__' in field:  # 处理关联字段
                    parts = field.split('__')
                    value = obj
                    for part in parts:
                        if value is None:
                            break
                        value = getattr(value, part, None)
                        if callable(value):
                            value = value()
                else:
                    value = ''

                # 处理特殊类型
                if isinstance(value, datetime):
                    value = value.strftime('%Y-%m-%d %H:%M:%S')
                elif isinstance(value, date):
                    value = value.strftime('%Y-%m-%d')
                elif value is None:
                    value = ''

                row.append(str(value))

            writer.writerow(row)

        output.seek(0)
        return output.getvalue()

    except Exception as e:
        logger.error(f"导出CSV失败: {str(e)}")
        return None


def export_to_json(queryset, fields, filename):
    """导出数据到JSON"""
    try:
        data = []
        for obj in queryset:
            item = {}
            for field in fields:
                if hasattr(obj, field):
                    value = getattr(obj, field)
                    if callable(value):
                        value = value()
                elif '__' in field:  # 处理关联字段
                    parts = field.split('__')
                    value = obj
                    for part in parts:
                        if value is None:
                            break
                        value = getattr(value, part, None)
                        if callable(value):
                            value = value()
                else:
                    value = None

                # 处理特殊类型
                if isinstance(value, (datetime, date)):
                    value = value.isoformat()
                elif isinstance(value, Decimal):
                    value = float(value)

                item[field] = value

            data.append(item)

        return json.dumps(data, ensure_ascii=False, indent=2)

    except Exception as e:
        logger.error(f"导出JSON失败: {str(e)}")
        return None


# ==================== 验证工具 ====================
def validate_phone_number(phone):
    """验证手机号码"""
    import re
    pattern = r'^1[3-9]\d{9}$'
    return bool(re.match(pattern, phone))


def validate_id_number(id_number, id_type='身份证'):
    """验证证件号码"""
    if id_type == '身份证':
        import re
        pattern = r'^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$'
        return bool(re.match(pattern, id_number))
    return True


def validate_email(email):
    """验证邮箱"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


# ==================== 格式化工具 ====================
def format_currency(amount):
    """格式化货币金额"""
    try:
        if amount is None:
            return '¥0.00'
        amount = Decimal(str(amount))
        return f'¥{amount:,.2f}'
    except:
        return '¥0.00'


def format_percentage(value, total):
    """格式化百分比"""
    try:
        if total == 0:
            return '0.00%'
        percentage = (value / total) * 100
        return f'{percentage:.2f}%'
    except:
        return '0.00%'


def format_duration(days):
    """格式化时长"""
    if days == 1:
        return '1天'
    elif days < 30:
        return f'{days}天'
    elif days < 365:
        months = days // 30
        remaining_days = days % 30
        if remaining_days > 0:
            return f'{months}个月{remaining_days}天'
        else:
            return f'{months}个月'
    else:
        years = days // 365
        remaining_days = days % 365
        if remaining_days > 0:
            months = remaining_days // 30
            if months > 0:
                return f'{years}年{months}个月'
            else:
                return f'{years}年{remaining_days}天'
        else:
            return f'{years}年'


def format_room_status(status):
    """格式化房态"""
    status_map = {
        '空闲': 'success',
        '已入住': 'danger',
        '已预订': 'warning',
        '维修中': 'secondary',
        '已取消': 'light'
    }
    return status_map.get(status, 'secondary')


def format_payment_status(status):
    """格式化支付状态"""
    status_map = {
        '未结': 'warning',
        '已结': 'success',
        '挂账': 'info'
    }
    return status_map.get(status, 'secondary')


# ==================== 业务逻辑工具 ====================
def can_checkin_room(room, checkin_date, checkout_date):
    """检查房间是否可以入住"""
    try:
        if room.status != '空闲':
            return False, f'房间当前状态为{room.get_status_display()}'

        # 检查是否有冲突的入住
        conflicting_checkins = CheckIn.objects.filter(
            room=room,
            check_in_status='在住',
            actual_check_in__date__lt=checkout_date,
        ).filter(
            Q(actual_check_out__date__gt=checkin_date) |
            Q(actual_check_out__isnull=True)
        ).exists()

        if conflicting_checkins:
            return False, '房间在选定日期内已被占用'

        # 检查是否有冲突的预订
        conflicting_reservations = Reservation.objects.filter(
            room=room,
            reservation_status='已确认',
            expected_check_in__lt=checkout_date,
            expected_check_out__gt=checkin_date
        ).exists()

        if conflicting_reservations:
            return False, '房间在选定日期内已被预订'

        return True, '房间可用'

    except Exception as e:
        logger.error(f"检查房间可用性失败: {str(e)}")
        return False, '检查失败'


def can_cancel_reservation(reservation):
    """检查预订是否可以取消"""
    try:
        if reservation.reservation_status in ['已取消', '已入住']:
            return False, f'预订已{reservation.get_reservation_status_display()}'

        # 检查入住日期是否已过
        if reservation.expected_check_in <= date.today():
            return False, '入住日期已过，不能取消'

        return True, '可以取消'

    except Exception as e:
        logger.error(f"检查预订取消条件失败: {str(e)}")
        return False, '检查失败'


def can_checkout_checkin(checkin):
    """检查是否可以离店"""
    try:
        if checkin.check_in_status != '在住':
            return False, '客人不在住状态'

        # 检查是否有未结账单
        unpaid_bills = Bill.objects.filter(
            check_in=checkin,
            payment_status='未结'
        ).exists()

        if unpaid_bills:
            return False, '有未结账单，请先结账'

        return True, '可以离店'

    except Exception as e:
        logger.error(f"检查离店条件失败: {str(e)}")
        return False, '检查失败'


# ==================== 数据清理工具 ====================
def cleanup_old_data(days=90):
    """清理旧数据"""
    try:
        cutoff_date = timezone.now() - timedelta(days=days)

        # 清理旧的操作日志（保留90天）
        old_logs = OperationLog.objects.filter(
            operation_time__lt=cutoff_date
        )
        log_count = old_logs.count()
        old_logs.delete()

        # 清理旧的房态日志（保留30天）
        old_room_logs = RoomStatusLog.objects.filter(
            change_time__lt=timezone.now() - timedelta(days=30)
        )
        room_log_count = old_room_logs.count()
        old_room_logs.delete()

        logger.info(f"数据清理完成: 操作日志{log_count}条, 房态日志{room_log_count}条")
        return True, f'清理完成: 操作日志{log_count}条, 房态日志{room_log_count}条'

    except Exception as e:
        logger.error(f"数据清理失败: {str(e)}")
        return False, f'清理失败: {str(e)}'


def backup_database():
    """备份数据库"""
    try:
        import os
        from django.conf import settings
        import subprocess

        backup_dir = os.path.join(settings.BASE_DIR, 'backups')
        os.makedirs(backup_dir, exist_ok=True)

        timestamp = timezone.now().strftime('%Y%m%d_%H%M%S')
        backup_file = os.path.join(backup_dir, f'hotel_backup_{timestamp}.sql')

        # 这里需要根据你的数据库配置调整
        db_settings = settings.DATABASES['default']
        cmd = [
            'mysqldump',
            '-h', db_settings.get('HOST', 'localhost'),
            '-P', str(db_settings.get('PORT', '3306')),
            '-u', db_settings['USER'],
            '-p' + db_settings['PASSWORD'],
            db_settings['NAME'],
            '>', backup_file
        ]

        # 执行备份命令
        result = subprocess.run(' '.join(cmd), shell=True, capture_output=True, text=True)

        if result.returncode == 0:
            logger.info(f"数据库备份成功: {backup_file}")
            return True, backup_file
        else:
            logger.error(f"数据库备份失败: {result.stderr}")
            return False, result.stderr

    except Exception as e:
        logger.error(f"数据库备份失败: {str(e)}")
        return False, str(e)


# ==================== 缓存工具 ====================
from django.core.cache import cache


def get_cached_data(key, func, timeout=300):
    """获取缓存数据"""
    data = cache.get(key)
    if data is None:
        data = func()
        if data is not None:
            cache.set(key, data, timeout)
    return data


def clear_cache_by_prefix(prefix):
    """清除指定前缀的缓存"""
    if hasattr(cache, 'delete_pattern'):  # Redis缓存
        import redis
        try:
            r = redis.Redis.from_url(settings.CACHES['default']['LOCATION'])
            keys = r.keys(f'*{prefix}*')
            if keys:
                r.delete(*keys)
                logger.info(f"清除缓存: {len(keys)}个键")
                return True
        except Exception as e:
            logger.error(f"清除缓存失败: {str(e)}")
    return False


# ==================== 通知工具 ====================
def send_sms_notification(phone, message):
    """发送短信通知"""
    try:
        # 这里需要集成短信服务商API
        # 例如: 阿里云短信、腾讯云短信等
        logger.info(f"发送短信到 {phone}: {message}")
        return True
    except Exception as e:
        logger.error(f"发送短信失败: {str(e)}")
        return False


def send_email_notification(email, subject, message):
    """发送邮件通知"""
    try:
        from django.core.mail import send_mail
        from django.conf import settings

        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[email],
            fail_silently=False,
        )
        logger.info(f"发送邮件到 {email}: {subject}")
        return True
    except Exception as e:
        logger.error(f"发送邮件失败: {str(e)}")
        return False