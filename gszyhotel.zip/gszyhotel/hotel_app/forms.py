from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import datetime, date, timedelta
from decimal import Decimal
from .models import *
from .utils import *
from django.db.models import Q
# ==================== 认证相关表单 ====================
class CustomLoginForm(AuthenticationForm):
    """自定义登录表单"""
    username = forms.CharField(
        label='用户名',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入用户名',
            'autofocus': True
        })
    )
    password = forms.CharField(
        label='密码',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入密码'
        })
    )


class StaffProfileForm(forms.ModelForm):
    """员工个人资料表单"""

    class Meta:
        model = Staff
        fields = ['name', 'gender', 'phone', 'email', 'department', 'position']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'department': forms.TextInput(attrs={'class': 'form-control'}),
            'position': forms.TextInput(attrs={'class': 'form-control'}),
        }


class StaffForm(forms.ModelForm):
    """员工管理表单"""
    password = forms.CharField(
        label='密码',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True
    )
    confirm_password = forms.CharField(
        label='确认密码',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True
    )

    class Meta:
        model = Staff
        fields = ['username', 'name', 'gender', 'phone', 'email',
                  'department', 'position', 'role', 'status']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'department': forms.TextInput(attrs={'class': 'form-control'}),
            'position': forms.TextInput(attrs={'class': 'form-control'}),
            'role': forms.Select(attrs={'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password and password != confirm_password:
            raise ValidationError('两次输入的密码不一致！')

        if password and len(password) < 6:
            raise ValidationError('密码长度至少6位！')

        return cleaned_data


# ==================== 客房管理表单 ====================
class RoomForm(forms.ModelForm):
    """客房表单"""

    class Meta:
        model = Room
        fields = ['room_id', 'room_type', 'floor', 'status', 'price',
                  'description', 'capacity', 'extra_bed', 'extra_bed_price',
                  'room_features']
        widgets = {
            'room_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '如: 101, 201等'
            }),
            'room_type': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '如: 标准间, 大床房, 套房等'
            }),
            'floor': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 99
            }),
            'status': forms.Select(attrs={'class': 'form-control'}),
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '请输入客房描述...'
            }),
            'capacity': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 10
            }),
            'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'extra_bed_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'room_features': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入客房特色，每行一个...'
            }),
        }

    def clean_room_id(self):
        room_id = self.cleaned_data['room_id']
        if self.instance.pk is None:  # 新增时检查
            if Room.objects.filter(room_id=room_id).exists():
                raise ValidationError('客房编号已存在！')
        return room_id

    def clean_price(self):
        price = self.cleaned_data['price']
        if price <= 0:
            raise ValidationError('价格必须大于0！')
        return price


class RoomStatusUpdateForm(forms.Form):
    """房态更新表单"""
    room_id = forms.CharField(widget=forms.HiddenInput())
    status = forms.ChoiceField(
        label='新状态',
        choices=Room.ROOM_STATUS_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    reason = forms.CharField(
        label='变更原因',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入变更原因...'
        })
    )


# ==================== 客户管理表单 ====================
class CustomerForm(forms.ModelForm):
    """客户表单"""

    class Meta:
        model = Customer
        fields = ['name', 'id_type', 'id_number', 'phone', 'email',
                  'gender', 'birthday', 'customer_type', 'member_level',
                  'member_id', 'is_blacklist', 'blacklist_reason']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入客户姓名'
            }),
            'id_type': forms.Select(attrs={'class': 'form-control'}),
            'id_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入证件号码'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入手机号码'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入电子邮箱'
            }),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'birthday': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'customer_type': forms.Select(attrs={'class': 'form-control'}),
            'member_level': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入会员等级'
            }),
            'member_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入会员卡号'
            }),
            'is_blacklist': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'blacklist_reason': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入黑名单原因...'
            }),
        }

    def clean_id_number(self):
        id_type = self.cleaned_data.get('id_type')
        id_number = self.cleaned_data['id_number']

        if self.instance.pk is None:  # 新增时检查
            if Customer.objects.filter(id_type=id_type, id_number=id_number).exists():
                raise ValidationError('该证件号码已存在！')
        return id_number

    def clean_phone(self):
        phone = self.cleaned_data['phone']
        if phone and len(phone) < 11:
            raise ValidationError('手机号码格式不正确！')
        return phone


class CustomerSearchForm(forms.Form):
    """客户搜索表单"""
    search = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '姓名/手机/证件号/会员卡号'
        })
    )
    customer_type = forms.ChoiceField(
        choices=[('', '全部类型')] + list(Customer.CUSTOMER_TYPE_CHOICES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    member_level = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '会员等级'
        })
    )


# ==================== 预订管理表单 ====================
class ReservationForm(forms.ModelForm):
    """预订表单"""
    customer_search = forms.CharField(
        label='搜索客户',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '输入姓名/手机号搜索客户',
            'autocomplete': 'off'
        })
    )

    room_search = forms.CharField(
        label='搜索房间',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '输入房间号搜索房间',
            'autocomplete': 'off'
        })
    )

    class Meta:
        model = Reservation
        fields = ['customer', 'room', 'room_type', 'expected_check_in',
                  'expected_check_out', 'adult_count', 'child_count',
                  'extra_bed', 'deposit', 'payment_method', 'reservation_status',
                  'source', 'remark']
        widgets = {
            'customer': forms.Select(attrs={'class': 'form-control'}),
            'room': forms.Select(attrs={'class': 'form-control'}),
            'room_type': forms.TextInput(attrs={
                'class': 'form-control',
                'readonly': 'readonly',  # 设为只读，自动填充
                'placeholder': '自动根据房间填写'
            }),
            'expected_check_in': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'expected_check_out': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'adult_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 10
            }),
            'child_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 10
            }),
            'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'deposit': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'reservation_status': forms.Select(attrs={'class': 'form-control'}),
            'source': forms.Select(attrs={'class': 'form-control'}),
            'remark': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入备注...'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 设置初始值
        self.fields['expected_check_in'].initial = date.today()
        self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)
        self.fields['adult_count'].initial = 1
        self.fields['reservation_status'].initial = '待确认'
        self.fields['room_type'].initial = ''  # 初始为空，通过JavaScript填充

        # 只显示空闲房间
        self.fields['room'].queryset = Room.objects.filter(status='空闲')

    def clean_room_type(self):
        """确保 room_type 不为空"""
        room_type = self.cleaned_data.get('room_type')
        if not room_type:
            raise ValidationError('请选择房间，房型将自动填写')
        return room_type
# class ReservationForm(forms.ModelForm):
#     """预订表单"""
#     customer_search = forms.CharField(
#         label='搜索客户',
#         required=False,
#         widget=forms.TextInput(attrs={
#             'class': 'form-control',
#             'placeholder': '输入姓名/手机号搜索客户',
#             'autocomplete': 'off'
#         })
#     )
#
#     class Meta:
#         model = Reservation
#         fields = ['customer', 'room', 'room_type', 'expected_check_in',
#                   'expected_check_out', 'adult_count', 'child_count',
#                   'extra_bed', 'deposit', 'payment_method', 'reservation_status',
#                   'source', 'remark']
#         widgets = {
#             'customer': forms.Select(attrs={'class': 'form-control'}),
#             'room': forms.Select(attrs={'class': 'form-control'}),
#             'room_type': forms.TextInput(attrs={'class': 'form-control'}),
#             'expected_check_in': forms.DateInput(attrs={
#                 'class': 'form-control',
#                 'type': 'date'
#             }),
#             'expected_check_out': forms.DateInput(attrs={
#                 'class': 'form-control',
#                 'type': 'date'
#             }),
#             'adult_count': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': 1,
#                 'max': 10
#             }),
#             'child_count': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': 0,
#                 'max': 10
#             }),
#             'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
#             'deposit': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'step': '0.01',
#                 'min': '0'
#             }),
#             'payment_method': forms.Select(attrs={'class': 'form-control'}),
#             'reservation_status': forms.Select(attrs={'class': 'form-control'}),
#             'source': forms.Select(attrs={'class': 'form-control'}),
#             'remark': forms.Textarea(attrs={
#                 'class': 'form-control',
#                 'rows': 2,
#                 'placeholder': '请输入备注...'
#             }),
#         }
#
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         # 设置初始值
#         self.fields['expected_check_in'].initial = date.today()
#         self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)
#         self.fields['adult_count'].initial = 1
#         self.fields['reservation_status'].initial = '待确认'
#
#     def clean(self):
#         cleaned_data = super().clean()
#         expected_check_in = cleaned_data.get('expected_check_in')
#         expected_check_out = cleaned_data.get('expected_check_out')
#         room = cleaned_data.get('room')
#
#         if expected_check_in and expected_check_out:
#             if expected_check_in >= expected_check_out:
#                 raise ValidationError('离店日期必须晚于入住日期！')
#
#             if expected_check_in < date.today():
#                 raise ValidationError('入住日期不能早于今天！')
#
#             # 检查房间是否可用
#             if room and room.status != '空闲':
#                 raise ValidationError(f'房间 {room.room_id} 当前不可用！')
#
#             # 检查房间是否被占用
#             if room:
#                 occupied = CheckIn.objects.filter(
#                     room=room,
#                     check_in_status='在住',
#                     actual_check_in__date__lt=expected_check_out,
#                 ).filter(
#                     Q(actual_check_out__date__gt=expected_check_in) |
#                     Q(actual_check_out__isnull=True)
#                 ).exists()
#
#                 if occupied:
#                     raise ValidationError(f'房间 {room.room_id} 在选定日期内已被占用！')
#
#         return cleaned_data


class ReservationCancelForm(forms.Form):
    """预订取消表单"""
    cancel_reason = forms.CharField(
        label='取消原因',
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 3,
            'placeholder': '请输入取消原因...',
            'required': True
        })
    )


# ==================== 入住管理表单 ====================
# forms.py - 修复 CheckInForm
class CheckInForm(forms.ModelForm):
    """入住表单（用于预订入住）"""

    class Meta:
        model = CheckIn
        fields = ['actual_check_in', 'expected_check_out', 'adult_count',
                  'child_count', 'extra_bed', 'extra_bed_count', 'payment_method',
                  'remark']
        widgets = {
            'actual_check_in': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'expected_check_out': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'adult_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 10
            }),
            'child_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 10
            }),
            'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'extra_bed_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 5
            }),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'remark': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入备注...'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 设置初始值
        today = timezone.now()
        tomorrow = today + timedelta(days=1)

        self.fields['actual_check_in'].initial = today
        self.fields['expected_check_out'].initial = tomorrow.date()
        self.fields['adult_count'].initial = 1

        # 确保日期格式正确
        self.fields['actual_check_in'].widget.attrs['value'] = today.strftime('%Y-%m-%dT%H:%M')
        self.fields['expected_check_out'].widget.attrs['value'] = tomorrow.strftime('%Y-%m-%d')

    def clean(self):
        cleaned_data = super().clean()
        actual_check_in = cleaned_data.get('actual_check_in')
        expected_check_out = cleaned_data.get('expected_check_out')
        extra_bed = cleaned_data.get('extra_bed')
        extra_bed_count = cleaned_data.get('extra_bed_count')

        if actual_check_in and expected_check_out:
            # 确保 expected_check_out 是 date 类型
            if isinstance(expected_check_out, datetime):
                expected_check_out_date = expected_check_out.date()
            else:
                expected_check_out_date = expected_check_out

            # 确保 actual_check_in 是 datetime 类型
            if isinstance(actual_check_in, datetime):
                actual_check_in_date = actual_check_in.date()
            else:
                actual_check_in_date = actual_check_in

            if expected_check_out_date <= actual_check_in_date:
                raise ValidationError('离店日期必须晚于入住日期！')

        if extra_bed and (not extra_bed_count or extra_bed_count <= 0):
            raise ValidationError('请填写加床数量！')

        return cleaned_data



# class CheckInForm(forms.ModelForm):
#     """入住表单（用于预订入住）"""
#
#     class Meta:
#         model = CheckIn
#         fields = ['actual_check_in', 'expected_check_out', 'adult_count',
#                   'child_count', 'extra_bed', 'extra_bed_count', 'payment_method',
#                   'remark']
#         widgets = {
#             'actual_check_in': forms.DateTimeInput(attrs={
#                 'class': 'form-control',
#                 'type': 'datetime-local'
#             }),
#             'expected_check_out': forms.DateInput(attrs={
#                 'class': 'form-control',
#                 'type': 'date'
#             }),
#             'adult_count': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': 1,
#                 'max': 10
#             }),
#             'child_count': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': 0,
#                 'max': 10
#             }),
#             'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
#             'extra_bed_count': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': 0,
#                 'max': 5
#             }),
#             'payment_method': forms.Select(attrs={'class': 'form-control'}),
#             'remark': forms.Textarea(attrs={
#                 'class': 'form-control',
#                 'rows': 2,
#                 'placeholder': '请输入备注...'
#             }),
#         }
#
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         # 设置初始值
#         self.fields['actual_check_in'].initial = timezone.now()
#         self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)
#         self.fields['adult_count'].initial = 1
#
#     def clean(self):
#         cleaned_data = super().clean()
#         expected_check_out = cleaned_data.get('expected_check_out')
#         extra_bed = cleaned_data.get('extra_bed')
#         extra_bed_count = cleaned_data.get('extra_bed_count')
#
#         if expected_check_out and expected_check_out <= date.today():
#             raise ValidationError('离店日期必须晚于今天！')
#
#         if extra_bed and (not extra_bed_count or extra_bed_count <= 0):
#             raise ValidationError('请填写加床数量！')
#
#         return cleaned_data


class DirectCheckInForm(forms.ModelForm):
    """直接入住表单（无预订）"""
    customer_search = forms.CharField(
        label='搜索客户',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '输入姓名/手机号搜索客户',
            'autocomplete': 'off'
        })
    )

    class Meta:
        model = CheckIn
        fields = ['customer', 'room', 'actual_check_in', 'expected_check_out',
                  'adult_count', 'child_count', 'extra_bed', 'extra_bed_count',
                  'payment_method', 'remark']
        widgets = {
            'customer': forms.Select(attrs={'class': 'form-control'}),
            'room': forms.Select(attrs={'class': 'form-control'}),
            'actual_check_in': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'expected_check_out': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'adult_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 10
            }),
            'child_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 10
            }),
            'extra_bed': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'extra_bed_count': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 5
            }),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'remark': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入备注...'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 设置初始值
        self.fields['actual_check_in'].initial = timezone.now()
        self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)
        self.fields['adult_count'].initial = 1

        # 只显示空闲房间
        self.fields['room'].queryset = Room.objects.filter(status='空闲')

    def clean(self):
        cleaned_data = super().clean()
        room = cleaned_data.get('room')
        expected_check_out = cleaned_data.get('expected_check_out')

        if room and room.status != '空闲':
            raise ValidationError(f'房间 {room.room_id} 当前不可用！')

        if expected_check_out and expected_check_out <= date.today():
            raise ValidationError('离店日期必须晚于今天！')

        return cleaned_data


class CheckoutForm(forms.Form):
    """离店表单"""
    payment_method = forms.ChoiceField(
        label='支付方式',
        choices=Bill.PAYMENT_METHOD_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    remark = forms.CharField(
        label='备注',
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 2,
            'placeholder': '请输入备注...'
        })
    )


class ExtendStayForm(forms.Form):
    """续住表单"""
    new_checkout_date = forms.DateField(
        label='新的离店日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    reason = forms.CharField(
        label='续住原因',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入续住原因...'
        })
    )


# ==================== 账单管理表单 ====================
class BillForm(forms.ModelForm):
    """账单表单"""

    class Meta:
        model = Bill
        fields = ['check_in', 'bill_type', 'item_name', 'quantity',
                  'unit_price', 'consumption_time', 'payment_method', 'remark']
        widgets = {
            'check_in': forms.Select(attrs={'class': 'form-control'}),
            'bill_type': forms.Select(attrs={'class': 'form-control'}),
            'item_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入项目名称'
            }),
            'quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 999,
                'step': '1'
            }),
            'unit_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0',
                'placeholder': '0.00'
            }),
            'consumption_time': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'payment_method': forms.Select(attrs={'class': 'form-control'}),
            'remark': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': '请输入备注...'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['consumption_time'].initial = timezone.now()
        self.fields['quantity'].initial = 1
        self.fields['unit_price'].initial = 0

    def clean_unit_price(self):
        unit_price = self.cleaned_data['unit_price']
        if unit_price < 0:
            raise ValidationError('单价不能为负数！')
        return unit_price

    def clean_quantity(self):
        quantity = self.cleaned_data['quantity']
        if quantity <= 0:
            raise ValidationError('数量必须大于0！')
        return quantity


class BillPaymentForm(forms.Form):
    """账单支付表单"""
    payment_method = forms.ChoiceField(
        label='支付方式',
        choices=Bill.PAYMENT_METHOD_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    remark = forms.CharField(
        label='备注',
        required=False,
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 2,
            'placeholder': '请输入备注...'
        })
    )


# ==================== 报表查询表单 ====================
class DateRangeForm(forms.Form):
    """日期范围表单"""
    start_date = forms.DateField(
        label='开始日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    end_date = forms.DateField(
        label='结束日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')

        if start_date and end_date:
            if start_date > end_date:
                raise ValidationError('开始日期不能晚于结束日期！')

            if (end_date - start_date).days > 365:
                raise ValidationError('查询时间范围不能超过一年！')

        return cleaned_data


class RoomAvailabilityForm(forms.Form):
    """客房可用性查询表单"""
    checkin_date = forms.DateField(
        label='入住日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    checkout_date = forms.DateField(
        label='离店日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    room_type = forms.CharField(
        label='房型',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入房型'
        })
    )
    floor = forms.IntegerField(
        label='楼层',
        required=False,
        min_value=1,
        max_value=99,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入楼层'
        })
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        today = date.today()
        self.fields['checkin_date'].initial = today
        self.fields['checkout_date'].initial = today + timedelta(days=1)

    def clean(self):
        cleaned_data = super().clean()
        checkin_date = cleaned_data.get('checkin_date')
        checkout_date = cleaned_data.get('checkout_date')

        if checkin_date and checkout_date:
            if checkin_date >= checkout_date:
                raise ValidationError('离店日期必须晚于入住日期！')

            if checkin_date < date.today():
                raise ValidationError('入住日期不能早于今天！')

        return cleaned_data


class GuestHistoryForm(forms.Form):
    """客人历史查询表单"""
    customer_id = forms.IntegerField(
        label='客户ID',
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入客户ID'
        })
    )
    phone = forms.CharField(
        label='手机号',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入手机号'
        })
    )
    id_number = forms.CharField(
        label='证件号',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入证件号'
        })
    )
    name = forms.CharField(
        label='姓名',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入姓名'
        })
    )


class BillingQueryForm(forms.Form):
    """账单查询表单"""
    customer_id = forms.IntegerField(
        label='客户ID',
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入客户ID'
        })
    )
    checkin_id = forms.IntegerField(
        label='入住单号',
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入入住单号'
        })
    )
    bill_type = forms.ChoiceField(
        label='消费类型',
        choices=[('', '全部类型')] + list(Bill.BILL_TYPE_CHOICES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    payment_status = forms.ChoiceField(
        label='支付状态',
        choices=[('', '全部状态')] + list(Bill.PAYMENT_STATUS_CHOICES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    date_from = forms.DateField(
        label='开始日期',
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    date_to = forms.DateField(
        label='结束日期',
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )


class ReservationQueryForm(forms.Form):
    """预订查询表单"""
    reservation_id = forms.IntegerField(
        label='预订号',
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入预订号'
        })
    )
    customer_id = forms.IntegerField(
        label='客户ID',
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入客户ID'
        })
    )
    phone = forms.CharField(
        label='手机号',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入手机号'
        })
    )
    status = forms.ChoiceField(
        label='状态',
        choices=[('', '全部状态')] + list(Reservation.RESERVATION_STATUS_CHOICES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )


# ==================== 快速操作表单 ====================
class QuickCheckInForm(forms.Form):
    """快速入住表单"""
    customer = forms.ModelChoiceField(
        label='客户',
        queryset=Customer.objects.all(),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    room = forms.ModelChoiceField(
        label='房间',
        queryset=Room.objects.filter(status='空闲'),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    expected_check_out = forms.DateField(
        label='离店日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    adult_count = forms.IntegerField(
        label='成人数',
        initial=1,
        min_value=1,
        max_value=10,
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )
    payment_method = forms.ChoiceField(
        label='支付方式',
        choices=CheckIn.PAYMENT_METHOD_CHOICES,
        initial='现金',
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)

    def clean(self):
        cleaned_data = super().clean()
        expected_check_out = cleaned_data.get('expected_check_out')

        if expected_check_out and expected_check_out <= date.today():
            raise ValidationError('离店日期必须晚于今天！')

        return cleaned_data


class QuickCheckoutForm(forms.Form):
    """快速离店表单"""
    checkin_id = forms.IntegerField(
        label='入住单号',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入入住单号',
            'required': True
        })
    )

    def clean_checkin_id(self):
        checkin_id = self.cleaned_data['checkin_id']
        try:
            checkin = CheckIn.objects.get(checkin_id=checkin_id, check_in_status='在住')
            return checkin_id
        except CheckIn.DoesNotExist:
            raise ValidationError('入住记录不存在或客人已离店！')


class QuickReservationForm(forms.Form):
    """快速预订表单"""
    customer = forms.ModelChoiceField(
        label='客户',
        queryset=Customer.objects.all(),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    room = forms.ModelChoiceField(
        label='房间',
        queryset=Room.objects.filter(status='空闲'),
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    expected_check_in = forms.DateField(
        label='入住日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    expected_check_out = forms.DateField(
        label='离店日期',
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    deposit = forms.DecimalField(
        label='订金',
        required=False,
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'step': '0.01',
            'min': '0'
        })
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['expected_check_in'].initial = date.today()
        self.fields['expected_check_out'].initial = date.today() + timedelta(days=1)

    def clean(self):
        cleaned_data = super().clean()
        expected_check_in = cleaned_data.get('expected_check_in')
        expected_check_out = cleaned_data.get('expected_check_out')

        if expected_check_in and expected_check_out:
            if expected_check_in >= expected_check_out:
                raise ValidationError('离店日期必须晚于入住日期！')

            if expected_check_in < date.today():
                raise ValidationError('入住日期不能早于今天！')

        return cleaned_data


class QuickBillingForm(forms.Form):
    """快速结账表单"""
    checkin_id = forms.IntegerField(
        label='入住单号',
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入入住单号',
            'required': True
        })
    )
    payment_method = forms.ChoiceField(
        label='支付方式',
        choices=Bill.PAYMENT_METHOD_CHOICES,
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def clean_checkin_id(self):
        checkin_id = self.cleaned_data['checkin_id']
        try:
            checkin = CheckIn.objects.get(checkin_id=checkin_id, check_in_status='在住')
            return checkin_id
        except CheckIn.DoesNotExist:
            raise ValidationError('入住记录不存在或客人已离店！')


# ==================== 系统管理表单 ====================
class SystemBackupForm(forms.Form):
    """系统备份表单"""
    backup_type = forms.ChoiceField(
        label='备份类型',
        choices=[
            ('database', '数据库备份'),
            ('reports', '报表备份'),
            ('logs', '日志备份')
        ],
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'})
    )
    include_data = forms.BooleanField(
        label='包含数据',
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )
    backup_name = forms.CharField(
        label='备份名称',
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '请输入备份名称'
        })
    )


class SystemSettingsForm(forms.Form):
    """系统设置表单"""
    site_name = forms.CharField(
        label='系统名称',
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    site_title = forms.CharField(
        label='系统标题',
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    checkin_time = forms.TimeField(
        label='入住时间',
        widget=forms.TimeInput(attrs={
            'class': 'form-control',
            'type': 'time'
        })
    )
    checkout_time = forms.TimeField(
        label='离店时间',
        widget=forms.TimeInput(attrs={
            'class': 'form-control',
            'type': 'time'
        })
    )
    enable_online_payment = forms.BooleanField(
        label='启用在线支付',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )
    enable_sms_notification = forms.BooleanField(
        label='启用短信通知',
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )


# ==================== 通用筛选表单 ====================
class FilterForm(forms.Form):
    """通用筛选表单"""
    search = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '搜索...'
        })
    )
    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        })
    )
    status = forms.ChoiceField(
        required=False,
        choices=[('', '全部状态')],
        widget=forms.Select(attrs={'class': 'form-control'})
    )


class PaginationForm(forms.Form):
    """分页表单"""
    page = forms.IntegerField(
        required=False,
        min_value=1,
        initial=1,
        widget=forms.HiddenInput()
    )
    page_size = forms.ChoiceField(
        required=False,
        choices=[
            (10, '10条/页'),
            (20, '20条/页'),
            (50, '50条/页'),
            (100, '100条/页')
        ],
        initial=20,
        widget=forms.Select(attrs={'class': 'form-control'})
    )


# ==================== 导出表单 ====================
class ExportForm(forms.Form):
    """导出表单"""
    format = forms.ChoiceField(
        label='导出格式',
        choices=[
            ('csv', 'CSV格式'),
            ('excel', 'Excel格式'),
            ('pdf', 'PDF格式')
        ],
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'})
    )
    include_headers = forms.BooleanField(
        label='包含表头',
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )
    export_all = forms.BooleanField(
        label='导出全部数据',
        initial=False,
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )