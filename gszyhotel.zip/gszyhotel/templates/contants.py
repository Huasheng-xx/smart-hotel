import os

def print_directory_tree(startpath, indent=''):
    """递归打印目录结构"""
    try:
        items = sorted(os.listdir(startpath))
    except PermissionError:
        print(indent + '[Permission Denied]')
        return

    for i, item in enumerate(items):
        path = os.path.join(startpath, item)
        is_last = (i == len(items) - 1)
        prefix = '└── ' if is_last else '├── '
        print(indent + prefix + item)

        if os.path.isdir(path):
            next_indent = indent + ('    ' if is_last else '│   ')
            print_directory_tree(path, next_indent)

if __name__ == '__main__':
    current_dir = os.getcwd()
    print(f"Directory structure of: {current_dir}")
    print_directory_tree(current_dir)